(function(h){h.deparam=function(i,j){var d={},k={"true":!0,"false":!1,"null":null};h.each(i.replace(/\+/g," ").split("&"),function(i,l){var m;var a=l.split("="),c=decodeURIComponent(a[0]),g=d,f=0,b=c.split("]["),e=b.length-1;/\[/.test(b[0])&&/\]$/.test(b[e])?(b[e]=b[e].replace(/\]$/,""),b=b.shift().split("[").concat(b),e=b.length-1):e=0;if(2===a.length)if(a=decodeURIComponent(a[1]),j&&(a=a&&!isNaN(a)?+a:"undefined"===a?void 0:void 0!==k[a]?k[a]:a),e)for(;f<=e;f++)c=""===b[f]?g.length:b[f],m=g[c]=
f<e?g[c]||(b[f+1]&&isNaN(b[f+1])?{}:[]):a,g=m;else h.isArray(d[c])?d[c].push(a):d[c]=void 0!==d[c]?[d[c],a]:a;else c&&(d[c]=j?void 0:"")});return d}})(jQuery);
(function(d){function l(e,b,c,f){function a(a){a.timeout&&(g.cycleTimeout=setTimeout(function(){l(e,a,0,!a.rev)},a.timeout))}if(!b.busy){var g=e[0].parentNode,h=e[b.currSlide],k=e[b.nextSlide];if(0!==g.cycleTimeout||c)c||!g.cyclePause?(b.before.length&&d.each(b.before,function(a,c){c.apply(k,[h,k,b,f])}),b.nextSlide!=b.currSlide&&(b.busy=1,d.fn.cycle.custom(h,k,b,function(){m&&this.style.removeAttribute("filter");d.each(b.after,function(a,c){c.apply(k,[h,k,b,f])});a(b)})),c=b.nextSlide+1==e.length,
b.nextSlide=c?0:b.nextSlide+1,b.currSlide=c?e.length-1:b.nextSlide-1):a(b)}}function n(d,b,c){var f=d[0].parentNode,a=f.cycleTimeout;a&&(clearTimeout(a),f.cycleTimeout=0);b.nextSlide=b.currSlide+c;0>b.nextSlide?b.nextSlide=d.length-1:b.nextSlide>=d.length&&(b.nextSlide=0);l(d,b,1,0<=c);return!1}var m=/MSIE/.test(navigator.userAgent);d.fn.cycle=function(e){return this.each(function(){e=e||{};this.cycleTimeout&&clearTimeout(this.cycleTimeout);this.cyclePause=this.cycleTimeout=0;var b=d(this),c=e.slideExpr?
d(e.slideExpr,this):b.children(),f=c.get();if(2>f.length)window.console&&console.log("terminating; too few slides: "+f.length);else{var a=d.extend({},d.fn.cycle.defaults,e||{},d.metadata?b.metadata():d.meta?b.data():{}),g=d.isFunction(b.data)?b.data(a.metaAttr):null;g&&(a=d.extend(a,g));a.before=a.before?[a.before]:[];a.after=a.after?[a.after]:[];a.after.unshift(function(){a.busy=0});g=this.className;a.width=parseInt((g.match(/w:(\d+)/)||[])[1],10)||a.width;a.height=parseInt((g.match(/h:(\d+)/)||
[])[1],10)||a.height;a.timeout=parseInt((g.match(/t:(\d+)/)||[])[1],10)||a.timeout;"static"==b.css("position")&&b.css("position","relative");a.width&&b.width(a.width);a.height&&"auto"!=a.height&&b.height(a.height);c.css({position:"absolute",top:0}).each(function(a){d(this).css("z-index",f.length-a)});d(f[0]).css("opacity",1).show();m&&f[0].style.removeAttribute("filter");a.fit&&a.width&&c.width(a.width);a.fit&&a.height&&"auto"!=a.height&&c.height(a.height);a.pause&&b.hover(function(){this.cyclePause=
1},function(){this.cyclePause=0});(g=d.fn.cycle.transitions[a.fx])&&g(b,c,a);c.each(function(){var b=d(this);this.cycleH=a.fit&&a.height?a.height:b.height();this.cycleW=a.fit&&a.width?a.width:b.width()});a.cssFirst&&d(c[0]).css(a.cssFirst);if(a.timeout)for(a.speed.constructor==String&&(a.speed={slow:600,fast:200}[a.speed]||400),a.sync||(a.speed/=2);250>a.timeout-a.speed;)a.timeout+=a.speed;a.speedIn=a.speed;a.speedOut=a.speed;a.slideCount=f.length;a.currSlide=0;a.nextSlide=1;b=c[0];a.before.length&&
a.before[0].apply(b,[b,b,a,!0]);1<a.after.length&&a.after[1].apply(b,[b,b,a,!0]);a.click&&!a.next&&(a.next=a.click);a.next&&d(a.next).unbind("click.cycle").bind("click.cycle",function(){return n(f,a,a.rev?-1:1)});a.prev&&d(a.prev).unbind("click.cycle").bind("click.cycle",function(){return n(f,a,a.rev?1:-1)});a.timeout&&(this.cycleTimeout=setTimeout(function(){l(f,a,0,!a.rev)},a.timeout+(a.delay||0)))}})};d.fn.cycle.custom=function(e,b,c,f){var a=d(e),g=d(b);g.css(c.cssBefore);var h=function(){g.animate(c.animIn,
c.speedIn,c.easeIn,f)};a.animate(c.animOut,c.speedOut,c.easeOut,function(){a.css(c.cssAfter);c.sync||h()});c.sync&&h()};d.fn.cycle.transitions={fade:function(d,b,c){b.not(":eq(0)").hide();c.cssBefore={opacity:0,display:"block"};c.cssAfter={display:"none"};c.animOut={opacity:0};c.animIn={opacity:1}},fadeout:function(e,b,c){c.before.push(function(b,a,c,e){d(b).css("zIndex",c.slideCount+(!0===e?1:0));d(a).css("zIndex",c.slideCount+(!0===e?0:1))});b.not(":eq(0)").hide();c.cssBefore={opacity:1,display:"block",
zIndex:1};c.cssAfter={display:"none",zIndex:0};c.animOut={opacity:0};c.animIn={opacity:1}}};d.fn.cycle.ver=function(){return"Lite-1.7"};d.fn.cycle.defaults={animIn:{},animOut:{},fx:"fade",after:null,before:null,cssBefore:{},cssAfter:{},delay:0,fit:0,height:"auto",metaAttr:"cycle",next:null,pause:!1,prev:null,speed:1E3,slideExpr:null,sync:!0,timeout:4E3}})(jQuery);
/*! Hammer.JS - v2.0.4 - 2014-09-28
 * http://hammerjs.github.io/
 *
 * Copyright (c) 2014 Jorik Tangelder;
 * Licensed under the MIT license */

!function(a,b,c,d){"use strict";function e(a,b,c){return setTimeout(k(a,c),b)}function f(a,b,c){return Array.isArray(a)?(g(a,c[b],c),!0):!1}function g(a,b,c){var e;if(a)if(a.forEach)a.forEach(b,c);else if(a.length!==d)for(e=0;e<a.length;)b.call(c,a[e],e,a),e++;else for(e in a)a.hasOwnProperty(e)&&b.call(c,a[e],e,a)}function h(a,b,c){for(var e=Object.keys(b),f=0;f<e.length;)(!c||c&&a[e[f]]===d)&&(a[e[f]]=b[e[f]]),f++;return a}function i(a,b){return h(a,b,!0)}function j(a,b,c){var d,e=b.prototype;d=a.prototype=Object.create(e),d.constructor=a,d._super=e,c&&h(d,c)}function k(a,b){return function(){return a.apply(b,arguments)}}function l(a,b){return typeof a==kb?a.apply(b?b[0]||d:d,b):a}function m(a,b){return a===d?b:a}function n(a,b,c){g(r(b),function(b){a.addEventListener(b,c,!1)})}function o(a,b,c){g(r(b),function(b){a.removeEventListener(b,c,!1)})}function p(a,b){for(;a;){if(a==b)return!0;a=a.parentNode}return!1}function q(a,b){return a.indexOf(b)>-1}function r(a){return a.trim().split(/\s+/g)}function s(a,b,c){if(a.indexOf&&!c)return a.indexOf(b);for(var d=0;d<a.length;){if(c&&a[d][c]==b||!c&&a[d]===b)return d;d++}return-1}function t(a){return Array.prototype.slice.call(a,0)}function u(a,b,c){for(var d=[],e=[],f=0;f<a.length;){var g=b?a[f][b]:a[f];s(e,g)<0&&d.push(a[f]),e[f]=g,f++}return c&&(d=b?d.sort(function(a,c){return a[b]>c[b]}):d.sort()),d}function v(a,b){for(var c,e,f=b[0].toUpperCase()+b.slice(1),g=0;g<ib.length;){if(c=ib[g],e=c?c+f:b,e in a)return e;g++}return d}function w(){return ob++}function x(a){var b=a.ownerDocument;return b.defaultView||b.parentWindow}function y(a,b){var c=this;this.manager=a,this.callback=b,this.element=a.element,this.target=a.options.inputTarget,this.domHandler=function(b){l(a.options.enable,[a])&&c.handler(b)},this.init()}function z(a){var b,c=a.options.inputClass;return new(b=c?c:rb?N:sb?Q:qb?S:M)(a,A)}function A(a,b,c){var d=c.pointers.length,e=c.changedPointers.length,f=b&yb&&d-e===0,g=b&(Ab|Bb)&&d-e===0;c.isFirst=!!f,c.isFinal=!!g,f&&(a.session={}),c.eventType=b,B(a,c),a.emit("hammer.input",c),a.recognize(c),a.session.prevInput=c}function B(a,b){var c=a.session,d=b.pointers,e=d.length;c.firstInput||(c.firstInput=E(b)),e>1&&!c.firstMultiple?c.firstMultiple=E(b):1===e&&(c.firstMultiple=!1);var f=c.firstInput,g=c.firstMultiple,h=g?g.center:f.center,i=b.center=F(d);b.timeStamp=nb(),b.deltaTime=b.timeStamp-f.timeStamp,b.angle=J(h,i),b.distance=I(h,i),C(c,b),b.offsetDirection=H(b.deltaX,b.deltaY),b.scale=g?L(g.pointers,d):1,b.rotation=g?K(g.pointers,d):0,D(c,b);var j=a.element;p(b.srcEvent.target,j)&&(j=b.srcEvent.target),b.target=j}function C(a,b){var c=b.center,d=a.offsetDelta||{},e=a.prevDelta||{},f=a.prevInput||{};(b.eventType===yb||f.eventType===Ab)&&(e=a.prevDelta={x:f.deltaX||0,y:f.deltaY||0},d=a.offsetDelta={x:c.x,y:c.y}),b.deltaX=e.x+(c.x-d.x),b.deltaY=e.y+(c.y-d.y)}function D(a,b){var c,e,f,g,h=a.lastInterval||b,i=b.timeStamp-h.timeStamp;if(b.eventType!=Bb&&(i>xb||h.velocity===d)){var j=h.deltaX-b.deltaX,k=h.deltaY-b.deltaY,l=G(i,j,k);e=l.x,f=l.y,c=mb(l.x)>mb(l.y)?l.x:l.y,g=H(j,k),a.lastInterval=b}else c=h.velocity,e=h.velocityX,f=h.velocityY,g=h.direction;b.velocity=c,b.velocityX=e,b.velocityY=f,b.direction=g}function E(a){for(var b=[],c=0;c<a.pointers.length;)b[c]={clientX:lb(a.pointers[c].clientX),clientY:lb(a.pointers[c].clientY)},c++;return{timeStamp:nb(),pointers:b,center:F(b),deltaX:a.deltaX,deltaY:a.deltaY}}function F(a){var b=a.length;if(1===b)return{x:lb(a[0].clientX),y:lb(a[0].clientY)};for(var c=0,d=0,e=0;b>e;)c+=a[e].clientX,d+=a[e].clientY,e++;return{x:lb(c/b),y:lb(d/b)}}function G(a,b,c){return{x:b/a||0,y:c/a||0}}function H(a,b){return a===b?Cb:mb(a)>=mb(b)?a>0?Db:Eb:b>0?Fb:Gb}function I(a,b,c){c||(c=Kb);var d=b[c[0]]-a[c[0]],e=b[c[1]]-a[c[1]];return Math.sqrt(d*d+e*e)}function J(a,b,c){c||(c=Kb);var d=b[c[0]]-a[c[0]],e=b[c[1]]-a[c[1]];return 180*Math.atan2(e,d)/Math.PI}function K(a,b){return J(b[1],b[0],Lb)-J(a[1],a[0],Lb)}function L(a,b){return I(b[0],b[1],Lb)/I(a[0],a[1],Lb)}function M(){this.evEl=Nb,this.evWin=Ob,this.allow=!0,this.pressed=!1,y.apply(this,arguments)}function N(){this.evEl=Rb,this.evWin=Sb,y.apply(this,arguments),this.store=this.manager.session.pointerEvents=[]}function O(){this.evTarget=Ub,this.evWin=Vb,this.started=!1,y.apply(this,arguments)}function P(a,b){var c=t(a.touches),d=t(a.changedTouches);return b&(Ab|Bb)&&(c=u(c.concat(d),"identifier",!0)),[c,d]}function Q(){this.evTarget=Xb,this.targetIds={},y.apply(this,arguments)}function R(a,b){var c=t(a.touches),d=this.targetIds;if(b&(yb|zb)&&1===c.length)return d[c[0].identifier]=!0,[c,c];var e,f,g=t(a.changedTouches),h=[],i=this.target;if(f=c.filter(function(a){return p(a.target,i)}),b===yb)for(e=0;e<f.length;)d[f[e].identifier]=!0,e++;for(e=0;e<g.length;)d[g[e].identifier]&&h.push(g[e]),b&(Ab|Bb)&&delete d[g[e].identifier],e++;return h.length?[u(f.concat(h),"identifier",!0),h]:void 0}function S(){y.apply(this,arguments);var a=k(this.handler,this);this.touch=new Q(this.manager,a),this.mouse=new M(this.manager,a)}function T(a,b){this.manager=a,this.set(b)}function U(a){if(q(a,bc))return bc;var b=q(a,cc),c=q(a,dc);return b&&c?cc+" "+dc:b||c?b?cc:dc:q(a,ac)?ac:_b}function V(a){this.id=w(),this.manager=null,this.options=i(a||{},this.defaults),this.options.enable=m(this.options.enable,!0),this.state=ec,this.simultaneous={},this.requireFail=[]}function W(a){return a&jc?"cancel":a&hc?"end":a&gc?"move":a&fc?"start":""}function X(a){return a==Gb?"down":a==Fb?"up":a==Db?"left":a==Eb?"right":""}function Y(a,b){var c=b.manager;return c?c.get(a):a}function Z(){V.apply(this,arguments)}function $(){Z.apply(this,arguments),this.pX=null,this.pY=null}function _(){Z.apply(this,arguments)}function ab(){V.apply(this,arguments),this._timer=null,this._input=null}function bb(){Z.apply(this,arguments)}function cb(){Z.apply(this,arguments)}function db(){V.apply(this,arguments),this.pTime=!1,this.pCenter=!1,this._timer=null,this._input=null,this.count=0}function eb(a,b){return b=b||{},b.recognizers=m(b.recognizers,eb.defaults.preset),new fb(a,b)}function fb(a,b){b=b||{},this.options=i(b,eb.defaults),this.options.inputTarget=this.options.inputTarget||a,this.handlers={},this.session={},this.recognizers=[],this.element=a,this.input=z(this),this.touchAction=new T(this,this.options.touchAction),gb(this,!0),g(b.recognizers,function(a){var b=this.add(new a[0](a[1]));a[2]&&b.recognizeWith(a[2]),a[3]&&b.requireFailure(a[3])},this)}function gb(a,b){var c=a.element;g(a.options.cssProps,function(a,d){c.style[v(c.style,d)]=b?a:""})}function hb(a,c){var d=b.createEvent("Event");d.initEvent(a,!0,!0),d.gesture=c,c.target.dispatchEvent(d)}var ib=["","webkit","moz","MS","ms","o"],jb=b.createElement("div"),kb="function",lb=Math.round,mb=Math.abs,nb=Date.now,ob=1,pb=/mobile|tablet|ip(ad|hone|od)|android/i,qb="ontouchstart"in a,rb=v(a,"PointerEvent")!==d,sb=qb&&pb.test(navigator.userAgent),tb="touch",ub="pen",vb="mouse",wb="kinect",xb=25,yb=1,zb=2,Ab=4,Bb=8,Cb=1,Db=2,Eb=4,Fb=8,Gb=16,Hb=Db|Eb,Ib=Fb|Gb,Jb=Hb|Ib,Kb=["x","y"],Lb=["clientX","clientY"];y.prototype={handler:function(){},init:function(){this.evEl&&n(this.element,this.evEl,this.domHandler),this.evTarget&&n(this.target,this.evTarget,this.domHandler),this.evWin&&n(x(this.element),this.evWin,this.domHandler)},destroy:function(){this.evEl&&o(this.element,this.evEl,this.domHandler),this.evTarget&&o(this.target,this.evTarget,this.domHandler),this.evWin&&o(x(this.element),this.evWin,this.domHandler)}};var Mb={mousedown:yb,mousemove:zb,mouseup:Ab},Nb="mousedown",Ob="mousemove mouseup";j(M,y,{handler:function(a){var b=Mb[a.type];b&yb&&0===a.button&&(this.pressed=!0),b&zb&&1!==a.which&&(b=Ab),this.pressed&&this.allow&&(b&Ab&&(this.pressed=!1),this.callback(this.manager,b,{pointers:[a],changedPointers:[a],pointerType:vb,srcEvent:a}))}});var Pb={pointerdown:yb,pointermove:zb,pointerup:Ab,pointercancel:Bb,pointerout:Bb},Qb={2:tb,3:ub,4:vb,5:wb},Rb="pointerdown",Sb="pointermove pointerup pointercancel";a.MSPointerEvent&&(Rb="MSPointerDown",Sb="MSPointerMove MSPointerUp MSPointerCancel"),j(N,y,{handler:function(a){var b=this.store,c=!1,d=a.type.toLowerCase().replace("ms",""),e=Pb[d],f=Qb[a.pointerType]||a.pointerType,g=f==tb,h=s(b,a.pointerId,"pointerId");e&yb&&(0===a.button||g)?0>h&&(b.push(a),h=b.length-1):e&(Ab|Bb)&&(c=!0),0>h||(b[h]=a,this.callback(this.manager,e,{pointers:b,changedPointers:[a],pointerType:f,srcEvent:a}),c&&b.splice(h,1))}});var Tb={touchstart:yb,touchmove:zb,touchend:Ab,touchcancel:Bb},Ub="touchstart",Vb="touchstart touchmove touchend touchcancel";j(O,y,{handler:function(a){var b=Tb[a.type];if(b===yb&&(this.started=!0),this.started){var c=P.call(this,a,b);b&(Ab|Bb)&&c[0].length-c[1].length===0&&(this.started=!1),this.callback(this.manager,b,{pointers:c[0],changedPointers:c[1],pointerType:tb,srcEvent:a})}}});var Wb={touchstart:yb,touchmove:zb,touchend:Ab,touchcancel:Bb},Xb="touchstart touchmove touchend touchcancel";j(Q,y,{handler:function(a){var b=Wb[a.type],c=R.call(this,a,b);c&&this.callback(this.manager,b,{pointers:c[0],changedPointers:c[1],pointerType:tb,srcEvent:a})}}),j(S,y,{handler:function(a,b,c){var d=c.pointerType==tb,e=c.pointerType==vb;if(d)this.mouse.allow=!1;else if(e&&!this.mouse.allow)return;b&(Ab|Bb)&&(this.mouse.allow=!0),this.callback(a,b,c)},destroy:function(){this.touch.destroy(),this.mouse.destroy()}});var Yb=v(jb.style,"touchAction"),Zb=Yb!==d,$b="compute",_b="auto",ac="manipulation",bc="none",cc="pan-x",dc="pan-y";T.prototype={set:function(a){a==$b&&(a=this.compute()),Zb&&(this.manager.element.style[Yb]=a),this.actions=a.toLowerCase().trim()},update:function(){this.set(this.manager.options.touchAction)},compute:function(){var a=[];return g(this.manager.recognizers,function(b){l(b.options.enable,[b])&&(a=a.concat(b.getTouchAction()))}),U(a.join(" "))},preventDefaults:function(a){if(!Zb){var b=a.srcEvent,c=a.offsetDirection;if(this.manager.session.prevented)return void b.preventDefault();var d=this.actions,e=q(d,bc),f=q(d,dc),g=q(d,cc);return e||f&&c&Hb||g&&c&Ib?this.preventSrc(b):void 0}},preventSrc:function(a){this.manager.session.prevented=!0,a.preventDefault()}};var ec=1,fc=2,gc=4,hc=8,ic=hc,jc=16,kc=32;V.prototype={defaults:{},set:function(a){return h(this.options,a),this.manager&&this.manager.touchAction.update(),this},recognizeWith:function(a){if(f(a,"recognizeWith",this))return this;var b=this.simultaneous;return a=Y(a,this),b[a.id]||(b[a.id]=a,a.recognizeWith(this)),this},dropRecognizeWith:function(a){return f(a,"dropRecognizeWith",this)?this:(a=Y(a,this),delete this.simultaneous[a.id],this)},requireFailure:function(a){if(f(a,"requireFailure",this))return this;var b=this.requireFail;return a=Y(a,this),-1===s(b,a)&&(b.push(a),a.requireFailure(this)),this},dropRequireFailure:function(a){if(f(a,"dropRequireFailure",this))return this;a=Y(a,this);var b=s(this.requireFail,a);return b>-1&&this.requireFail.splice(b,1),this},hasRequireFailures:function(){return this.requireFail.length>0},canRecognizeWith:function(a){return!!this.simultaneous[a.id]},emit:function(a){function b(b){c.manager.emit(c.options.event+(b?W(d):""),a)}var c=this,d=this.state;hc>d&&b(!0),b(),d>=hc&&b(!0)},tryEmit:function(a){return this.canEmit()?this.emit(a):void(this.state=kc)},canEmit:function(){for(var a=0;a<this.requireFail.length;){if(!(this.requireFail[a].state&(kc|ec)))return!1;a++}return!0},recognize:function(a){var b=h({},a);return l(this.options.enable,[this,b])?(this.state&(ic|jc|kc)&&(this.state=ec),this.state=this.process(b),void(this.state&(fc|gc|hc|jc)&&this.tryEmit(b))):(this.reset(),void(this.state=kc))},process:function(){},getTouchAction:function(){},reset:function(){}},j(Z,V,{defaults:{pointers:1},attrTest:function(a){var b=this.options.pointers;return 0===b||a.pointers.length===b},process:function(a){var b=this.state,c=a.eventType,d=b&(fc|gc),e=this.attrTest(a);return d&&(c&Bb||!e)?b|jc:d||e?c&Ab?b|hc:b&fc?b|gc:fc:kc}}),j($,Z,{defaults:{event:"pan",threshold:10,pointers:1,direction:Jb},getTouchAction:function(){var a=this.options.direction,b=[];return a&Hb&&b.push(dc),a&Ib&&b.push(cc),b},directionTest:function(a){var b=this.options,c=!0,d=a.distance,e=a.direction,f=a.deltaX,g=a.deltaY;return e&b.direction||(b.direction&Hb?(e=0===f?Cb:0>f?Db:Eb,c=f!=this.pX,d=Math.abs(a.deltaX)):(e=0===g?Cb:0>g?Fb:Gb,c=g!=this.pY,d=Math.abs(a.deltaY))),a.direction=e,c&&d>b.threshold&&e&b.direction},attrTest:function(a){return Z.prototype.attrTest.call(this,a)&&(this.state&fc||!(this.state&fc)&&this.directionTest(a))},emit:function(a){this.pX=a.deltaX,this.pY=a.deltaY;var b=X(a.direction);b&&this.manager.emit(this.options.event+b,a),this._super.emit.call(this,a)}}),j(_,Z,{defaults:{event:"pinch",threshold:0,pointers:2},getTouchAction:function(){return[bc]},attrTest:function(a){return this._super.attrTest.call(this,a)&&(Math.abs(a.scale-1)>this.options.threshold||this.state&fc)},emit:function(a){if(this._super.emit.call(this,a),1!==a.scale){var b=a.scale<1?"in":"out";this.manager.emit(this.options.event+b,a)}}}),j(ab,V,{defaults:{event:"press",pointers:1,time:500,threshold:5},getTouchAction:function(){return[_b]},process:function(a){var b=this.options,c=a.pointers.length===b.pointers,d=a.distance<b.threshold,f=a.deltaTime>b.time;if(this._input=a,!d||!c||a.eventType&(Ab|Bb)&&!f)this.reset();else if(a.eventType&yb)this.reset(),this._timer=e(function(){this.state=ic,this.tryEmit()},b.time,this);else if(a.eventType&Ab)return ic;return kc},reset:function(){clearTimeout(this._timer)},emit:function(a){this.state===ic&&(a&&a.eventType&Ab?this.manager.emit(this.options.event+"up",a):(this._input.timeStamp=nb(),this.manager.emit(this.options.event,this._input)))}}),j(bb,Z,{defaults:{event:"rotate",threshold:0,pointers:2},getTouchAction:function(){return[bc]},attrTest:function(a){return this._super.attrTest.call(this,a)&&(Math.abs(a.rotation)>this.options.threshold||this.state&fc)}}),j(cb,Z,{defaults:{event:"swipe",threshold:10,velocity:.65,direction:Hb|Ib,pointers:1},getTouchAction:function(){return $.prototype.getTouchAction.call(this)},attrTest:function(a){var b,c=this.options.direction;return c&(Hb|Ib)?b=a.velocity:c&Hb?b=a.velocityX:c&Ib&&(b=a.velocityY),this._super.attrTest.call(this,a)&&c&a.direction&&a.distance>this.options.threshold&&mb(b)>this.options.velocity&&a.eventType&Ab},emit:function(a){var b=X(a.direction);b&&this.manager.emit(this.options.event+b,a),this.manager.emit(this.options.event,a)}}),j(db,V,{defaults:{event:"tap",pointers:1,taps:1,interval:300,time:250,threshold:2,posThreshold:10},getTouchAction:function(){return[ac]},process:function(a){var b=this.options,c=a.pointers.length===b.pointers,d=a.distance<b.threshold,f=a.deltaTime<b.time;if(this.reset(),a.eventType&yb&&0===this.count)return this.failTimeout();if(d&&f&&c){if(a.eventType!=Ab)return this.failTimeout();var g=this.pTime?a.timeStamp-this.pTime<b.interval:!0,h=!this.pCenter||I(this.pCenter,a.center)<b.posThreshold;this.pTime=a.timeStamp,this.pCenter=a.center,h&&g?this.count+=1:this.count=1,this._input=a;var i=this.count%b.taps;if(0===i)return this.hasRequireFailures()?(this._timer=e(function(){this.state=ic,this.tryEmit()},b.interval,this),fc):ic}return kc},failTimeout:function(){return this._timer=e(function(){this.state=kc},this.options.interval,this),kc},reset:function(){clearTimeout(this._timer)},emit:function(){this.state==ic&&(this._input.tapCount=this.count,this.manager.emit(this.options.event,this._input))}}),eb.VERSION="2.0.4",eb.defaults={domEvents:!1,touchAction:$b,enable:!0,inputTarget:null,inputClass:null,preset:[[bb,{enable:!1}],[_,{enable:!1},["rotate"]],[cb,{direction:Hb}],[$,{direction:Hb},["swipe"]],[db],[db,{event:"doubletap",taps:2},["tap"]],[ab]],cssProps:{userSelect:"none",touchSelect:"none",touchCallout:"none",contentZooming:"none",userDrag:"none",tapHighlightColor:"rgba(0,0,0,0)"}};var lc=1,mc=2;fb.prototype={set:function(a){return h(this.options,a),a.touchAction&&this.touchAction.update(),a.inputTarget&&(this.input.destroy(),this.input.target=a.inputTarget,this.input.init()),this},stop:function(a){this.session.stopped=a?mc:lc},recognize:function(a){var b=this.session;if(!b.stopped){this.touchAction.preventDefaults(a);var c,d=this.recognizers,e=b.curRecognizer;(!e||e&&e.state&ic)&&(e=b.curRecognizer=null);for(var f=0;f<d.length;)c=d[f],b.stopped===mc||e&&c!=e&&!c.canRecognizeWith(e)?c.reset():c.recognize(a),!e&&c.state&(fc|gc|hc)&&(e=b.curRecognizer=c),f++}},get:function(a){if(a instanceof V)return a;for(var b=this.recognizers,c=0;c<b.length;c++)if(b[c].options.event==a)return b[c];return null},add:function(a){if(f(a,"add",this))return this;var b=this.get(a.options.event);return b&&this.remove(b),this.recognizers.push(a),a.manager=this,this.touchAction.update(),a},remove:function(a){if(f(a,"remove",this))return this;var b=this.recognizers;return a=this.get(a),b.splice(s(b,a),1),this.touchAction.update(),this},on:function(a,b){var c=this.handlers;return g(r(a),function(a){c[a]=c[a]||[],c[a].push(b)}),this},off:function(a,b){var c=this.handlers;return g(r(a),function(a){b?c[a].splice(s(c[a],b),1):delete c[a]}),this},emit:function(a,b){this.options.domEvents&&hb(a,b);var c=this.handlers[a]&&this.handlers[a].slice();if(c&&c.length){b.type=a,b.preventDefault=function(){b.srcEvent.preventDefault()};for(var d=0;d<c.length;)c[d](b),d++}},destroy:function(){this.element&&gb(this,!1),this.handlers={},this.session={},this.input.destroy(),this.element=null}},h(eb,{INPUT_START:yb,INPUT_MOVE:zb,INPUT_END:Ab,INPUT_CANCEL:Bb,STATE_POSSIBLE:ec,STATE_BEGAN:fc,STATE_CHANGED:gc,STATE_ENDED:hc,STATE_RECOGNIZED:ic,STATE_CANCELLED:jc,STATE_FAILED:kc,DIRECTION_NONE:Cb,DIRECTION_LEFT:Db,DIRECTION_RIGHT:Eb,DIRECTION_UP:Fb,DIRECTION_DOWN:Gb,DIRECTION_HORIZONTAL:Hb,DIRECTION_VERTICAL:Ib,DIRECTION_ALL:Jb,Manager:fb,Input:y,TouchAction:T,TouchInput:Q,MouseInput:M,PointerEventInput:N,TouchMouseInput:S,SingleTouchInput:O,Recognizer:V,AttrRecognizer:Z,Tap:db,Pan:$,Swipe:cb,Pinch:_,Rotate:bb,Press:ab,on:n,off:o,each:g,merge:i,extend:h,inherit:j,bindFn:k,prefixed:v}),typeof define==kb&&define.amd?define(function(){return eb}):"undefined"!=typeof module&&module.exports?module.exports=eb:a[c]=eb}(window,document,"Hammer");
//# sourceMappingURL=hammer.min.map



/* The Jquery Plugin */
(function(factory) {
    if (typeof define === 'function' && define.amd) {
        define(['jquery', 'hammerjs'], factory);
    } else if (typeof exports === 'object') {
        factory(require('jquery'), require('hammerjs'));
    } else {
        factory(jQuery, Hammer);
    }
}(function($, Hammer) {
    function hammerify(el, options) {
        var $el = $(el);
        if(!$el.data("hammer")) {
            $el.data("hammer", new Hammer($el[0], options));
        }
    }

    $.fn.hammer = function(options) {
        return this.each(function() {
            hammerify(this, options);
        });
    };

    // extend the emit method to also trigger jQuery events
    Hammer.Manager.prototype.emit = (function(originalEmit) {
        return function(type, data) {
            originalEmit.call(this, type, data);
            $(this.element).trigger({
                type: type,
                gesture: data
            });
        };
    })(Hammer.Manager.prototype.emit);
}));
/* Modernizr 2.0.6 (Custom Build) | MIT & BSD
* Build: http://www.modernizr.com/download/#-fontface-backgroundsize-borderimage-borderradius-boxshadow-flexbox-hsla-multiplebgs-opacity-rgba-textshadow-cssanimations-csscolumns-generatedcontent-cssgradients-cssreflections-csstransforms-csstransforms3d-csstransitions-applicationcache-canvas-canvastext-draganddrop-hashchange-history-audio-video-indexeddb-input-inputtypes-localstorage-postmessage-sessionstorage-websockets-websqldatabase-webworkers-iepp-cssclasses-teststyles-testprop-testallprops-hasevent-prefixes-domprefixes-load
*/

; window.Modernizr = function (a, b, c) { function G() { e.input = function (a) { for (var b = 0, c = a.length; b < c; b++) s[a[b]] = a[b] in l; return s } ("autocomplete autofocus list placeholder max min multiple pattern required step".split(" ")), e.inputtypes = function (a) { for (var d = 0, e, f, h, i = a.length; d < i; d++) l.setAttribute("type", f = a[d]), e = l.type !== "text", e && (l.value = m, l.style.cssText = "position:absolute;visibility:hidden;", /^range$/.test(f) && l.style.WebkitAppearance !== c ? (g.appendChild(l), h = b.defaultView, e = h.getComputedStyle && h.getComputedStyle(l, null).WebkitAppearance !== "textfield" && l.offsetHeight !== 0, g.removeChild(l)) : /^(search|tel)$/.test(f) || (/^(url|email)$/.test(f) ? e = l.checkValidity && l.checkValidity() === !1 : /^color$/.test(f) ? (g.appendChild(l), g.offsetWidth, e = l.value != m, g.removeChild(l)) : e = l.value != m)), r[a[d]] = !!e; return r } ("search tel url email datetime date month week time datetime-local number range color".split(" ")) } function E(a, b) { var c = a.charAt(0).toUpperCase() + a.substr(1), d = (a + " " + p.join(c + " ") + c).split(" "); return D(d, b) } function D(a, b) { for (var d in a) if (k[a[d]] !== c) return b == "pfx" ? a[d] : !0; return !1 } function C(a, b) { return !! ~("" + a).indexOf(b) } function B(a, b) { return typeof a === b } function A(a, b) { return z(o.join(a + ";") + (b || "")) } function z(a) { k.cssText = a } var d = "2.0.6", e = {}, f = !0, g = b.documentElement, h = b.head || b.getElementsByTagName("head")[0], i = "modernizr", j = b.createElement(i), k = j.style, l = b.createElement("input"), m = ":)", n = Object.prototype.toString, o = " -webkit- -moz- -o- -ms- -khtml- ".split(" "), p = "Webkit Moz O ms Khtml".split(" "), q = {}, r = {}, s = {}, t = [], u = function (a, c, d, e) { var f, h, j, k = b.createElement("div"); if (parseInt(d, 10)) while (d--) j = b.createElement("div"), j.id = e ? e[d] : i + (d + 1), k.appendChild(j); f = ["&shy;", "<style>", a, "</style>"].join(""), k.id = i, k.innerHTML += f, g.appendChild(k), h = c(k, a), k.parentNode.removeChild(k); return !!h }, v = function () { function d(d, e) { e = e || b.createElement(a[d] || "div"), d = "on" + d; var f = d in e; f || (e.setAttribute || (e = b.createElement("div")), e.setAttribute && e.removeAttribute && (e.setAttribute(d, ""), f = B(e[d], "function"), B(e[d], c) || (e[d] = c), e.removeAttribute(d))), e = null; return f } var a = { select: "input", change: "input", submit: "form", reset: "form", error: "img", load: "img", abort: "img" }; return d } (), w, x = {}.hasOwnProperty, y; !B(x, c) && !B(x.call, c) ? y = function (a, b) { return x.call(a, b) } : y = function (a, b) { return b in a && B(a.constructor.prototype[b], c) }; var F = function (a, c) { var d = a.join(""), f = c.length; u(d, function (a, c) { var d = b.styleSheets[b.styleSheets.length - 1], g = d.cssRules && d.cssRules[0] ? d.cssRules[0].cssText : d.cssText || "", h = a.childNodes, i = {}; while (f--) i[h[f].id] = h[f]; e.csstransforms3d = i.csstransforms3d.offsetLeft === 9, e.generatedcontent = i.generatedcontent.offsetHeight >= 1, e.fontface = /src/i.test(g) && g.indexOf(c.split(" ")[0]) === 0 }, f, c) } (['@font-face {font-family:"font";src:url("https://")}', ["@media (", o.join("transform-3d),("), i, ")", "{#csstransforms3d{left:9px;position:absolute}}"].join(""), ['#generatedcontent:after{content:"', m, '";visibility:hidden}'].join("")], ["fontface", "csstransforms3d", "generatedcontent"]); q.flexbox = function () { function c(a, b, c, d) { a.style.cssText = o.join(b + ":" + c + ";") + (d || "") } function a(a, b, c, d) { b += ":", a.style.cssText = (b + o.join(c + ";" + b)).slice(0, -b.length) + (d || "") } var d = b.createElement("div"), e = b.createElement("div"); a(d, "display", "box", "width:42px;padding:0;"), c(e, "box-flex", "1", "width:10px;"), d.appendChild(e), g.appendChild(d); var f = e.offsetWidth === 42; d.removeChild(e), g.removeChild(d); return f }, q.canvas = function () { var a = b.createElement("canvas"); return !!a.getContext && !!a.getContext("2d") }, q.canvastext = function () { return !!e.canvas && !!B(b.createElement("canvas").getContext("2d").fillText, "function") }, q.postmessage = function () { return !!a.postMessage }, q.websqldatabase = function () { var b = !!a.openDatabase; return b }, q.indexedDB = function () { for (var b = -1, c = p.length; ++b < c; ) if (a[p[b].toLowerCase() + "IndexedDB"]) return !0; return !!a.indexedDB }, q.hashchange = function () { return v("hashchange", a) && (b.documentMode === c || b.documentMode > 7) }, q.history = function () { return !!a.history && !!history.pushState }, q.draganddrop = function () { return v("dragstart") && v("drop") }, q.websockets = function () { for (var b = -1, c = p.length; ++b < c; ) if (a[p[b] + "WebSocket"]) return !0; return "WebSocket" in a }, q.rgba = function () { z("background-color:rgba(150,255,150,.5)"); return C(k.backgroundColor, "rgba") }, q.hsla = function () { z("background-color:hsla(120,40%,100%,.5)"); return C(k.backgroundColor, "rgba") || C(k.backgroundColor, "hsla") }, q.multiplebgs = function () { z("background:url(https://),url(https://),red url(https://)"); return /(url\s*\(.*?){3}/.test(k.background) }, q.backgroundsize = function () { return E("backgroundSize") }, q.borderimage = function () { return E("borderImage") }, q.borderradius = function () { return E("borderRadius") }, q.boxshadow = function () { return E("boxShadow") }, q.textshadow = function () { return b.createElement("div").style.textShadow === "" }, q.opacity = function () { A("opacity:.55"); return /^0.55$/.test(k.opacity) }, q.cssanimations = function () { return E("animationName") }, q.csscolumns = function () { return E("columnCount") }, q.cssgradients = function () { var a = "background-image:", b = "gradient(linear,left top,right bottom,from(#9f9),to(white));", c = "linear-gradient(left top,#9f9, white);"; z((a + o.join(b + a) + o.join(c + a)).slice(0, -a.length)); return C(k.backgroundImage, "gradient") }, q.cssreflections = function () { return E("boxReflect") }, q.csstransforms = function () { return !!D(["transformProperty", "WebkitTransform", "MozTransform", "OTransform", "msTransform"]) }, q.csstransforms3d = function () { var a = !!D(["perspectiveProperty", "WebkitPerspective", "MozPerspective", "OPerspective", "msPerspective"]); a && "webkitPerspective" in g.style && (a = e.csstransforms3d); return a }, q.csstransitions = function () { return E("transitionProperty") }, q.fontface = function () { return e.fontface }, q.generatedcontent = function () { return e.generatedcontent }, q.video = function () { var a = b.createElement("video"), c = !1; try { if (c = !!a.canPlayType) { c = new Boolean(c), c.ogg = a.canPlayType('video/ogg; codecs="theora"'); var d = 'video/mp4; codecs="avc1.42E01E'; c.h264 = a.canPlayType(d + '"') || a.canPlayType(d + ', mp4a.40.2"'), c.webm = a.canPlayType('video/webm; codecs="vp8, vorbis"') } } catch (e) { } return c }, q.audio = function () { var a = b.createElement("audio"), c = !1; try { if (c = !!a.canPlayType) c = new Boolean(c), c.ogg = a.canPlayType('audio/ogg; codecs="vorbis"'), c.mp3 = a.canPlayType("audio/mpeg;"), c.wav = a.canPlayType('audio/wav; codecs="1"'), c.m4a = a.canPlayType("audio/x-m4a;") || a.canPlayType("audio/aac;") } catch (d) { } return c }, q.localstorage = function () { try { return !!localStorage.getItem } catch (a) { return !1 } }, q.sessionstorage = function () { try { return !!sessionStorage.getItem } catch (a) { return !1 } }, q.webworkers = function () { return !!a.Worker }, q.applicationcache = function () { return !!a.applicationCache }; for (var H in q) y(q, H) && (w = H.toLowerCase(), e[w] = q[H](), t.push((e[w] ? "" : "no-") + w)); e.input || G(), z(""), j = l = null, a.attachEvent && function () { var a = b.createElement("div"); a.innerHTML = "<elem></elem>"; return a.childNodes.length !== 1 } () && function (a, b) { function s(a) { var b = -1; while (++b < g) a.createElement(f[b]) } a.iepp = a.iepp || {}; var d = a.iepp, e = d.html5elements || "abbr|article|aside|audio|canvas|datalist|details|figcaption|figure|footer|header|hgroup|mark|meter|nav|output|progress|section|summary|time|video", f = e.split("|"), g = f.length, h = new RegExp("(^|\\s)(" + e + ")", "gi"), i = new RegExp("<(/*)(" + e + ")", "gi"), j = /^\s*[\{\}]\s*$/, k = new RegExp("(^|[^\\n]*?\\s)(" + e + ")([^\\n]*)({[\\n\\w\\W]*?})", "gi"), l = b.createDocumentFragment(), m = b.documentElement, n = m.firstChild, o = b.createElement("body"), p = b.createElement("style"), q = /print|all/, r; d.getCSS = function (a, b) { if (a + "" === c) return ""; var e = -1, f = a.length, g, h = []; while (++e < f) { g = a[e]; if (g.disabled) continue; b = g.media || b, q.test(b) && h.push(d.getCSS(g.imports, b), g.cssText), b = "all" } return h.join("") }, d.parseCSS = function (a) { var b = [], c; while ((c = k.exec(a)) != null) b.push(((j.exec(c[1]) ? "\n" : c[1]) + c[2] + c[3]).replace(h, "$1.iepp_$2") + c[4]); return b.join("\n") }, d.writeHTML = function () { var a = -1; r = r || b.body; while (++a < g) { var c = b.getElementsByTagName(f[a]), d = c.length, e = -1; while (++e < d) c[e].className.indexOf("iepp_") < 0 && (c[e].className += " iepp_" + f[a]) } l.appendChild(r), m.appendChild(o), o.className = r.className, o.id = r.id, o.innerHTML = r.innerHTML.replace(i, "<$1font") }, d._beforePrint = function () { p.styleSheet.cssText = d.parseCSS(d.getCSS(b.styleSheets, "all")), d.writeHTML() }, d.restoreHTML = function () { o.innerHTML = "", m.removeChild(o), m.appendChild(r) }, d._afterPrint = function () { d.restoreHTML(), p.styleSheet.cssText = "" }, s(b), s(l); d.disablePP || (n.insertBefore(p, n.firstChild), p.media = "print", p.className = "iepp-printshim", a.attachEvent("onbeforeprint", d._beforePrint), a.attachEvent("onafterprint", d._afterPrint)) } (a, b), e._version = d, e._prefixes = o, e._domPrefixes = p, e.hasEvent = v, e.testProp = function (a) { return D([a]) }, e.testAllProps = E, e.testStyles = u, g.className = g.className.replace(/\bno-js\b/, "") + (f ? " js " + t.join(" ") : ""); return e } (this, this.document), function (a, b, c) { function k(a) { return !a || a == "loaded" || a == "complete" } function j() { var a = 1, b = -1; while (p.length - ++b) if (p[b].s && !(a = p[b].r)) break; a && g() } function i(a) { var c = b.createElement("script"), d; c.src = a.s, c.onreadystatechange = c.onload = function () { !d && k(c.readyState) && (d = 1, j(), c.onload = c.onreadystatechange = null) }, m(function () { d || (d = 1, j()) }, H.errorTimeout), a.e ? c.onload() : n.parentNode.insertBefore(c, n) } function h(a) { var c = b.createElement("link"), d; c.href = a.s, c.rel = "stylesheet", c.type = "text/css"; if (!a.e && (w || r)) { var e = function (a) { m(function () { if (!d) try { a.sheet.cssRules.length ? (d = 1, j()) : e(a) } catch (b) { b.code == 1e3 || b.message == "security" || b.message == "denied" ? (d = 1, m(function () { j() }, 0)) : e(a) } }, 0) }; e(c) } else c.onload = function () { d || (d = 1, m(function () { j() }, 0)) }, a.e && c.onload(); m(function () { d || (d = 1, j()) }, H.errorTimeout), !a.e && n.parentNode.insertBefore(c, n) } function g() { var a = p.shift(); q = 1, a ? a.t ? m(function () { a.t == "c" ? h(a) : i(a) }, 0) : (a(), j()) : q = 0 } function f(a, c, d, e, f, h) { function i() { !o && k(l.readyState) && (r.r = o = 1, !q && j(), l.onload = l.onreadystatechange = null, m(function () { u.removeChild(l) }, 0)) } var l = b.createElement(a), o = 0, r = { t: d, s: c, e: h }; l.src = l.data = c, !s && (l.style.display = "none"), l.width = l.height = "0", a != "object" && (l.type = d), l.onload = l.onreadystatechange = i, a == "img" ? l.onerror = i : a == "script" && (l.onerror = function () { r.e = r.r = 1, g() }), p.splice(e, 0, r), u.insertBefore(l, s ? null : n), m(function () { o || (u.removeChild(l), r.r = r.e = o = 1, j()) }, H.errorTimeout) } function e(a, b, c) { var d = b == "c" ? z : y; q = 0, b = b || "j", C(a) ? f(d, a, b, this.i++, l, c) : (p.splice(this.i++, 0, a), p.length == 1 && g()); return this } function d() { var a = H; a.loader = { load: e, i: 0 }; return a } var l = b.documentElement, m = a.setTimeout, n = b.getElementsByTagName("script")[0], o = {}.toString, p = [], q = 0, r = "MozAppearance" in l.style, s = r && !!b.createRange().compareNode, t = r && !s, u = s ? l : n.parentNode, v = a.opera && o.call(a.opera) == "[object Opera]", w = "webkitAppearance" in l.style, x = w && "async" in b.createElement("script"), y = r ? "object" : v || x ? "img" : "script", z = w ? "img" : y, A = Array.isArray || function (a) { return o.call(a) == "[object Array]" }, B = function (a) { return Object(a) === a }, C = function (a) { return typeof a == "string" }, D = function (a) { return o.call(a) == "[object Function]" }, E = [], F = {}, G, H; H = function (a) { function f(a) { var b = a.split("!"), c = E.length, d = b.pop(), e = b.length, f = { url: d, origUrl: d, prefixes: b }, g, h; for (h = 0; h < e; h++) g = F[b[h]], g && (f = g(f)); for (h = 0; h < c; h++) f = E[h](f); return f } function e(a, b, e, g, h) { var i = f(a), j = i.autoCallback; if (!i.bypass) { b && (b = D(b) ? b : b[a] || b[g] || b[a.split("/").pop().split("?")[0]]); if (i.instead) return i.instead(a, b, e, g, h); e.load(i.url, i.forceCSS || !i.forceJS && /css$/.test(i.url) ? "c" : c, i.noexec), (D(b) || D(j)) && e.load(function () { d(), b && b(i.origUrl, h, g), j && j(i.origUrl, h, g) }) } } function b(a, b) { function c(a) { if (C(a)) e(a, h, b, 0, d); else if (B(a)) for (i in a) a.hasOwnProperty(i) && e(a[i], h, b, i, d) } var d = !!a.test, f = d ? a.yep : a.nope, g = a.load || a.both, h = a.callback, i; c(f), c(g), a.complete && b.load(a.complete) } var g, h, i = this.yepnope.loader; if (C(a)) e(a, 0, i, 0); else if (A(a)) for (g = 0; g < a.length; g++) h = a[g], C(h) ? e(h, 0, i, 0) : A(h) ? H(h) : B(h) && b(h, i); else B(a) && b(a, i) }, H.addPrefix = function (a, b) { F[a] = b }, H.addFilter = function (a) { E.push(a) }, H.errorTimeout = 1e4, b.readyState == null && b.addEventListener && (b.readyState = "loading", b.addEventListener("DOMContentLoaded", G = function () { b.removeEventListener("DOMContentLoaded", G, 0), b.readyState = "complete" }, 0)), a.yepnope = d() } (this, this.document), Modernizr.load = function () { yepnope.apply(window, [].slice.call(arguments, 0)) };
/*! skrollr 0.6.19 (2014-01-02) | Alexander Prinzhorn - https://github.com/Prinzhorn/skrollr | Free to use under terms of MIT license */

(function(e,t,r){"use strict";function n(r){if(o=t.documentElement,a=t.body,K(),it=this,r=r||{},ut=r.constants||{},r.easing)for(var n in r.easing)U[n]=r.easing[n];yt=r.edgeStrategy||"set",ct={beforerender:r.beforerender,render:r.render},ft=r.forceHeight!==!1,ft&&(zt=r.scale||1),pt=r.mobileDeceleration||E,gt=r.smoothScrolling!==!1,vt=r.smoothScrollingDuration||x,dt={targetTop:it.getScrollTop()},_t=(r.mobileCheck||function(){return/Android|iPhone|iPad|iPod|BlackBerry|Windows Phone/i.test(navigator.userAgent||navigator.vendor||e.opera)})(),_t?(st=t.getElementById("skrollr-body"),st&&at(),X(),Ct(o,[y,S],[T])):Ct(o,[y,b],[T]),it.refresh(),St(e,"resize orientationchange",function(){var e=o.clientWidth,t=o.clientHeight;(t!==$t||e!==Lt)&&($t=t,Lt=e,Mt=!0)});var i=Y();return function l(){Z(),bt=i(l)}(),it}var o,a,i=e.skrollr={get:function(){return it},init:function(e){return it||new n(e)},VERSION:"0.6.19"},l=Object.prototype.hasOwnProperty,s=e.Math,c=e.getComputedStyle,f="touchstart",u="touchmove",p="touchcancel",m="touchend",g="skrollable",v=g+"-before",d=g+"-between",h=g+"-after",y="skrollr",T="no-"+y,b=y+"-desktop",S=y+"-mobile",w="linear",k=1e3,E=.004,x=200,A="start",F="end",C="center",D="bottom",H="___skrollable_id",P=/^(?:input|textarea|button|select)$/i,N=/^\s+|\s+$/g,V=/^data(?:-(_\w+))?(?:-?(-?\d*\.?\d+p?))?(?:-?(start|end|top|center|bottom))?(?:-?(top|center|bottom))?$/,z=/\s*([\w\-\[\]]+)\s*:\s*(.+?)\s*(?:;|$)/gi,O=/^([a-z\-]+)\[(\w+)\]$/,q=/-([a-z])/g,I=function(e,t){return t.toUpperCase()},L=/[\-+]?[\d]*\.?[\d]+/g,$=/\{\?\}/g,M=/rgba?\(\s*-?\d+\s*,\s*-?\d+\s*,\s*-?\d+/g,B=/[a-z\-]+-gradient/g,_="",G="",K=function(){var e=/^(?:O|Moz|webkit|ms)|(?:-(?:o|moz|webkit|ms)-)/;if(c){var t=c(a,null);for(var n in t)if(_=n.match(e)||+n==n&&t[n].match(e))break;if(!_)return _=G="",r;_=_[0],"-"===_.slice(0,1)?(G=_,_={"-webkit-":"webkit","-moz-":"Moz","-ms-":"ms","-o-":"O"}[_]):G="-"+_.toLowerCase()+"-"}},Y=function(){var t=e.requestAnimationFrame||e[_.toLowerCase()+"RequestAnimationFrame"],r=Pt();return(_t||!t)&&(t=function(t){var n=Pt()-r,o=s.max(0,1e3/60-n);return e.setTimeout(function(){r=Pt(),t()},o)}),t},R=function(){var t=e.cancelAnimationFrame||e[_.toLowerCase()+"CancelAnimationFrame"];return(_t||!t)&&(t=function(t){return e.clearTimeout(t)}),t},U={begin:function(){return 0},end:function(){return 1},linear:function(e){return e},quadratic:function(e){return e*e},cubic:function(e){return e*e*e},swing:function(e){return-s.cos(e*s.PI)/2+.5},sqrt:function(e){return s.sqrt(e)},outCubic:function(e){return s.pow(e-1,3)+1},bounce:function(e){var t;if(.5083>=e)t=3;else if(.8489>=e)t=9;else if(.96208>=e)t=27;else{if(!(.99981>=e))return 1;t=91}return 1-s.abs(3*s.cos(1.028*e*t)/t)}};n.prototype.refresh=function(e){var n,o,a=!1;for(e===r?(a=!0,lt=[],Bt=0,e=t.getElementsByTagName("*")):e=[].concat(e),n=0,o=e.length;o>n;n++){var i=e[n],l=i,s=[],c=gt,f=yt;if(i.attributes){for(var u=0,p=i.attributes.length;p>u;u++){var m=i.attributes[u];if("data-anchor-target"!==m.name)if("data-smooth-scrolling"!==m.name)if("data-edge-strategy"!==m.name){var v=m.name.match(V);if(null!==v){var d={props:m.value,element:i};s.push(d);var h=v[1];h&&(d.constant=h.substr(1));var y=v[2];/p$/.test(y)?(d.isPercentage=!0,d.offset=(0|y.slice(0,-1))/100):d.offset=0|y;var T=v[3],b=v[4]||T;T&&T!==A&&T!==F?(d.mode="relative",d.anchors=[T,b]):(d.mode="absolute",T===F?d.isEnd=!0:d.isPercentage||(d.offset=d.offset*zt))}}else f=m.value;else c="off"!==m.value;else if(l=t.querySelector(m.value),null===l)throw'Unable to find anchor target "'+m.value+'"'}if(s.length){var S,w,k;!a&&H in i?(k=i[H],S=lt[k].styleAttr,w=lt[k].classAttr):(k=i[H]=Bt++,S=i.style.cssText,w=Ft(i)),lt[k]={element:i,styleAttr:S,classAttr:w,anchorTarget:l,keyFrames:s,smoothScrolling:c,edgeStrategy:f},Ct(i,[g],[])}}}for(Et(),n=0,o=e.length;o>n;n++){var E=lt[e[n][H]];E!==r&&(J(E),et(E))}return it},n.prototype.relativeToAbsolute=function(e,t,r){var n=o.clientHeight,a=e.getBoundingClientRect(),i=a.top,l=a.bottom-a.top;return t===D?i-=n:t===C&&(i-=n/2),r===D?i+=l:r===C&&(i+=l/2),i+=it.getScrollTop(),0|i+.5},n.prototype.animateTo=function(e,t){t=t||{};var n=Pt(),o=it.getScrollTop();return mt={startTop:o,topDiff:e-o,targetTop:e,duration:t.duration||k,startTime:n,endTime:n+(t.duration||k),easing:U[t.easing||w],done:t.done},mt.topDiff||(mt.done&&mt.done.call(it,!1),mt=r),it},n.prototype.stopAnimateTo=function(){mt&&mt.done&&mt.done.call(it,!0),mt=r},n.prototype.isAnimatingTo=function(){return!!mt},n.prototype.setScrollTop=function(t,r){return ht=r===!0,_t?Gt=s.min(s.max(t,0),Vt):e.scrollTo(0,t),it},n.prototype.getScrollTop=function(){return _t?Gt:e.pageYOffset||o.scrollTop||a.scrollTop||0},n.prototype.getMaxScrollTop=function(){return Vt},n.prototype.on=function(e,t){return ct[e]=t,it},n.prototype.off=function(e){return delete ct[e],it},n.prototype.destroy=function(){var e=R();e(bt),kt(),Ct(o,[T],[y,b,S]);for(var t=0,n=lt.length;n>t;t++)ot(lt[t].element);o.style.overflow=a.style.overflow="auto",o.style.height=a.style.height="auto",st&&i.setStyle(st,"transform","none"),it=r,st=r,ct=r,ft=r,Vt=0,zt=1,ut=r,pt=r,Ot="down",qt=-1,Lt=0,$t=0,Mt=!1,mt=r,gt=r,vt=r,dt=r,ht=r,Bt=0,yt=r,_t=!1,Gt=0,Tt=r};var X=function(){var n,i,l,c,g,v,d,h,y,T,b,S;St(o,[f,u,p,m].join(" "),function(e){var o=e.changedTouches[0];for(c=e.target;3===c.nodeType;)c=c.parentNode;switch(g=o.clientY,v=o.clientX,T=e.timeStamp,P.test(c.tagName)||e.preventDefault(),e.type){case f:n&&n.blur(),it.stopAnimateTo(),n=c,i=d=g,l=v,y=T;break;case u:P.test(c.tagName)&&t.activeElement!==c&&e.preventDefault(),h=g-d,S=T-b,it.setScrollTop(Gt-h,!0),d=g,b=T;break;default:case p:case m:var a=i-g,w=l-v,k=w*w+a*a;if(49>k){if(!P.test(n.tagName)){n.focus();var E=t.createEvent("MouseEvents");E.initMouseEvent("click",!0,!0,e.view,1,o.screenX,o.screenY,o.clientX,o.clientY,e.ctrlKey,e.altKey,e.shiftKey,e.metaKey,0,null),n.dispatchEvent(E)}return}n=r;var x=h/S;x=s.max(s.min(x,3),-3);var A=s.abs(x/pt),F=x*A+.5*pt*A*A,C=it.getScrollTop()-F,D=0;C>Vt?(D=(Vt-C)/F,C=Vt):0>C&&(D=-C/F,C=0),A*=1-D,it.animateTo(0|C+.5,{easing:"outCubic",duration:A})}}),e.scrollTo(0,0),o.style.overflow=a.style.overflow="hidden"},j=function(){var e,t,r,n,a,i,l,c,f,u,p,m=o.clientHeight,g=xt();for(c=0,f=lt.length;f>c;c++)for(e=lt[c],t=e.element,r=e.anchorTarget,n=e.keyFrames,a=0,i=n.length;i>a;a++)l=n[a],u=l.offset,p=g[l.constant]||0,l.frame=u,l.isPercentage&&(u*=m,l.frame=u),"relative"===l.mode&&(ot(t),l.frame=it.relativeToAbsolute(r,l.anchors[0],l.anchors[1])-u,ot(t,!0)),l.frame+=p,ft&&!l.isEnd&&l.frame>Vt&&(Vt=l.frame);for(Vt=s.max(Vt,At()),c=0,f=lt.length;f>c;c++){for(e=lt[c],n=e.keyFrames,a=0,i=n.length;i>a;a++)l=n[a],p=g[l.constant]||0,l.isEnd&&(l.frame=Vt-l.offset+p);e.keyFrames.sort(Nt)}},W=function(e,t){for(var r=0,n=lt.length;n>r;r++){var o,a,s=lt[r],c=s.element,f=s.smoothScrolling?e:t,u=s.keyFrames,p=u[0].frame,m=u[u.length-1].frame,y=p>f,T=f>m,b=u[y?0:u.length-1];if(y||T){if(y&&-1===s.edge||T&&1===s.edge)continue;switch(Ct(c,[y?v:h],[v,d,h]),s.edge=y?-1:1,s.edgeStrategy){case"reset":ot(c);continue;case"ease":f=b.frame;break;default:case"set":var S=b.props;for(o in S)l.call(S,o)&&(a=nt(S[o].value),i.setStyle(c,o,a));continue}}else 0!==s.edge&&(Ct(c,[g,d],[v,h]),s.edge=0);for(var w=0,k=u.length-1;k>w;w++)if(f>=u[w].frame&&u[w+1].frame>=f){var E=u[w],x=u[w+1];for(o in E.props)if(l.call(E.props,o)){var A=(f-E.frame)/(x.frame-E.frame);A=E.props[o].easing(A),a=rt(E.props[o].value,x.props[o].value,A),a=nt(a),i.setStyle(c,o,a)}break}}},Z=function(){Mt&&(Mt=!1,Et());var e,t,n=it.getScrollTop(),o=Pt();if(mt)o>=mt.endTime?(n=mt.targetTop,e=mt.done,mt=r):(t=mt.easing((o-mt.startTime)/mt.duration),n=0|mt.startTop+t*mt.topDiff),it.setScrollTop(n,!0);else if(!ht){var a=dt.targetTop-n;a&&(dt={startTop:qt,topDiff:n-qt,targetTop:n,startTime:It,endTime:It+vt}),dt.endTime>=o&&(t=U.sqrt((o-dt.startTime)/vt),n=0|dt.startTop+t*dt.topDiff)}if(_t&&st&&i.setStyle(st,"transform","translate(0, "+-Gt+"px) "+Tt),ht||qt!==n){Ot=n>qt?"down":qt>n?"up":Ot,ht=!1;var l={curTop:n,lastTop:qt,maxTop:Vt,direction:Ot},s=ct.beforerender&&ct.beforerender.call(it,l);s!==!1&&(W(n,it.getScrollTop()),qt=n,ct.render&&ct.render.call(it,l)),e&&e.call(it,!1)}It=o},J=function(e){for(var t=0,r=e.keyFrames.length;r>t;t++){for(var n,o,a,i,l=e.keyFrames[t],s={};null!==(i=z.exec(l.props));)a=i[1],o=i[2],n=a.match(O),null!==n?(a=n[1],n=n[2]):n=w,o=o.indexOf("!")?Q(o):[o.slice(1)],s[a]={value:o,easing:U[n]};l.props=s}},Q=function(e){var t=[];return M.lastIndex=0,e=e.replace(M,function(e){return e.replace(L,function(e){return 100*(e/255)+"%"})}),G&&(B.lastIndex=0,e=e.replace(B,function(e){return G+e})),e=e.replace(L,function(e){return t.push(+e),"{?}"}),t.unshift(e),t},et=function(e){var t,r,n={};for(t=0,r=e.keyFrames.length;r>t;t++)tt(e.keyFrames[t],n);for(n={},t=e.keyFrames.length-1;t>=0;t--)tt(e.keyFrames[t],n)},tt=function(e,t){var r;for(r in t)l.call(e.props,r)||(e.props[r]=t[r]);for(r in e.props)t[r]=e.props[r]},rt=function(e,t,r){var n,o=e.length;if(o!==t.length)throw"Can't interpolate between \""+e[0]+'" and "'+t[0]+'"';var a=[e[0]];for(n=1;o>n;n++)a[n]=e[n]+(t[n]-e[n])*r;return a},nt=function(e){var t=1;return $.lastIndex=0,e[0].replace($,function(){return e[t++]})},ot=function(e,t){e=[].concat(e);for(var r,n,o=0,a=e.length;a>o;o++)n=e[o],r=lt[n[H]],r&&(t?(n.style.cssText=r.dirtyStyleAttr,Ct(n,r.dirtyClassAttr)):(r.dirtyStyleAttr=n.style.cssText,r.dirtyClassAttr=Ft(n),n.style.cssText=r.styleAttr,Ct(n,r.classAttr)))},at=function(){Tt="translateZ(0)",i.setStyle(st,"transform",Tt);var e=c(st),t=e.getPropertyValue("transform"),r=e.getPropertyValue(G+"transform"),n=t&&"none"!==t||r&&"none"!==r;n||(Tt="")};i.setStyle=function(e,t,r){var n=e.style;if(t=t.replace(q,I).replace("-",""),"zIndex"===t)n[t]=isNaN(r)?r:""+(0|r);else if("float"===t)n.styleFloat=n.cssFloat=r;else try{_&&(n[_+t.slice(0,1).toUpperCase()+t.slice(1)]=r),n[t]=r}catch(o){}};var it,lt,st,ct,ft,ut,pt,mt,gt,vt,dt,ht,yt,Tt,bt,St=i.addEvent=function(t,r,n){var o=function(t){return t=t||e.event,t.target||(t.target=t.srcElement),t.preventDefault||(t.preventDefault=function(){t.returnValue=!1}),n.call(this,t)};r=r.split(" ");for(var a,i=0,l=r.length;l>i;i++)a=r[i],t.addEventListener?t.addEventListener(a,n,!1):t.attachEvent("on"+a,o),Kt.push({element:t,name:a,listener:n})},wt=i.removeEvent=function(e,t,r){t=t.split(" ");for(var n=0,o=t.length;o>n;n++)e.removeEventListener?e.removeEventListener(t[n],r,!1):e.detachEvent("on"+t[n],r)},kt=function(){for(var e,t=0,r=Kt.length;r>t;t++)e=Kt[t],wt(e.element,e.name,e.listener);Kt=[]},Et=function(){var e=it.getScrollTop();Vt=0,ft&&!_t&&(a.style.height="auto"),j(),ft&&!_t&&(a.style.height=Vt+o.clientHeight+"px"),_t?it.setScrollTop(s.min(it.getScrollTop(),Vt)):it.setScrollTop(e,!0),ht=!0},xt=function(){var e,t,r=o.clientHeight,n={};for(e in ut)t=ut[e],"function"==typeof t?t=t.call(it):/p$/.test(t)&&(t=t.substr(0,-1)/100*r),n[e]=t;return n},At=function(){var e=st&&st.offsetHeight||0,t=s.max(e,a.scrollHeight,a.offsetHeight,o.scrollHeight,o.offsetHeight,o.clientHeight);return t-o.clientHeight},Ft=function(t){var r="className";return e.SVGElement&&t instanceof e.SVGElement&&(t=t[r],r="baseVal"),t[r]},Ct=function(t,n,o){var a="className";if(e.SVGElement&&t instanceof e.SVGElement&&(t=t[a],a="baseVal"),o===r)return t[a]=n,r;for(var i=t[a],l=0,s=o.length;s>l;l++)i=Ht(i).replace(Ht(o[l])," ");i=Dt(i);for(var c=0,f=n.length;f>c;c++)-1===Ht(i).indexOf(Ht(n[c]))&&(i+=" "+n[c]);t[a]=Dt(i)},Dt=function(e){return e.replace(N,"")},Ht=function(e){return" "+e+" "},Pt=Date.now||function(){return+new Date},Nt=function(e,t){return e.frame-t.frame},Vt=0,zt=1,Ot="down",qt=-1,It=Pt(),Lt=0,$t=0,Mt=!1,Bt=0,_t=!1,Gt=0,Kt=[]})(window,document);
/**
 *  A Jquery Extension that hooks into the events.chapamn.edu feed.
 *
 * Usage: $('#my-cool-feed').chapmanEventsFeed({url: 'https://events.chapman.edu?group_id=56'});
 *
 * This will fill in the #my-cool-feed
 */


(function( $ ){

  /**
   * The constructor that takes in an object of options.
   */
  ChapmanEventsFeed = function(options) {
    if (!options || !options.feed_path) throw "ChapmanEventsFeed needs to have a url passed into the options object."
    this.per               = options.per   || 2;
    this.browse_link       = options.browse_link === undefined ? true : options.browse_link;
    this.feed              = options.feed        === undefined ? true : options.feed;
    this.featured          = options.featured    === undefined ? true : options.featured;
    this.$feed_element     = options.$feed_element;
    this.$featured_element = options.$featured_element;
    this.feed_path         = options.feed_path;
    this.featured_path     = options.featured_path;
    this.program_events    = options.program_events;
    this.feed_url          = this.feedUrl();
    this.featured_url      = this.featuredUrl();
  };


  /**
   * Converts the url into the feed url for ajax
   */
  ChapmanEventsFeed.prototype.feedUrl = function() {
    var parser  = document.createElement('a');
    parser.href = this.feed_path;
    parser.pathname += 'feed.json';
    return parser.href;
  };

  /**
   * Converts the url into the featured url for ajax
   */
  ChapmanEventsFeed.prototype.featuredUrl = function() {
    var parser  = document.createElement('a');
    parser.href = this.featured_path;
    parser.pathname += '/feed.json';
    return parser.href;
  }


  /**
   * Makes the ajax request to our endpoint.  This expects an html response.
   */
  ChapmanEventsFeed.prototype.fetchFeed = function(callback) {
    $.ajax({
      method:  'GET',
      data:    { per: this.per },
      url:     this.feed_url,
      success: this.onFeedSuccess.bind(this),
      error:   this.onFeedError.bind(this)
    });
  };

  /**
   * Makes the ajax request for the featured event spot.  Expects an html response
   */
  ChapmanEventsFeed.prototype.fetchFeatured = function() {
    $.ajax({
      method:  'GET',
      data:    { alt_url: this.feed_url },
      url:     this.featured_url,
      headers: {'Access-Control-Allow-Origin': '*'},
      success: this.onFeaturedSuccess.bind(this),
      error:   this.onFeaturedError.bind(this)
    });
  };

  /**
   * The callback for when feed ajax was a success
   */
  ChapmanEventsFeed.prototype.onFeedSuccess = function(data) {
    var $event_cards = $(),
        $feed_column = $('<div class="feed-column"></div>'),
        self = this;
    if (this.program_events) {
      var $cardContainter = $('#program-events-display')

      data.events.forEach(function(event) {
        var $eventCard = self.programCard(event);
        $cardContainter.append($eventCard);
      });

      return;
    }
    $.each(data.events, function(index, event) {
      var $card = $('<div class="event-card"></div>')
            .append(self.eventCardDate(event.formatted_date))
            .append(self.eventCardText(event));
      $event_cards = $event_cards.add($card);
    });

    $feed_column.append($event_cards);
    this.$feed_element.addClass('contains-feed');
    this.$feed_element.append($feed_column);
  };

  /**
   * The callback for when feed ajax encountered an error;
   */
  ChapmanEventsFeed.prototype.onFeedError = function(message) {
    this.$feed_element.html("<p>There was a problem loading events.</p>");
  };

  ChapmanEventsFeed.prototype.onFeaturedSuccess = function(data) {
    $featured_event = $('<div class="featured-event event-card"></div>')
        .append(this.eventCardDate(data.formatted_date))
        .append(this.eventCardImg(data))
        .append(this.eventCardText(data));
    this.$featured_element.addClass('contains-featured');
    this.$featured_element.append($featured_event);
  };

  ChapmanEventsFeed.prototype.onFeaturedError = function(message) {
    console.log("There's no featured event for the current events feed.");
  };

  ChapmanEventsFeed.prototype.eventCardDate = function(date) {
    var date_arr = date.split(",");
    // div.day was originally just a styled p tag, but that was causing a WAVE
    // Possible Heading alert.
    var date_html = [
      '<div class="event-date"><div class="date-wrapper">',
      '  <div class="left date-column"><div class="day">'+ date_arr[0] +'</div></div>',
      '  <div class="right date-column"><p>'+ date_arr[1] +'</p><p>'+ date_arr[2] +'</p></div>',
      '</div></div>'
    ];

    return date_html.join('\n');
  };

  ChapmanEventsFeed.prototype.eventCardText = function(event) {
    if(event.location_note){
      var eventLoc = event.location_note;
    } else {
      var eventLoc = event.location;
    }
    var text_content_html = [
      '<div class="text-content">',
        '<h3><a href="'+ event.url +'">'+ event.title +'</a></h3>',
        '<p>' + event.formatted_time + '</p>',
        '<p class="location">' + eventLoc.toLowerCase() + '</p>',
      '</div>'
    ];

    return text_content_html.join('\n');
  };

  ChapmanEventsFeed.prototype.eventCardImg = function(event) {
    var image_div = $('<div class="featured-image"></div>')
          .css('background-image', 'url(' + event.cover_photo + ')');
    return image_div;
  };

  ChapmanEventsFeed.prototype.programCard = function(event) {
    var dates           = event.formatted_date.split(',');
    var $eventLink      = $('<a></a>', { class: 'program-event', href: event.url });
    var $eventTitle     = $('<p></p>', { class: 'program-event__title', text: event.title });
    var $eventDate      = $('<p></p>', { class: 'program-event__date', text: dates[1] + '. ' + dates[0] + ', ' + dates[2] });
    var $eventTime      = $('<p></p>', { class: 'program-event__time', text: event.formatted_time });
    var $dateContainer  = $('<div></div>', { class: 'program-event__date-container' });

    $dateContainer.append($eventDate, $eventTime);
    // $dateContainer.append($eventTime);
    $eventLink.append($eventTitle, $dateContainer);
    $eventLink.append($dateContainer);

    return $eventLink;
  }

  /**
   * The jQuery extention so that we can use this easily.
   */
  $.fn.chapmanEventsFeed = function(options) {
    options.$feed_element = this;
    options.$featured_element = $('[data-chapman-featured-event]');
    this.cef = new ChapmanEventsFeed(options);
    if (this.cef.feed)     { this.cef.fetchFeed(); }
    if (this.cef.featured) { this.cef.fetchFeatured(); }

    this.addClass('chapman-events-feed');
    return this;
  };

})( jQuery );
ChapmanSocialFeed = function(options) {
  this.url               = this.parseUrl(options.url);
  this.$container        = options.$container;
  this.post_width        = options.post_width   || 355;
  this.gutter_width      = options.gutter_width || 20;
  this.max_columns       = options.max_columns  || 4;
  this.animation_queue   = [];
  this.currently_loading = false;
  this.load_more_params  = {
    page:   options.page  || 1,
    per:    options.per   || 30,
    before: this.currentTimeAsParam()
  }

  this.selectors = {
    posts: '.post_tile',
    columns: '.column',
    new_ribbons: '.new_ribbon'
  };

  this.resize_timer = null;
  $(window).on('resize', this.onResize.bind(this));
};


ChapmanSocialFeed.prototype.initialize = function() {
  if (this.$container.children().length == 0) {
    this.$container.html(this.createNewColumns());
    this.loadMore();
  } else { // The first page of social posts has already been loaded
    this.layoutPostsInColumns({animate: true});
    this.load_more_params.page += 1;
  }
};




/***********************************************************************
 * Functions for laying out the posts into columns
 */

ChapmanSocialFeed.prototype.layoutPostsInColumns = function(options) {
  var use_animation   = (options && options.animate);
  var $posts          = (options && options.$posts) ? options.$posts : this.$container.find(this.selectors.posts);
  var scroll_position = $(window).scrollTop();

  this.sortPosts($posts);
  if (use_animation) {
    $posts.css('opacity', 0);
    this.addToAnimationQueue($posts);
  }
  this.$container.html(this.createNewColumns());
  this.appendPosts($posts);
  this.attachPostListeners($posts);
  if (use_animation) {
    this.animatePosts();
  }
  $(window).scrollTop(scroll_position);
};

ChapmanSocialFeed.prototype.sortPosts = function($posts) {
  $posts.sort(function(a, b) {
    return new Date($(b).data('timestamp')) - new Date($(a).data('timestamp'));
  });
};

ChapmanSocialFeed.prototype.detectNumberOfColumns = function() {
  var calculated =  Math.floor(this.$container.width() /  this.post_width);
  if (calculated < 1){
    return 1;
  }
  else if (calculated <= this.max_columns){
    return calculated
  }
  else {
    return this.max_columns;
  }
};

ChapmanSocialFeed.prototype.createNewColumns = function() {
  var column_divs = '';
  for (var i = 0; i < this.detectNumberOfColumns(); ++i) {
    column_divs += '<div class="column" id="social-feed-column-'+i+'"/>';
  }
  return $(column_divs);
};

ChapmanSocialFeed.prototype.appendPosts = function($posts) {
  var $columns = this.$container.find(this.selectors.columns);
  var self = this;
  $posts.each(function() {
    self.appendPostToShortestColumn($(this), $columns);
  });
};

ChapmanSocialFeed.prototype.appendPostToShortestColumn = function($post, $columns) {
  var column_heights = $.map($columns, function(col) { return $(col).height(); });
  var min_index = column_heights.indexOf(Math.min.apply(Math, column_heights));
  $columns.eq(min_index).append($post);
};

ChapmanSocialFeed.prototype.prependPosts = function ($posts) {
  $posts.each(function() { $(this).prepend('<span class="new_ribbon">NEW</span>'); });
  $posts.css('opacity', 0);
  this.addToAnimationQueue($posts);
  $all_posts = this.$container.find(this.selectors.posts).add($posts);
  this.layoutPostsInColumns({$posts: $all_posts});
  this.animatePosts({reverse: true});
};

ChapmanSocialFeed.prototype.attachPostListeners = function($posts) {
  $posts.each(function(){
    if ($(this).hasClass('post_photo')) {
      $(this).find('.view_message').on('mouseenter', function(e){
        $(this).siblings('.message').stop().slideDown(200);
      });
      $(this).find('.message').on('mouseleave', function(e){
        $(this).stop().slideUp(400);
      });
      $(this).on('mouseleave', function(e){
        $(this).children('.message').stop().slideUp(400);
      });
    }
  });
};

ChapmanSocialFeed.prototype.addToAnimationQueue = function($posts) {
  var self = this;
  $posts.each(function(){
    self.animation_queue.push(this.id);
  });
};

ChapmanSocialFeed.prototype.animatePosts = function(options) {
  options = options || {};
  if (this.animation_queue.length === 0) {
    $(this.selectors.posts).css('opacity', 1);  // Just in case we missed some
    return;
  }
  var id = (options.reverse) ? this.animation_queue.pop() : this.animation_queue.shift();
  $('#' + id).css('opacity', 1);
  var self = this;
  setTimeout(function(){ self.animatePosts(options); }, 10);
};

ChapmanSocialFeed.prototype.removeNewRibbons = function() {
  $(this.selectors.new_ribbons).fadeOut(1000);
};




/************************************************************************************
 * Functions for loading more posts from the server
 */

ChapmanSocialFeed.prototype.loadMore = function() {
  if (this.currently_loading) return 'Already Requested';
  this.currently_loading = true;
  var self = this;
  $.ajax({
    url: this.url,
    method: 'get',
    data: self.load_more_params,
    crossDomain: true,
    success: function(posts) {
      var $posts = $(posts);
      $posts.css('opacity', 0);
      self.addToAnimationQueue($posts);
      self.appendPosts($posts);
      self.attachPostListeners($posts);
      self.animatePosts();
      self.load_more_params.page += 1;
      self.currently_loading = false;
    },
    error: function() {
      console.log("Error loading most posts");
    }
  });
};

ChapmanSocialFeed.prototype.currentTimeAsParam = function() {
  var now = new Date();
  return [now.getFullYear(), now.getMonth()+1, now.getDate(), now.getHours().toString() + now.getMinutes().toString()].join("-")
}


/**
  * Converts the url passed in, into the url that we will make our ajax reqest to.
  */
ChapmanSocialFeed.prototype.parseUrl = function(url) {
  var parser  = document.createElement('a');
  parser.href = url;
  parser.pathname += 'feed';
  return parser.href;
}

/***********************************************************************************
 * Event listener functions
 */

ChapmanSocialFeed.prototype.onResize = function(e) {
  var self = this;
  clearTimeout(self.resize_timer);
  self.resize_timer = setTimeout(function() {
    self.layoutPostsInColumns();
  }, 200);
};


/***********************************************************************************
 * The jQuery Function
 */

$.fn.chapmanSocialFeed = function(options) {
  var self = this;
  var feed = new ChapmanSocialFeed($.extend(options, {$container: this}));
  feed.initialize();
  return this;
};
/*
 * Chapman Social Feed jQuery Plugin
 *
 * Based on this pattern:
 * https://github.com/jquery-boilerplate/jquery-boilerplate/blob/master/src/jquery.boilerplate.js
 *
 */
// the semi-colon before function invocation is a safety net against concatenated
// scripts and/or other plugins which may not be closed properly.
;(function($, window, document, undefined) {

  "use strict";

  var pluginName = 'chapmanStoriesFeed';

  // undefined is used here as the undefined global variable in ECMAScript 3 is
  // mutable (ie. it can be changed by someone else). undefined isn't really being
  // passed in so we can ensure the value of it is truly undefined. In ES5, undefined
  // can no longer be modified.

  // window and document are passed through as local variables rather than global
  // as this (slightly) quickens the resolution process and can be more efficiently
  // minified (especially when both are regularly referenced in your plugin).

  // Create the defaults once
  var defaults = {
    feedEndPoint: 'https://social.chapman.edu/',
    baseBlogUrl: 'https://blogs.chapman.edu/',
    feedService: 'wordpress',
    storiesPerPage: 4,

    // The values are expected to be data attributes on the element. The user supplies them
    // via the Cascade interface.
    dataTitle: 'Chapman Stories Feed',
    dataBgColor: null,
    dataButtonLabel: 'View more stories',
    dataButtonUrl: 'https://news.chapman.edu/',
    dataTopStoryUrl: 'https://blogs.chapman.edu/'
  };

  // The actual plugin constructor
  function Plugin(element, options) {
    this.element = element;
    this.$element = $(element);

    // jQuery has an extend method which merges the contents of two or
    // more objects, storing the result in the first object. The first object
    // is generally empty as we don't want to alter the default options for
    // future instances of the plugin
    this.settings = $.extend({}, defaults, options);
    this._defaults = defaults;
    this._name = pluginName;
    this.init();
  }

  // Avoid Plugin.prototype conflicts
  $.extend(Plugin.prototype, {

    init: function() {
      // Data attribute values
      this.feedParams       = {service: this.settings.feedService, per: this.settings.storiesPerPage};
      this.feedUrl          = this.settings.feedEndPoint;
      this.topStoryUrl      = this.$element.data('chapmanStoriesTopStoryUrl');
      this.title            = this.$element.data('chapmanStoriesTitle') || this.settings.dataTitle;
      this.backgroundColor  = this.$element.data('chapmanStoriesBgColor') || this.settings.dataBgColor;
      this.buttonLabel      = this.$element.data('chapmanStoriesButtonLabel') || this.settings.dataButtonLabel;
      this.buttonUrl        = this.$element.data('chapmanStoriesButtonUrl') || this.settings.dataButtonUrl;

      this.parseDataUrl();
      this.buildOutWidget();
    },

    // The url in data attr can either be social.chapman or blogs.chapman
    // The feed enpoint will always be a social.chapman url but now the blogs source can either be specified
    // by params in a social.chapman url or a specific blog
    parseDataUrl: function() {
      var self = this;
      var dataUrl = this.$element.data('chapmanStoriesFeedUrl');

      if(!dataUrl){ return; }

      // if the data attr is a blogs url, it will be set to the source url in the feed params
      if(dataUrl.includes(this.settings.baseBlogUrl)){
        // inside db stores blog urls without trailing slash
        this.feedParams['source'] = dataUrl.replace(/\/?$/, '');
      } else {
        // get any params that are set in data attr url and add/replace them in the feed params hash
        // This avoids having duplicate params in the feedEndPoint URL
        var dataParams = this.parseUrlParams(dataUrl);
        $.each(dataParams, function(param, value){
          self.feedParams[param] = value;
        });
      }
    },

    parseUrlParams: function(url) {
      var domUrlBuilder = document.createElement('a');
      domUrlBuilder.href = url;
      var params = domUrlBuilder.search.substring(1);
      return params ? $.deparam(params) : {};
    },

    buildOutWidget: function() {
      var $outerContainer = this.buildOuterContainer();
      var $topStory = this.buildTopStoryElement();
      var $storiesFeed = this.buildStoriesFeedElement();

      if ( this.backgroundColor ) {
        this.$element.css('backgroundColor', this.backgroundColor);
      }

      this.$element.html($outerContainer);
      $outerContainer.append($topStory);
      $outerContainer.append($storiesFeed);
    },

    buildOuterContainer: function() {
      var $outerContainer = $('<div />').addClass('outer-container');
      var $title = $('<h2 />').addClass('social-feed-title').text(this.title);

      $outerContainer.append($title);
      return $outerContainer;
    },

    buildTopStoryElement: function() {
      var classes = 'feed-column top-story';
      var loadingHtml = '<p>Loading top story...</p>'
      var $topStoryElement = $('<div />').addClass(classes).html(loadingHtml);

      // if top story post is not specified, it will default to the top story based on the feed params
      var topStoryParams = $.extend(true, {}, this.feedParams);
      if(this.topStoryUrl){ topStoryParams['url'] = this.topStoryUrl; }

      // This will return HTML for top story.
      $.ajax({
        method: 'GET',
        url: this.buildSocialApiEndpoint('top_story', topStoryParams),
        success: function(html) {
          // Note: if html comes wrapped in a hidden tag. It will not be displayed.
          // See https://github.com/chapmanu/inside/issues/774 (data comes from Inside/Social).
          if ( html.length ) {
            $topStoryElement.html(html);
          }
        },
        error: function(data) {
          console.error('Unable to load top story:', data);
          $topStoryElement.html("<p>There was a problem loading the top story.</p>");
        }
      });

      return $topStoryElement;
    },

    buildStoriesFeedElement: function() {
      var classes = 'feed-column stories-feed';
      var loadingHtml = '<p>Loading stories...</p>';
      var $storiesElement = $('<div />').addClass(classes).html(loadingHtml);
      var $feedButton = this.buildFeedButton();
      // This will return HTML for top story.
      $.ajax({
        method: 'GET',
        url: this.buildSocialApiEndpoint('feed', this.feedParams),
        data: this.feedParams,
        success: function(data) {
          if ( data.length ) {
            var dataObj = $(data)
            dataObj.find('.post_external_link').remove();
            dataObj.find('footer').remove();
            
            $storiesElement.html(dataObj);
            $storiesElement.append($feedButton);
          }
        },
        error: function(data) {
          console.error('Unable to load stories:', data);
          $storiesElement.html("<p>There was a problem loading stories.</p>");
        }
      });

      return $storiesElement;
    },

    buildFeedButton: function() {
      var $container = $('<div />').addClass('actions');
      var $button = $('<a />').addClass('theme-button');
      $button.attr('href', this.buttonUrl);
      $button.text(this.buttonLabel);
      return $button;
    },

    buildSocialApiEndpoint: function(path, params){
      // Build URL dynamically using DOM.
      var domUrlBuilder = document.createElement('a');
      domUrlBuilder.href = this.feedUrl;
      domUrlBuilder.pathname = path;
      domUrlBuilder.search = $.param(params);
      return domUrlBuilder.href;
    }
  });

  // A really lightweight plugin wrapper around the constructor,
  // preventing against multiple instantiations.
  $.fn[pluginName] = function(options) {
    return this.each(function() {
      if ( !$.data(this, "plugin_" + pluginName) ) {
        $.data(this, "plugin_" + pluginName, new Plugin(this, options));
      }
    });
  };
})(jQuery, window, document);
/**
 * Functions to help determine what size screen we are on.  Make sure these
 * pixel width stay in sync with what we have in our scss variables.
 */


var Media = {
  medium_screen: 768,
  large_screen: 1024
};

Media.smallScreen = function() {
  var screen_size = $(window).width();
  return (screen_size < Media.medium_screen);
};

Media.mediumScreen = function() {
  var screen_size = $(window).width();
  return (screen_size >= Media.medium_screen && screen_size < Media.large_screen);
};

Media.largeScreen = function() {
  var screen_size = $(window).width();
  return (screen_size >= Media.largeScreen);
};
/**
 * CU UTILS MODULE
 *
 *
 * Keep all useful helper utility functions in here.
 *
 *
 *
 */


var utils = {

	/**
	 * Convert month format from numbers to abbreviation
	 */
	toShortMonthName: function (month) {
		switch (parseInt(month)) {
			case 1:
				return 'JAN';
			case 2:
				return 'FEB';
			case 3:
				return 'MAR';
			case 4:
				return 'APR';
			case 5:
				return 'MAY';
			case 6:
				return 'JUN';
			case 7:
				return 'JULY';
			case 8:
				return 'AUG';
			case 9:
				return 'SEPT';
			case 10:
				return 'OCT';
			case 11:
				return 'NOV';
			case 12:
				return 'DEC';
			default:
				return '';
		}
	},

	/**
	 * Convert month format from 2-digit (leading zero) string to abbreviation
	 */
	toShortMonthName_fromstring: function(month) {
		switch (month) {
			case '01':
				return 'JAN';
			case '02':
				return 'FEB';
			case '03':
				return 'MAR';
			case '04':
				return 'APR';
			case '05':
				return 'MAY';
			case '06':
				return 'JUN';
			case '07':
				return 'JULY';
			case '08':
				return 'AUG';
			case '09':
				return 'SEPT';
			case '10':
				return 'OCT';
			case '11':
				return 'NOV';
			case '12':
				return 'DEC';
			default:
				return '';
		}
	},

	/**
	 * Pad day with leading zero
	 */
	pad2: function(number) {
		return (number < 10 ? '0' : '') + number;
	},

	ios: function() {
		var user_agent = window.navigator.userAgent.toLowerCase();
		return /iphone|ipod|ipad/.test(user_agent);
	}
};
var chapDOM = (function () {
  var validAttr = ['src', 'alt', 'href', 'data-cta-label', 'aria-label', 'style'];
  'use strict';
  /**
   * Create the constructor
   * @param {String} selector The selector to use
   */
  var Constructor = function (selector) {

    if (!selector) return;

    if (selector === 'document') {
      this.elems = [document];
    } else if (selector === 'window') {
      this.elems = [window];
    } else {
      this.elems = document.querySelectorAll(selector);
    }
  };

  /**
   * Run a callback on each item
   * @param  {Function} callback The callback function to run
   */
  Constructor.prototype.each = function (callback) {
    if (!callback || typeof callback !== 'function') return;
    for (var i = 0; i < this.elems.length; i++) {
      callback(this.elems[i], i);
    }

    return this;
  };

  /**
   * Add a class to elements
   * @param {String} className The class name
   */
  Constructor.prototype.addClass = function (className) {
    if (!this.elems.length) return;

    this.each(function (item) {
      item.classList.add(className);
    });

    return this;
  };

  /**
   * Change the html element attribute
   * @param {String} type The html attribute
   * @param {String} data Value to set the html attribute to
   */
  Constructor.prototype.changeAttr = function (type, data) {
    if (!this.elems.length) return

    if (typeof data !== 'string' && !validAttr.includes(type)) return;

    if (this.elems.length > 1) {
      this.each(function (elem) {

        elem.setAttribute(type, data);
      });
      return this;
    }

    this.elems[0].setAttribute(type, data);

    return this;
  }
  /**
   * Change the html text
   * @param {String} text Value to set the inner html for the element to
   */
  Constructor.prototype.changeText = function (text) {
    if (!this.elems.length) return

    if (typeof text !== 'string') return;

    if (this.elems.length > 1) {
      this.each(function (elem) {
        elem.innerHTML = text;
      });
      return this;
    }

    this.elems[0].textContent = text;
    return this;
  }

  /**
   * Remove a class to elements
   * @param {String} className The class name
  */
  Constructor.prototype.removeClass = function (className) {
    if (!this.elems.length) return;
    this.each(function (item) {
      item.classList.remove(className);
    });

    return this;
  };

  Constructor.prototype.hide = function () {
    if (!this.elems.length) return;

    if (this.elems.length > 1) {
      this.each(function (elem) {
        elem.style.display = 'none';
      });
      return this;
    }

    this.elems[0].style.display = 'none';
    return this;
  }

  /**
   * Instantiate a new constructor
   */
  var instantiate = function (selector) {
    return new Constructor(selector);
  };

  /**
   * Return the constructor instantiation
   */
  return instantiate;

})();
$(function () {
  var byTheNumberscounted = {};

  checkDisplay();

  $(window).on('resize scroll',
    function () {
      checkDisplay();
    });

  function checkDisplay() {

    $('.counter').each(function(idx) {
      var $this = $(this),
          countTo = $this.attr('data-count');
      
      if( $this.isOnScreen() && !byTheNumberscounted['counter' + idx] ) {
        byTheNumberscounted['counter' + idx] = true;

        if (isNaN(countTo)) {
          $this.text(countTo);
          return;
        }

        $({ countNum: $this.text() }).animate({
          countNum: countTo
        },
        {
          duration: 2500,
          easing:'linear',
          step: function() {
            $this.text(Math.floor(this.countNum));
          },
          complete: function() {
            $this.text(this.countNum);
          }
        });  
      }
    });
  }
});

/**
 * Runs on Document ready
 */

$(document).ready(function() {
  $('[data-chapman-events-feed]').each(function() {
    $(this).chapmanEventsFeed({ 
      feed_path: $(this).data('chapman-events-feed'),
      featured_path: $('[data-chapman-featured-event]').data('chapman-featured-event'),
      per: 2
    });
  });
});
$(document).ready(function() {
	$('.chapman-stories-feed-widget').chapmanStoriesFeed();
});
var EmergencyAlert = (function() {
  // Module Vars
  var emergencyAlertDiv,
      alertMessage,
      raveFeed,
      noEmergencyMessage,
      isEmergency = false;

  // Module Functions
  var initialize = function() {
    emergencyAlertDiv = $('div.emergency-alert');
    alertMessage = $('div.alert-message').text();
    // Imposter test & Local Test urls
    // raveFeed = 'https://imposter.chapman.edu/rave.rss';
    // raveFeed = 'http://localhost:3000/rave.rss';
    // raveNotificationFeed = 'http://localhost:3000/rave_notification.rss';
    
    raveFeed = 'https://content.getrave.com/rss/chapman/channel2';
    raveNotificationFeed = 'https://content.getrave.com/rss/chapman/channel3';
    
    noNotificationMessage = 'There is currently no notification';
    noEmergencyMessage = "There is currently no emergency"; // current Rave message for no emergency

    // If there is already a message (comes from data def in Cascade),
    // don't override the HTML with Rave feed
    if (alertMessage.trim() != '') {
      displayEmergencyAlert();
    }
    else {
      $.ajax({
        url: raveFeed,
        type: 'GET',
        success: function(data) {
          $(data).find("item").each(function () {
            var title = $(this).find("title").text();
            // Looks for absence of the "no emergency" message
            isEmergency = title.indexOf(noEmergencyMessage) < 0;
          });
          
          if(isEmergency) {
            displayEmergencyAlert();
            fillRaveFeedData(data);
            return;
          }

          $.ajax({
            url: raveNotificationFeed,
            type: 'GET',
            success: function(data) {
              $(data).find("item").each(function () {
                var title = $(this).find("title").text();
                // Looks for absence of the "no notification" message
                isNotification = title.indexOf(noNotificationMessage) < 0;
              });
              
              if(isNotification) {
                displayNotification();
                fillRaveFeedData(data);
                return
              }
            }
          })
        }
      });
    }
  };

  var displayEmergencyAlert = function() {
    emergencyAlertDiv.show();
    var trigger = $('.close-alert-trigger');
    addCloseTrigger(trigger);
  };

  var displayNotification = function() {
    var $notificationLink = $("<a>", {
      href: "https://www.chapman.edu/notices",
      text: 'chapman.edu/notices'
    });
    $('.emergency-alert').addClass('notification');
    $('.alert-heading').text('Chapman Notice');
    $('.alert-link').text('For more information and frequent updates, visit: ');
    $('.alert-link').append($notificationLink);
    $('#icon-warning').remove();
    $('.alert-text').prepend(
      "<svg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' version='1.1' id='icon-warning' x='0px' y='0px' viewBox='0 0 246.027 246.027' style='enable-background:new 0 0 32 32;' xml:space='preserve' width='32px' height='32px'><path d='M242.751,196.508L143.937,25.358c-4.367-7.564-12.189-12.081-20.924-12.081c-8.735,0-16.557,4.516-20.924,12.081  L3.276,196.508c-4.368,7.564-4.368,16.596,0,24.161s12.189,12.081,20.924,12.081h197.629c8.734,0,16.556-4.516,20.923-12.08  C247.119,213.105,247.118,204.073,242.751,196.508z M123.014,204.906c-8.672,0-15.727-7.055-15.727-15.727  c0-8.671,7.055-15.726,15.727-15.726s15.727,7.055,15.727,15.726C138.74,197.852,131.685,204.906,123.014,204.906z M138.847,137.68  c0,8.73-7.103,15.833-15.833,15.833s-15.833-7.103-15.833-15.833V65.013c0-4.142,3.358-7.5,7.5-7.5h16.667  c4.143,0,7.5,3.358,7.5,7.5V137.68z' fill='#FFFFFF'/></svg>"
    );

    emergencyAlertDiv.show();
    var trigger = $('.close-alert-trigger');
    addCloseTrigger(trigger);
  }

  var addCloseTrigger = function(trigger) {
    trigger.on('click', function() {
      emergencyAlertDiv.slideUp("slow");
    });
  };

  var fillRaveFeedData = function(data) {
    // There should really only be 1 item in the feed at any given time
    // See imposter.chapman.edu for sample feeds
    $(data).find("item").each(function () {
      var item = $(this);
      var raveFeedDescription = item.find("description").text();
      emergencyAlertDiv.find('div.alert-message').html(raveFeedDescription);
      var raveFeedTitle = item.find("title").text();
      emergencyAlertDiv.find('div.alert-title').html(raveFeedTitle);
    });
  };

  return {
    init: initialize
  };
})();

$(document).ready(function() {
  // Only load on homepage
  if($('.homepage').length) {
    EmergencyAlert.init();
  }
});
$(document).ready(function(){
  var trigger = $('.hero-select-button');
  var list    = $('.hero-select-list');
  var highlighted;

  var highlight = function(i) {
    highlighted = $(i);
    highlighted.addClass('selected').siblings('.selected').removeClass('selected');
  };

  trigger.on('click', function() {
    // trigger.toggleClass('active');
    list.slideToggle(200);
  });

  $('.hero-select-list li').on('hover', function() {
    highlight(this);
  });

  $(document).on('click', function(event) {
    if(trigger[0] !== event.target && !list.has(event.target).length) {
      list.slideUp(200);
    }
  });
});
$(document).ready(function () {
  var cachedNewsroomFeed = 'https://www.chapman.edu/getFeed.ashx?name=newsEditorsPicks';

  var $selectors = {
    featuredStory: {
      tag:          new chapDOM('.homepage #featured_newsroom_stories .maxWidth .announcement .tag'),
      img:          new chapDOM('.homepage #featured_newsroom_stories .maxWidth .announcement img'),
      h2Link:       new chapDOM('.homepage #featured_newsroom_stories .maxWidth .announcement h2 a'),
      description:  new chapDOM('.homepage #featured_newsroom_stories .maxWidth .announcement #featured-description')
    },
    stories: (function() {
      var storySelectors = []
      for(var i = 1; i <= 3; i++) {
        var selector = {
          main:       new chapDOM('.homepage .third .story.story-' + i),
          tag:        new chapDOM('.homepage .third .story.story-' + i + ' a.tag'),
          permaLink:  new chapDOM('.homepage .third .story.story-' + i + ' a.permalink'),
          h2Title:    new chapDOM('.homepage .third .story.story-' + i + ' a.permalink h2.title'),
          bgImg:      new chapDOM('.homepage .third .story.story-' + i + ' .story-bg'),
          img:        new chapDOM('.homepage .third .story.story-' + i + ' img')
        }
        storySelectors.push(selector);
      }
      return storySelectors
    })(),
    style: {
      featured:     new chapDOM('.homepage .editors-picks.stories .maxWidth .announcement'),
      stories:      new chapDOM('.homepage .editors-picks.stories .maxWidth .third'),
      loadingIcon:  new chapDOM('.homepage .editors-picks.stories .maxWidth .lds-spinner')
    }
  };

  var xhrTimer = setTimeout(function() {
    if (xhr && xhr.readyState != 4) {
      xhr.abort();
    }
    clearLoader();
  }, 3000);

  function clearLoader() {
    $selectors.style.loadingIcon.hide();
    $selectors.style.featured.removeClass('news-loading');
    $selectors.style.featured.addClass('news-loaded');
    $selectors.style.stories.removeClass('news-loading');
    $selectors.style.stories.addClass('news-loaded');
  }

  function decodeEntities(encodedString) {
    var textArea = document.createElement('textarea');
    textArea.innerHTML = encodedString;

    return textArea.value;
  }

  function trimDescription(description, title) {
    var descriptionNoHTML = description.trim().replace(/(<([^>]+)>)/ig, ""),
      descriptionNoHTMLLength = descriptionNoHTML.length,
      titleLength = title.length;

    descriptionNoHTML = decodeEntities(descriptionNoHTML);

    if (descriptionNoHTMLLength > 505 && titleLength < 30) {
      descriptionNoHTML = descriptionNoHTML.substring(0, descriptionNoHTML.indexOf(" ", 500) < 0 ? 501 : descriptionNoHTML.indexOf(" ", 500));
      descriptionNoHTML = descriptionNoHTML + '...';
      return descriptionNoHTML;
    }

    if (descriptionNoHTMLLength > 405 && titleLength < 60) {
      descriptionNoHTML = descriptionNoHTML.substring(0, descriptionNoHTML.indexOf(" ", 400) < 0 ? 401 : descriptionNoHTML.indexOf(" ", 400));
      descriptionNoHTML = descriptionNoHTML + '...';
      return descriptionNoHTML;
    }

    if (descriptionNoHTMLLength > 205 && titleLength > 60) {
      descriptionNoHTML = descriptionNoHTML.substring(0, descriptionNoHTML.indexOf(" ", 200) < 0 ? 201 : descriptionNoHTML.indexOf(" ", 200));
      descriptionNoHTML = descriptionNoHTML + '...';
      return descriptionNoHTML;
    }

    return descriptionNoHTML;
  }

  function updateWidgetStories(newsStories) {
    newsStories.forEach( function(story, idx) {
      if (idx === 0) {
        $selectors.featuredStory.tag.changeAttr('href', story.primary_category_link);
        $selectors.featuredStory.tag.changeText('#' + decodeEntities(story.primary_category));
        $selectors.featuredStory.img.changeAttr('src', story.post_image);
        $selectors.featuredStory.img.changeAttr('alt', story.post_image_alt);
        $selectors.featuredStory.h2Link.changeAttr('href',story.post_url);
        $selectors.featuredStory.h2Link.changeAttr('data-cta-label', story.post_title_excerpt || story.post_title);
        $selectors.featuredStory.h2Link.changeText(story.post_title_excerpt || story.post_title);
        $selectors.featuredStory.description.changeText(trimDescription(story.featured_description_excerpt || story.featured_description, story.post_title_excerpt || story.post_title));

        return
      }
      
      $selectors.stories[idx - 1].tag.changeAttr('href', story.primary_category_link);
      $selectors.stories[idx - 1].tag.changeText('#' + decodeEntities(story.primary_category));

      $selectors.stories[idx - 1].main.changeAttr('aria-label', story.post_title_excerpt || story.post_title);
      $selectors.stories[idx - 1].permaLink.changeAttr('href', story.post_url);
      $selectors.stories[idx - 1].permaLink.changeAttr('data-cta-label', story.post_title_excerpt || story.post_title);
      $selectors.stories[idx - 1].h2Title.changeText(story.post_title_excerpt || story.post_title);
      $selectors.stories[idx - 1].bgImg.changeAttr('style', 'background-image:url(' + story.post_image + ')');
      $selectors.stories[idx - 1].bgImg.changeAttr('aria-label', story.post_image_alt);
      $selectors.stories[idx - 1].img.changeAttr('alt', story.post_image_alt);
      $selectors.stories[idx - 1].img.changeAttr('src', story.post_image);
    });
    clearTimeout(xhrTimer);
    clearLoader();
  }

  function clearImages() {
    $selectors.featuredStory.img.changeAttr('src', '');
    $selectors.stories.forEach( function(story) {
      story.bgImg.changeAttr('style', '');
      story.img.changeAttr('src', '');
    })
  }

  var xhr = $.get(cachedNewsroomFeed, function (data) {
    if (data.post_count != 4 && data.posts.length != 4) return;

    clearImages();
    updateWidgetStories(data.posts);
  });
});
$(document).ready(function () {
  $(".widget-slides").lightSlider({
    gallery: false,
    item: 1,
    thumbItem: 9,
    slideMargin: 0,
    speed: 500,
    pause: 10000,
    auto: true,
    loop: true,
    keyPress: true,
    pauseOnHover: false,
    adaptiveHeight: true,
    // useCSS: true,
    onSliderLoad: function () {
      $(".widget-slides").removeClass("cS-hidden");
    }
  });

  // IE Fallback for widget-slides img { object-fit: } CSS property 
  if (document.documentMode || /Edge/.test(navigator.userAgent)) {
    $('.image-slider-wrapper img').each(function () {
      var t = $(this),
        s = 'url(' + t.attr('src') + ')',
        p = t.parent(),
        d = $('<div></div>');

      p.append(d);
      d.css({
        'height': t.parent().css('height'),
        'background-size': 'cover',
        'background-repeat': 'no-repeat',
        'background-position': '50% 20%',
        'background-image': s
      });
      t.hide();
    });
  }
});
/*
 * messaging_1_column.js
 *
 * The following module (Messaging1Column), or object, is used to define
 * features and logic used within the messaging 1-column widgets: 
 * "Text Widget", "Text with Image Widget" and "Text with Video Widget".
 */


var Messaging1Column = Messaging1Column || {};

(function ($, document, window) {

  'use strict';

  Messaging1Column.select = {

    speed: 200,

    elem: {
      $trigger: null
    },

    init: function () {

      // Cached selectors
      this.elem.$trigger = ($('.text-widget-select').length > -1) ? $('.text-widget-select') : null;

      if (this.elem.$trigger !== null) {
        this.bindUIActions();
      }

    },

    bindUIActions: function () {

      // Delegated events
      this.elem.$trigger.on('click', '.select-button', this.toggle.bind(this));

      $(document).on('click', this.close.bind(this));

    },

    close: function (e) {

      var $button = this.elem.$trigger.find('.select-button');
      var $list = $button.parent().find('.select-list');

      if (!$button.is(e.target) && $button.has(e.target).length === 0) {
        $list.slideUp(this.speed);
      }

    },

    toggle: function (e) {

      var $target = $(e.target);

      $target.toggleClass('active');
      $target.parent().find('.select-list').slideToggle(this.speed);

    }

  };

}(window.jQuery, window.document, window));

$(document).ready(function () {

  'use strict';

  Messaging1Column.select.init();

});
var Messaging2Column = {};

Messaging2Column.resize_timer =  null;

Messaging2Column.centerMessagingMedia = function() {
  clearTimeout(Messaging2Column.resize_timer);
  Messaging2Column.resize_timer = setTimeout(function(){
    $('.messaging-widget.messaging-widget__2-column').each(function() {
      var $text  = $(this).find('.text-column');
      var $media = $(this).find('.media-column');
      $media.css('height', 'auto');
      var text_height  = $text.height();
      var media_height = $media.height();

      if (Media.smallScreen() || text_height === media_height)
        return;
      if (media_height < text_height)
        $media.css('height', $text.height());
    });
  }, 0);
};


// Initialize
$(document).ready(function() {Messaging2Column.centerMessagingMedia(); });
$(window).on('resize', Messaging2Column.centerMessagingMedia);
$(window).load(function () {
    if ($('.optanon-alert-box-wrapper, #optanon').length) {
        $('.optanon-alert-box-wrapper, #optanon').attr('role', 'contentinfo')
    }
});
/*
 * personnel.js
 *
 * Javascript associated specifically with personnel widget, which can be found on this page:
 *
 * https://www.chapman.edu/admission/undergraduate/contact-us/index.aspx
 */

var personnelWidget = (function() {

    // Constants

    // Global Attrs: undefined values will be set on document ready.
    var $omninav = undefined;
    var omninavPresent = undefined;
    var omninavHeight = undefined;
    var $personnelListingWidget = undefined;
    var personnelListingWidgetPresent = undefined;
    var urlHashFragment = undefined;

    // Public Methods
    var initOnDocumentReady = function() {
        // Set undefined globals.
        $omninav = $('#cu_nav');
        omninavPresent = $omninav.length > 0;
        omninavHeight = omninavPresent ? $omninav.outerHeight() : null;

        $personnelListingWidget = $('div.personnel-listing-widget');
        personnelListingWidgetPresent = $personnelListingWidget.length > 0;

        urlHashFragment = window.location.hash;

        repositionForAnchorLink();
    }

    // Private Methods
    var repositionForAnchorLink = function() {
        /* This was added for this issue: https://github.com/chapmanu/cascade-assets/issues/129
         *
         * It is an approach that seems vulnerable to race conditions among loading elements and
         * I am not in love with this solution but I don't know of a better one at moment.
         *
         * When a user visits URL such as:
         * https://www.chapman.edu/admission/undergraduate/contact-us/index.aspx#jane-doe
         * Page needs to be reposition to make sure omninav does not cut off anchor point.
         */
        // Don't bother unless both these elements are present on page.
        if ( ! (omninavPresent && personnelListingWidgetPresent && urlHashFragment) ) {
            return false;
        }

        // Delay to give other page elements a change to load.
        var repositionDelay = 500;

        // Pull anchor identifer from URL hash.
        var anchorIdentifer = urlHashFragment.slice(1);

        // Identify target
        var targetSelector = 'span#' + anchorIdentifer
        var $target = $(targetSelector);

        // If target present, reposition page.
        if ( $target.length ) {
            var newTopPosition = $target.offset().top - omninavHeight;

            // Wait for other dynamic elements of page to load or it won't scroll to correct spot.
            setTimeout(function() {
                var newTopPosition = $target.offset().top - omninavHeight;
                $("body, html").animate({scrollTop: newTopPosition}, 1000);
            }, repositionDelay);
        }
    }

    // Public API
    return {
        init: initOnDocumentReady
    };
})();

$(document).ready(function() {
    personnelWidget.init();
});
$(document).ready(function() {
  var $programEvents = $('[data-chapman-program-events]');
  
  if (!$programEvents.length) return;
  $programEvents.chapmanEventsFeed({ 
    feed_path: $programEvents.data().chapmanProgramEvents,
    program_events: true,
    per: 200
  });
});
$(document).ready(function() {
  var $rssFeedContainer = document.querySelector('.rss-feed-display-widget')

  // NO RSS FEED WIDGET ON PAGE
  if (!$rssFeedContainer) return;

  var rssFeedItemColor = $rssFeedContainer.getAttribute('data-bg-color'),
  rssFeedUrl           = $rssFeedContainer.getAttribute('data-rss-feed');

  if (!rssFeedUrl.length) return;

  // SHOULD BUILD OUT FOR MORE ROBUST DATES CURRENTLY ONLY ACCEPTS WORDPRESS STYLE RSS FEED DATE FORMAT NOT SURE WHAT RSS FEED STANDARD IS FOR pubDate
  function createFeedItemDateTime(rssFeedItemDate, type) {
    switch(type) {
      case 'wordpress':
        var months  = ['Jan.', 'Feb.', 'Mar.', 'Apr.', 'May', 'Jun.', 'Jul.', 'Aug.', 'Sept.', 'Oct.', 'Nov.', 'Dec.'],
        date        = Date.parse(rssFeedItemDate),
        month       = months[new Date(date).getMonth()],
        dayOfMonth  = new Date(date).getDate(),
        year        = new Date(date).getFullYear(),
        hour        = new Date(date).getHours() > 12 ? new Date(date).getHours() - 12 : new Date(date).getHours(),
        minute      = new Date(date).getMinutes() < 10 ? '0' + new Date(date).getMinutes() : new Date(date).getMinutes(),
        ampm        = new Date(date).getHours() > 12 ? 'p.m.' : 'a.m.';

        if (hour == 0 || hour == 00)
          hour = 12
    
        return {date: month + ' ' + dayOfMonth + ', ' + year, time: hour + ':' + minute + " " + ampm};
      default:
        return rssFeedItemDate;
    }
  }

  function displayMoreRssItems() {
    var hiddenRssItems = $rssFeedContainer.querySelectorAll('.hidden-rss-item'),
    i = 0;

    while(i < 4) {
      hiddenRssItems[i].classList.remove('hidden-rss-item');
      hiddenRssItems[i].classList.add('rss-feed-item__container');
      hiddenRssItems[i].classList.add('bg-color--' + rssFeedItemColor);
      i++;
    }
  }

  function cleanTrimText(text, maxLength) {
    var cleanText = text.trim().replace(/(<([^>]+)>)/ig, ''),
    textArea      = document.createElement('textarea');

    if (cleanText.length > maxLength) {
      // IF THERE IS NO SPACE AFTER THE LAST CHARACTER OF MAX LENGTH MAX LENGTH IS SECOND TO LAST WORD
      cleanText = cleanText.substring(0, cleanText.indexOf(" ", maxLength) < 0 ? maxLength + 1 : cleanText.indexOf(" ", maxLength));
      cleanText = cleanText + '...'
    }

    // DECODE UNICODE CHARACTERS SEE SO 
    // https://stackoverflow.com/questions/7394748/whats-the-right-way-to-decode-a-string-that-has-special-html-entities-in-it/7394787
    textArea.innerHTML = cleanText;

    return textArea.value;
  }

  // GET RSS FEED DATA FROM NODE PARSER APPLICATION
  $.getJSON("https://social04.chapman.edu:4040/data?url=" + rssFeedUrl, function (data) {
    var feedItems      = data[0].item;
    $rssFeedItemButton = document.createElement('button');
    $rssFeedItemButton.className = 'rss-feed-display-widget__button button--' + rssFeedItemColor;
    $rssFeedItemButton.innerHTML = 'View More';

    $rssFeedItemButton.addEventListener('click', displayMoreRssItems)

    if (!feedItems.length) {
      var $emptyFeed = document.createElement('p');
      $emptyFeed.innerHTML = 'There are no items to display in the feed.'
      $rssFeedContainer.appendChild($emptyFeed);
      return;
    }

    feedItems.forEach(function(feedItem, idx) {
      var feedItemDate        = createFeedItemDateTime(feedItem.pubDate[0], 'wordpress'),
      feedItemDescription     = cleanTrimText(feedItem.description[0], 100);

      // CREATE RSS FEED HTML ELEMENTS
      var $feedItemContainer        = document.createElement('div'),
      $feedItemDescriptionContainer = document.createElement('div'),
      $feedItemDescription          = document.createElement('p'),
      $feedItemLink                 = document.createElement('a'),
      $feedItemDateContainer        = document.createElement('div'),
      $feedItemDate                 = document.createElement('p'),
      $feedItemTime                 = document.createElement('p');

      // ADDED CSS CLASS TO FIRST FOUR RSS DIPSLAY ELEMENTS IN FEED 
      // HIDE THE REST ADD APPROPRIATE CLASSES TO EACH ELEMENT
      $feedItemContainer.className            = idx < 4 ? 'rss-feed-item__container bg-color--' + rssFeedItemColor :'hidden-rss-item';
      $feedItemDescriptionContainer.className = 'rss-feed-item__description-container';
      $feedItemDescription.className          = 'rss-feed-item__description-text';
      $feedItemLink.className                 = 'rss-feed-item__link text--link';
      $feedItemDateContainer.className        = 'rss-feed-item__date-container';
      $feedItemDate.className                 = 'rss-feed-item__date text__bold';
      $feedItemTime.className                 = 'rss-feed-item__time';

      // ADDED INNER TEXT, DATE, AND TIME TO APPOPRIATE RSS DISPLAY ELEMENTS
      $feedItemDescription.innerHTML  = feedItemDescription;
      $feedItemLink.innerHTML         = feedItem.title[0];
      $feedItemDate.innerHTML         = feedItemDate.date;
      $feedItemTime.innerHTML         = feedItemDate.time;

      $feedItemLink.setAttribute('href', feedItem.link[0]);

      // APPENDING APPROPRIATE RSS ITEMS TO ELEMENTS AND THEN CONTAINER
      $feedItemDateContainer.appendChild($feedItemDate)
      $feedItemDateContainer.appendChild($feedItemTime)
      $feedItemDescriptionContainer.appendChild($feedItemLink)
      $feedItemDescriptionContainer.appendChild($feedItemDescription)
      $feedItemContainer.appendChild($feedItemDateContainer)
      $feedItemContainer.appendChild($feedItemDescriptionContainer)
      $rssFeedContainer.appendChild($feedItemContainer);

    });

    $rssFeedContainer.append($rssFeedItemButton);
    return;

  }).done(function (data) {

  }).fail(function (data) {
    var $emptyFeed = document.createElement('p');
    $emptyFeed.innerHTML = 'There are no items to display in the feed.'
    $rssFeedContainer.appendChild($emptyFeed);
    return;
  });
});
$(document).ready(function(){
	var slider = $("#sponsor-bar .carousel-container"),
		  listItems = slider.find('.sponsor-list').children(),
			numItems = listItems.length,
			itemWidth = numItems > 0 ? 134 : 0,
			itemLimit = 6,
			slideControls = $();

	slider.jcarousel({
		buttonNextHTML: "<div class='control jcarousel-next icon-circle-right'></div>",
		buttonPrevHTML: "<div class='control jcarousel-prev icon-circle-left'></div>",
		scroll: 1,
		wrap: "both",
		visible: getVisibleItems(),
		itemFallbackDimension: 95,
		initCallback: function (carousel) {
			slideControls = slider.find('.control');
			carousel.options.visible == numItems? slideControls.hide() : slideControls.show();
		},
		reloadCallback: (function(carousel){
			carousel.options.visible = getVisibleItems();
			carousel.options.visible == numItems? slideControls.hide() : slideControls.show();
		})
	});

	function getVisibleItems() {
		var maxItems = Math.floor(((slider.width() - 100) / itemWidth)); //subtracting width of control buttons

		if(maxItems < 1) maxItems = 1;
		if(maxItems > numItems) maxItems = numItems;
		if(maxItems > itemLimit) maxItems = itemLimit;

		return maxItems;
	}
});
// $(document).ready(function() {
//     var trigger = $('.dropbtn');
//     var list = $('.dropdown-content');
//     var highlighted;

//     var highlight = function(i) {
//         highlighted = $(i);
//         highlighted.addClass('selected').siblings('.selected').removeClass('selected');
//     };

//     trigger.on('click', function() {
//         // trigger.toggleClass('active');
//         list.slideToggle(200);
//     });

//     $('.dropdown-content li').on('hover', function() {
//         highlight(this);
//     });

//     $(document).on('click', function(event) {
//         if (trigger[0] !== event.target && !list.has(event.target).length) {
//             list.slideUp(200);
//         }
//     });
// });

/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */

function dropdownToggle() {
  document.getElementById("mastheadDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function (event) {
  if (!event.target.matches('.dropdown-inner')) {

    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
;
$(document).ready(function() {
  $('.campaign-monitor-forms input').attr('placeholder', 'Your email address...');
});
var TabsWidget = {};

TabsWidget.onTabClicked = function() {
  var $widget      = $(this).closest('.tabs-widget');
  var $navItem     = $(this);
  var $contentItem = $widget.find('.tabs-content > li:eq(' + $navItem.index() + ')');

  $navItem.addClass('active');
  $navItem.siblings().removeClass('active');
  
  $contentItem.addClass('active');
  $contentItem.siblings().removeClass('active');
};

$(function() {
  $tabNavLi = $('.tabs-widget .tabs-nav > li');
  $tabNavLi.on('click', TabsWidget.onTabClicked);

  $tabNavLi.keydown(function(e) {
    if (e.keyCode === 32 || e.keyCode === 13) {
      TabsWidget.onTabClicked.call(e.currentTarget);
      return false
    }
  })
})
;
$(function () {
  if ($('.testimonial-widget').length) {
    $('.testimonial-widget').slick({
      arrows: true,
      centerPadding: "0px",
      dots: true,
      slidesToShow: 1,
      infinite: false,
      adaptiveHeight: false,
      variableWidth: false,
      accessibility: true
    });
    $('.testimonial-widget__button--left').click(function () {
      $(this).closest('.testimonial-widget').slick('slickPrev');
    });
    $('.testimonial-widget__button--right').click(function () {
      $(this).closest('.testimonial-widget').slick('slickNext');
    });
    // The plugin is not fully accessible (despite its claims) when there are links within a slide. Instead, it sets tabindex to -1 for slides not currently visible.  
    // On tab (within .testimonial-widget)
    $('.testimonial-widget').keyup(function (e) {
      var code = (e.keyCode ? e.keyCode : e.which);
      if (code == 9) {
        // Add tabindex 0 to a elements
        $(".testimonial-widget a").each(function (i) {
          $(this).attr('tabindex', '0');
        });
      }
    });

    $(".testimonial-widget .slick-dots").each(function (i) {
      $(this).parent().addClass('testimonial-widget__slick-dots--margin-bottom')
    });
  };
  $('.testimonial-widget__cta:has(.button)').addClass('testimonial-widget__cta--button');

  // IE Fallback for widget-slides img { object-fit: } CSS property 
  if (document.documentMode || /Edge/.test(navigator.userAgent)) {
    $("img.contact-profile-widget__img").each(function () {
      var t = $(this),
        s = "url(" + t.attr("src") + ")",
        p = t.parent(),
        d = $("<div class='ie__fallback--object-fit'></div>");
      t.hide();
      p.append(d);
      d.css({
        height: 150,
        "background-size": "cover",
        "background-repeat": "no-repeat",
        "background-position": "center",
        "background-image": s
      });
    });
  }
});


var $buoop = {
  required: {
    i: 11,
    e: 15,
    f: 52,
    o: 44,
    s: 10.1,
    c: 57
  },
  insecure: true,
  api: 2019.10,
  url: "https://www.chapman.edu/upgrade-browser.aspx",
  shift_page_down: true,
  onshow: function () {
    var e = document.getElementsByTagName('b')[0];
    var d = document.createElement('strong');
    d.innerHTML = e.innerHTML;
    d.classList.add('buorg-mainmsg');

    e.parentNode.replaceChild(d, e);
  }
};

function $buo_f() {
  var e = document.createElement("script");
  e.src = "//browser-update.org/update.min.js";
  document.body.appendChild(e);
};
try {
  document.addEventListener("DOMContentLoaded", $buo_f, false)
} catch (e) {
  window.attachEvent("onload", $buo_f)
}
;
var FactCard = function($el) {
  this.$root  = $el;
  this.$front = $el.find('.fact-front');
  this.$back  = $el.find('.fact-back');
};

FactCard.prototype.initialize = function() {
  var self = this;

  // Hover Listeners
  if (!utils.ios()) { // iOS translates mouseleave to clicks, lame :(
    this.$root.on('mouseenter, focusin', function(e) { $(this).addClass('flipped'); });
    this.$root.on('mouseleave, focusout', function(e) { $(this).removeClass('flipped'); });
  }

  // Tap listeners
  this.$front.hammer().bind('tap', function(e) { 
    self.$root.addClass('flipped'); 
  });

  this.$back.hammer().bind('tap', function(e) {
    if (!$(event.target).closest('a').length) // Ensure that a link wasn't tapped
      self.$root.removeClass('flipped');
  });
};

$(document).ready(function() {
  $('.fact-card').each(function() { new FactCard($(this)).initialize(); });
});
var SidePanelHeroVideo = {};

SidePanelHeroVideo.resize = function(e) {
  var $video      = $('#background-video');
  var $parent     = $video.parent();
  var videoRatio  = 1.7777777778;
  var parentRatio = $parent.width() / $parent.height();

  if (parentRatio >= videoRatio)
    $video.width('100%');
  else
    $video.width($parent.height() * videoRatio);
};

SidePanelHeroVideo.listen = function() {
  var timeoutId;

  $(window).on('resize', function(e) {
    if (timeoutId) clearTimeout(timeoutId);
    timeoutId = setTimeout(SidePanelHeroVideo.resize, 40);
  });

  $(document).on('ready', SidePanelHeroVideo.resize);
};

SidePanelHeroVideo.listen();
$(document).ready(function () {
  $('.skip-link').on("keydown click", function (e) {
    //Spacebar or Enter Key
    if ((e.keyCode === 32 || e.keyCode === 13) || e.type == "click") {
      var scrollTarget = $('#main').length ? $('#main').first() : $('h1').first();
      if (scrollTarget.is(":hidden")) {
        if ($('#scrollToMe').length == 0) {
          scrollTarget.after("<div id='scrollToMe'></div>");
        }
        scrollTarget = $("#scrollToMe");
      }
      $('html,body').animate({ scrollTop: scrollTarget.offset().top }, 1000);
      scrollTarget.attr('tabindex', -1).on('blur focusout', function () {
        // when focus leaves this element, remove the tabindex attribute
        $(this).removeAttr('tabindex');
      }).focus(); // focus on the content container
      return false;
    }
  });
});

/*
 * Scroll to Left Navigation menu in Mobile view.
 */

var MobileNav = (function() {
  // Public Methods
  var scrollToLeftNavOnButtonClick = function() {
    var $navThisSectionButton = $('div#mobile-nav > a.button');
    var $leftNavMenu = $('.leftNav > .leftTitle');
    var omniNavHeight = $('#cu_nav').outerHeight(true);

    $navThisSectionButton.on('click', function() {
      // OmniNav is fixed position. I'd expect this to be:
      // $leftNavMenu.offset().top + omniNavHeight
      // But testing proved otherwise.
      var scrollTo = $leftNavMenu.offset().top - omniNavHeight;

      // I really wish we had used a plugin like scrollTo or scrollable. I'm
      // seeing various other approaches to scrolling elsewhere in code base so
      // I'm reluctanct to introduce a plugin now.
      // Source for this approach: https://stackoverflow.com/a/6677069/6763239
      $('html, body').animate({
        scrollTop: scrollTo
      }, 'slow');
    });
  };

  // Private Methods

  // Public API
  return {
    scrollToLeftNavOnButtonClick: scrollToLeftNavOnButtonClick
  };
})();


// On document ready.
$(function () {
  // The JS in this file only applies to omninav v1
  // For OmniNav v2, see omni-nav-v2.js
  if ( $('html').find('#omni-nav-v2').length === 0 ) {
    MobileNav.scrollToLeftNavOnButtonClick();
  }
});
$(document).ready(function() {
  var $rootDrillDownNav   = $('#left-column-navigation .root-left-nav'),
  $rootElement            = $('#left-column-navigation'),
  tabableElements         = 'a[href], area[href], input, select, textarea, button, iframe, object, embed, *[tabindex], *[contenteditable]',
  nonTabableElements      = '[tabindex=-1], [disabled], :hidden',
  resizeTimer             = null;

  if (!$rootElement.length || !$rootElement) return;

  function drillMenuDown() {
    var $menuToDrillDownTo  = $(this).siblings('.drilldown-menu'),
    widthAmount             = $rootDrillDownNav.width(),
    ulCurrentPos            = getTranslateXVal($rootDrillDownNav),
    translateXVal           = ulCurrentPos - widthAmount;

    $menuToDrillDownTo.show();
    $rootDrillDownNav.css({ transform: "translateX(" + translateXVal + "px)"  });

    $rootElement.find('ul.active').removeClass('active');
    $menuToDrillDownTo.addClass('active');

    $rootElement.css({ height: $menuToDrillDownTo.height() });
    
    $('html').scrollTop($('#left-column-navigation').offset().top - 120);

    return;
  }

 function drillMenuUp() {
    var widthAmount       = $rootDrillDownNav.width(),
    ulCurrentPos          = getTranslateXVal($rootDrillDownNav),
    translateXVal         = ulCurrentPos + widthAmount,
    $parentDrillDownMenu  = $(this).closest('.drill-down-list-item').closest('.drilldown-menu');

    $rootElement.find('ul.active').removeClass('active');
    !translateXVal ? $rootDrillDownNav.addClass('active') : $parentDrillDownMenu.addClass('active');

    $rootDrillDownNav.css({ transform: "translateX(" + translateXVal + "px)"  });
    $(this).parent().hide();

    if (translateXVal >= 0) {
      $rootElement.css({ height: ($rootDrillDownNav.initialHeight) });
      return;
    }
    
    $rootElement.css({ height: ($parentDrillDownMenu.height()) });

    $('html').scrollTop($('#left-column-navigation').offset().top - 120, 'slow');

    return;
  }

  function getTranslateXVal(selector) {
    var transformMatrix = selector.css("-webkit-transform") ||
                          selector.css("-moz-transform")    ||
                          selector.css("-ms-transform")     ||
                          selector.css("-o-transform")      ||
                          selector.css("transform");
    
    transformMatrix = transformMatrix === "none" ? 0 : transformMatrix;

    if (!isNaN(transformMatrix))
      return 0;
    
    var matrix = transformMatrix.replace(/[^0-9\-.,]/g, '').split(',');
    var x = matrix[12] || matrix[4];//translate x

    return parseInt(x);
  }

  function moveOffCanvasToCurrentPathItem() {
    var currentPath = $rootDrillDownNav.find('li.current'),
    $currentPathDrillDownMenu = currentPath.parent('.drilldown-menu');
    $rootElement.show();

    if (currentPath.length) {
      var $drillDownParents = currentPath.parents('ul.drilldown-menu'),
      widthAmount           = $rootDrillDownNav.width();

      $drillDownParents.show();
      $rootDrillDownNav.css({ transform: "translateX(-" + (widthAmount * $drillDownParents.length) + "px" });
      $rootElement.css({ height: $currentPathDrillDownMenu.height() });
      $rootDrillDownNav.css({ transition: 'all .5s'});

      $rootDrillDownNav.initialHeight = $rootDrillDownNav.height();

      $currentPathDrillDownMenu.addClass('active');

      return;
    }

    $rootElement.css({ height: $rootDrillDownNav.initialHeight });

    $('html').scrollTop($('#left-column-navigation').offset().top - 120);

    $rootDrillDownNav.initialHeight = $rootDrillDownNav.height();
    
    $rootDrillDownNav.addClass('active');
    return;
  }

  function resizeRootDrillDown() {
    var widthAmount       = $rootDrillDownNav[0].getBoundingClientRect().width,
    ulCurrentPos          = getTranslateXVal($rootDrillDownNav),
    $drillDownMenus       = $rootDrillDownNav.find('.drilldown-menu'),
    $drillDownMenuVisible = $rootDrillDownNav.find('.drilldown-menu[style*="display: block"]');

    $drillDownMenus.css({ left: widthAmount + "px" });
    $rootDrillDownNav.css({ transform: "translateX(-" + (!ulCurrentPos ? ulCurrentPos :  widthAmount * $drillDownMenuVisible.length) + "px"});
  }

  $rootDrillDownNav.on('click', '.drill-down-parent', drillMenuDown);
  
  $rootDrillDownNav.on('click', '.toggle-drilldown', drillMenuDown);

  $rootDrillDownNav.on('click', '.menu-back', drillMenuUp);

  // ACCESSIBILITY START //

  // LOOKS FOR FOCUS ON LEFT NAV ONLY FROM TABBING OR CLICKING FROM OTHER AREA THAN LEFT NAV
  $('body').on('focusin', '#left-column-navigation', function(e) {
    // FIXES ISSUE WHERE FOCUS IS ON FIRST LI OF MENU AND SHIFTS scrollTop MOVING MENU UP
    document.getElementById('left-column-navigation').scrollTop = 0;

    // USES RELATED TARGET TO IDENTIFIY IF FOCUS IS COMING FROM OUTSIDE ELEMENT OF LEFT NAV TO DETERMINE INITIAL FOCUS
    if (e.relatedTarget && !$(e.relatedTarget).parents('#left-column-navigation').length) {
      e.preventDefault();

      findSetLeftNavFocus(e);
    }
  });

  $('#twitter-widget-0').on('load', function() {
    $('#twitter-widget-0').contents().find('a').last().on('focusout', function(e) {
      e.preventDefault();

      var $drillDownFirstItem  = $rootDrillDownNav.find('.drilldown-menu.active').children('.menu-back');

      $drillDownFirstItem.length ? $drillDownFirstItem.focus() : $rootDrillDownNav.find('li').first().focus()

      return

    });
  });

  // DRILLS DOWN MENU ON ENTER OR SPACE BY ADDING LISTENER TO DRILL DOWN PARENT MENU LI
  $rootDrillDownNav.on('keydown', '.drill-down-parent', function(e) {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      var $nextTabableItem = $(this).siblings('.drilldown-menu').children('.menu-back')
      var drillDown = drillMenuDown.bind(this);

      drillDown();

      //REASON FOR SET TIMEOUT SEE THIS SO 
      //https://stackoverflow.com/questions/3580068/is-settimeout-with-no-delay-the-same-as-executing-the-function-instantly/3580703#3580703
      setTimeout(function() {
        $nextTabableItem.focus();
      },500);
      return;
    }
  });

  // DRILLS MENU BACK UP ON ENTER OR SPACE ON MENU BACK LI
  $rootDrillDownNav.on('keydown', '.menu-back', function(e) {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      var $nextTabableItem = $(this).closest('.drill-down-list-item').children('.drill-down-parent');
      var drillup = drillMenuUp.bind(this);

      drillup();

      //REASON FOR SET TIMEOUT SEE THIS SO 
      //https://stackoverflow.com/questions/3580068/is-settimeout-with-no-delay-the-same-as-executing-the-function-instantly/3580703#3580703
      setTimeout(function() {
        $nextTabableItem.focus();
      },500);
      return;
    }
  });

  // SELECTS FIRST ITEM IN THE FIRST MENU TO FIND PREVIOUS TABABLE ITEM IN HTML BEFORE LEFT NAV HIERARCHY ON SHIFT TAB
  Mousetrap(document.querySelector('.root-left-nav li.home-menu')).bind('shift+tab', function(e) {
    e.preventDefault();
    findPrevTabable();
  });

  // SELECTS FIRST ITEM IN THE DRILL DOWN MENU TO FIND PREVIOUS TABABLE ITEM IN HTML HIERARCHY ON SHIFT TAB
  $('.root-left-nav .menu-back').each(function(index) {
    Mousetrap(this).bind('shift+tab', function(e) {
      e.preventDefault();
      findPrevTabable();
    });
  });

  // SELECTS MAIN AND ALL DRILL DOWN MENUS TO ADD LISTENER TO LAST LI IN UL MENUS TO FIND NEXT TABABLE ELEMENT IN HTML HIERARCY AFTER LEFT NAV ON TAB
  $rootElement.find('ul').each(function(index) {
    $(this).children('li').last().on('keydown', function(e) {
      var keyCode = e.keyCode || e.which,
      parentActive = $(this).parent('ul').hasClass('active');

      if (keyCode === 9 && !e.shiftKey && parentActive) {
        e.preventDefault();
        findNextTabable();
      }
    })
  })


  function findSetLeftNavFocus(e) {
    e && e.stopPropagation();
    var $drillDownFirstItem  = $rootDrillDownNav.find('.drilldown-menu.active').children('.menu-back'),
    $drillDownLastItem       = $rootDrillDownNav.find('.drilldown-menu.active').children().last().children(tabableElements).not(nonTabableElements);

    // DETERMINES IF FOCUS IS COMING FROM MIDDLE CONTAINER OR BEFORE LEFT NAV IF SO SETS IT TO EITHER FIRST ITEM IN MENU OR DRILLED DOWN MENU
    if ($('.middleRightContainer').find(e.relatedTarget).length) {
      $drillDownFirstItem.length ? $drillDownFirstItem.focus() : $rootDrillDownNav.find('li').first().focus()
      return;
    }

    if ($('.breadcrumbs').find(e.relatedTarget).length) {
      $drillDownFirstItem.length ? $drillDownFirstItem.focus() : $rootDrillDownNav.find('li').first().focus()
      return;
    }

    // SETS FOCUS TO LAST ITEM IN FIRST MENU OR DRILLED DOWN MENU
    $drillDownLastItem.length ? $drillDownLastItem.focus() : $rootDrillDownNav.find('li').last().focus();

  }

  function findPrevTabable() {
    var $elem = $('.leftNav');

    // LOOPS THROUGH PREVIOUS HIERARCHIAL HTML ELEMENTS TO FIND PREVIOUS TABABLE ITEM
    $elem.prevAll().each(function(index) {
      // FIND METHOD LOOKS THROUGH ALL CHILDREN TO FIND TABABLE ELEMENTS
      var $prevTabableElement = $(this).find(tabableElements).not(nonTabableElements);

      if ($prevTabableElement.length) {
        $prevTabableElement.last().focus();
        return false;
      }
    });
  }

  function findNextTabable() {
    var focusedElement = false;
    // LOOPS THROUGH NEXT HIERARCHIAL HTML ELEMENTS IN LEFT NAV TO FIND NEXT TABABLE ITEM
    $rootElement.nextAll().each(function(index) {
      // FIND METHOD LOOKS THROUGH ALL CHILDREN TO FIND TABABLE ELEMENTS
      var $nextTabableElement = $(this).find(tabableElements).not(nonTabableElements);

      // IF ANY SETS FOCUS AND RETURNS FALSE TO END LOOP
      if ($nextTabableElement.length) {
        $nextTabableElement.first().focus();
        focusedElement = true;
        return false;
      }
    });

    if (focusedElement)
      return;
    
    // IF NO PREVIOUS FOCUS ITEMS FOUND WILL SEARCH NEXT HEIRARCHIAL TO LEFT NAV HTML ELEMENT FOR TABABLE ELEMENT
    $('.leftNav').nextAll().each(function(index) {
      var $nextTabableElement = $(this).find(tabableElements).not(nonTabableElements);

      if ($nextTabableElement.length) {
        $nextTabableElement.first().focus();
        focusedElement = true;
        return false;
      }
    });

    if (focusedElement)
      return;

    // IF NO PREVIOUS FOCUS ITEMS FOUND WILL SEARCH NEXT HEIRARCHIAL TO RIGHT NAV HTML ELEMENT FOR TABABLE ELEMENT
    $('.rightNav').nextAll().each(function(index) {
      var $nextTabableElement = $(this).find(tabableElements).not(nonTabableElements);

      if ($nextTabableElement.length) {
        $nextTabableElement.first().focus();
        focusedElement = true;
        return false;
      }
    });

    if (focusedElement)
      return;

    // IF NO PREVIOUS FOCUS ITEMS FOUND WILL SEARCH FOOTER HTML ELEMENT FOR TABABLE ELEMENT
    $('.footer__container').find(tabableElements).not(nonTabableElements).first().focus();  

    return;

  }

  // ACCESSIBILITY END //

  var checkResizeRootDrillDown = function() {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(resizeRootDrillDown, 500);
  };

  $(window).resize(checkResizeRootDrillDown);

  moveOffCanvasToCurrentPathItem();
  resizeRootDrillDown();

});

$(window).on('load', function() {
  var $rootDrillDownNav   = $('#left-column-navigation .root-left-nav');

  // FINDING IFRAME TWITTER WIDGET AND ADDING HANDLER FOR 
  $('#twitter-widget-0').contents().find('a').last().on('keydown', function(e) {
    var keyCode = e.keyCode || e.which
    
    if (keyCode === 9) {
      e.preventDefault();
      var $drillDownFirstItem  = $rootDrillDownNav.find('.drilldown-menu.active').children('.menu-back');

      $drillDownFirstItem.length ? $drillDownFirstItem.focus() : $rootDrillDownNav.find('li').first().focus();
    }

    return;
  });

  $('#twitter-widget-0').on('load', function() {
    $('#twitter-widget-0').contents().find('a').last().on('keydown', function(e) {
      var keyCode = e.keyCode || e.which

      if (keyCode === 9) {
        e.preventDefault();
        var $drillDownFirstItem  = $rootDrillDownNav.find('.drilldown-menu.active').children('.menu-back');
    
        $drillDownFirstItem.length ? $drillDownFirstItem.focus() : $rootDrillDownNav.find('li').first().focus();
      }
      return;
    });
  });

});


$(document).ready(function () {

  // Restructures toggle DOM order for immediate tabindex after Uninav. Remains the same visually.
  $(".uninav__umbrella-nav-button-container").detach().appendTo('nav#uninav');


  var $offCanvasNavContainer = $('#uninav .off-canvas-nav-container'),
    menuVisibleXVal = 0,
    menuWidth = $(window).width() > 600 ? 410 : 350,
    $rootUmbrellaDiv = $('#uninav #off-canvas-umbrella'),
    $rootMainDiv = $('#uninav #off-canvas-main'),
    $rootDrillDownNavUmbrella = $('#off-canvas-umbrella-navigation .root-umbrella-nav'),
    $rootDrillDownNavMain = $('#off-canvas-main-navigation .root-main-nav'),
    $rootElement = $('.off-canvas-nav-container')
  translateXVal = menuWidth;
  headerHeight = $('#uninav .cu-off-canvas-header').height() + $('#uninav .menu-header').height(),
    $sectionMenuButton = $('#uninav .uninav__umbrella-nav-button-container button'),
    $offCanvasOverlay = $('.off-canvas-overlay#js-off-canvas-overlay'),
    resizeTimer = null;

  $(window).resize(checkResizeRootDrillDown);

  $rootDrillDownNavMain.currentWidth = menuWidth;
  $rootDrillDownNavUmbrella.currentWidth = menuWidth;

  $sectionMenuButton.on('click', function () {
    $offCanvasNavContainer.css({
      transform: "translateX(" + menuVisibleXVal + "px)",
      visibility: 'visible'
    });
    $offCanvasOverlay.show();

    // shift focus
    setTimeout(function () { $('#js-off-canvas-nav-container #main-logo a').focus() }, 100);

  });

  $(window).on('scroll', setSectionMenuButtonSize)

  //CLOSE OFF-CANVAS-NAV
  $offCanvasNavContainer.find('.close.js-close-off-canvas-nav').on('click', function () {
    $offCanvasNavContainer.css({
      transform: "translateX(-" + menuWidth + "px)",
      visibility: 'hidden'
    });
    $offCanvasOverlay.hide();
    setTimeout(function () { $('#main a').focus() }, 1000);

  });

  $offCanvasNavContainer.find('.close.js-close-off-canvas-nav').on('keydown', function (e) {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      $offCanvasNavContainer.css({
        transform: "translateX(-" + menuWidth + "px)",
        visibility: 'hidden'
      });
      $offCanvasOverlay.hide();
      setTimeout(function () { $('#main a').focus() }, 1000);

    }
  });

  $rootUmbrellaDiv.find('.toggle-menu-label').on('click', function () {
    changeContextualMenus($(this));
  });

  $rootMainDiv.find('.toggle-menu-label').on('click', function () {
    changeContextualMenus($(this));
  });

  $rootUmbrellaDiv.find('.toggle-menu-label').on('keydown', function (e) {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      changeContextualMenus($(this));
    }
  });

  $rootMainDiv.find('.toggle-menu-label').on('keydown', function (e) {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      changeContextualMenus($(this));
    }
  });

  $('#uninav .uninav__hamburger-menu .hamburger-menu-button').on('click', function () {
    $offCanvasNavContainer.css({
      transform: "translateX(" + menuVisibleXVal + "px)",
      visibility: 'visible'
    });
    $offCanvasOverlay.show();
  });

  $('#uninav .uninav__hamburger-menu .hamburger-menu-button').on('keydown', function (e) {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      $offCanvasNavContainer.css({
        transform: "translateX(" + menuVisibleXVal + "px)",
        visibility: 'visible'
      });
      $offCanvasOverlay.show();
    }
  });

  $rootMainDiv.find('.menu-header .menu-label').on('click', function () {
    moveOffCanvasToRoot($(this));
  });

  $rootUmbrellaDiv.find('.menu-header .menu-label').on('click', function () {
    moveOffCanvasToRoot($(this));
  });

  $rootMainDiv.find('.menu-header .menu-label').on('keydown', function (e) {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      moveOffCanvasToRoot($(this));
    }
  });

  $rootUmbrellaDiv.find('.menu-header .menu-label').on('keydown', function (e) {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      moveOffCanvasToRoot($(this));
    }
  });

  $offCanvasOverlay.on('click', function () {
    $offCanvasNavContainer.css({
      transform: "translateX(-" + menuWidth + "px)",
      visibility: 'hidden'
    });
    $(this).hide();
  });

  $rootDrillDownNavUmbrella.on('click', '.drill-down-parent', drillMenuDown);

  $rootDrillDownNavMain.on('click', '.drill-down-parent', drillMenuDown);

  $rootDrillDownNavUmbrella.on('click', '.toggle-drilldown', drillMenuDown);

  $rootDrillDownNavMain.on('click', '.toggle-drilldown', drillMenuDown);

  $rootDrillDownNavUmbrella.on('click', '.menu-back', drillMenuUp);

  $rootDrillDownNavMain.on('click', '.menu-back', drillMenuUp);

  $rootDrillDownNavUmbrella.on('keydown', '.drill-down-parent', function (e) {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      var $nextTabableItem = $(this).siblings('.drilldown-menu').children('.menu-back')
      var drillDown = drillMenuDown.bind(this);

      drillDown();

      //REASON FOR SET TIMEOUT SEE THIS SO 
      //https://stackoverflow.com/questions/3580068/is-settimeout-with-no-delay-the-same-as-executing-the-function-instantly/3580703#3580703
      setTimeout(function () {
        $nextTabableItem.focus();
      }, 500);
      return;
    }
  });

  $rootDrillDownNavMain.on('keydown', '.drill-down-parent', function (e) {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      var $nextTabableItem = $(this).siblings('.drilldown-menu').children('.menu-back')
      var drillDown = drillMenuDown.bind(this);

      drillDown();

      //REASON FOR SET TIMEOUT SEE THIS SO 
      //https://stackoverflow.com/questions/3580068/is-settimeout-with-no-delay-the-same-as-executing-the-function-instantly/3580703#3580703
      setTimeout(function () {
        $nextTabableItem.focus();
      }, 500);
      return;
    }
  });

  $rootDrillDownNavUmbrella.on('keydown', '.menu-back', function (e) {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      var $nextTabableItem = $(this).closest('.drill-down-list-item').children('.drill-down-parent');
      var drillup = drillMenuUp.bind(this);

      drillup();

      //REASON FOR SET TIMEOUT SEE THIS SO 
      //https://stackoverflow.com/questions/3580068/is-settimeout-with-no-delay-the-same-as-executing-the-function-instantly/3580703#3580703
      setTimeout(function () {
        $nextTabableItem.focus();
      }, 500);
      return;
    }
  });

  $rootDrillDownNavMain.on('keydown', '.menu-back', function (e) {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      var $nextTabableItem = $(this).closest('.drill-down-list-item').children('.drill-down-parent');
      var drillup = drillMenuUp.bind(this);

      drillup();

      //REASON FOR SET TIMEOUT SEE THIS SO 
      //https://stackoverflow.com/questions/3580068/is-settimeout-with-no-delay-the-same-as-executing-the-function-instantly/3580703#3580703
      setTimeout(function () {
        $nextTabableItem.focus();
      }, 500);
      return;
    }
  });

  $('#off-canvas-umbrella-navigation .root-umbrella-nav .menu-back').each(function (idx, item) {
    Mousetrap(item).bind('shift+tab', function (e) {
      var currentMenuBack = $(document.activeElement);
      var drillUp = drillMenuUp.bind(currentMenuBack);
      drillUp();
    });
  });

  $('#off-canvas-main-navigation .root-main-nav .menu-back').each(function (idx, item) {
    Mousetrap(item).bind('shift+tab', function (e) {
      var currentMenuBack = $(document.activeElement);
      var drillUp = drillMenuUp.bind(currentMenuBack);
      drillUp();
    });
  });

  function changeContextualMenus($element) {
    var $otherContextualMenu = $element.parents('.off-canvas-menu').siblings('.off-canvas-menu'),
      $currentContextualMenu = $element.parents('.off-canvas-menu'),
      $activeDrillDownMenu = $otherContextualMenu.find('.drilldown-menu.active')

    $currentContextualMenu.removeClass('slide-in');
    $currentContextualMenu.addClass('slide-out');
    $otherContextualMenu.show();
    $otherContextualMenu.removeClass('slide-out');
    $otherContextualMenu.addClass('slide-in');

    if (!$activeDrillDownMenu.length) {
      if (!$rootDrillDownNavMain.initialHeight)
        $rootDrillDownNavMain.initialHeight = $('.root-main-nav').height();

      if (!$rootDrillDownNavUmbrella.initialHeight)
        $rootDrillDownNavUmbrella.initialHeight = $('.root-umbrella-nav').height();

      if ($otherContextualMenu.find('.root-umbrella-nav').length) {
        if ($rootDrillDownNavUmbrella.initialHeight + headerHeight >= $(window).height()) {
          $rootElement.css({ overflowY: 'scroll' });
        } else {
          $rootElement.css({ overflowY: 'hidden' });
        }
        $rootDrillDownNavUmbrella.css({ height: $rootDrillDownNavUmbrella.initialHeight });
      } else {
        if ($rootDrillDownNavMain.initialHeight + headerHeight >= $(window).height()) {
          $rootElement.css({ overflowY: 'scroll' });
        } else {
          $rootElement.css({ overflowY: 'hidden' });
        }
        $rootDrillDownNavMain.css({ height: $rootDrillDownNavMain.initialHeight });
      }



      setTimeout(function () {
        $currentContextualMenu.hide();
      }, 500);

      return;
    }

    if ($activeDrillDownMenu.height() + headerHeight >= $(window).height()) {
      $rootElement.css({ overflowY: 'scroll' });
    } else {
      $rootElement.css({ overflowY: 'hidden' });
    }

    setTimeout(function () {
      $currentContextualMenu.hide();
    }, 500);

    return;
  }

  function moveOffCanvasToRoot(element) {
    if (element.parents('#off-canvas-umbrella').length === 1) {
      $rootDrillDownNavUmbrella.find('.drilldown-menu.active').removeClass('active');
      $rootUmbrellaDiv.find('.root-umbrella-nav').css({ transform: "translateX(-" + menuVisibleXVal + "px" });
      $rootUmbrellaDiv.find('.drilldown-menu').hide();
      $rootDrillDownNavUmbrella.removeClass('drilled-down')

      if ($rootDrillDownNavUmbrella.initialHeight + headerHeight >= $(window).height()) {
        $rootElement.css({ overflowY: 'scroll' });
      } else {
        $rootElement.css({ overflowY: 'hidden' });
      }

      $rootDrillDownNavUmbrella.css({ height: $rootDrillDownNavUmbrella.initialHeight });
      return;
    }
    $rootDrillDownNavMain.find('.drilldown-menu.active').removeClass('active');
    $rootMainDiv.find('.root-main-nav').css({ transform: "translateX(-" + menuVisibleXVal + "px" });
    $rootMainDiv.find('.drilldown-menu').hide();
    $rootDrillDownNavMain.removeClass('drilled-down');

    if ($rootDrillDownNavMain.height() + headerHeight >= $(window).height()) {
      $rootElement.css({ overflowY: 'scroll' });
    } else {
      $rootElement.css({ overflowY: 'hidden' });
    }

    $rootDrillDownNavMain.css({ height: $rootDrillDownNavMain.initialHeight });
    return;
  }

  function drillMenuDown() {
    var $menuToDrillDownTo = $(this).siblings('.drilldown-menu'),
      ulCurrentPos = getTranslateXVal($rootDrillDownNavMain),
      umbrellaDrillDown = $(this).parents('#off-canvas-umbrella').length,
      translateXVal = ulCurrentPos - menuWidth;

    if (umbrellaDrillDown) {
      ulCurrentPos = getTranslateXVal($rootDrillDownNavUmbrella),
        translateXVal = ulCurrentPos - menuWidth;
      $rootDrillDownNavUmbrella.addClass('drilled-down');
      $rootDrillDownNavUmbrella.find('.drilldown-menu.active').removeClass('active');
      $menuToDrillDownTo.addClass('active');

      $menuToDrillDownTo.show();
      $rootElement.animate({ scrollTop: 0 });
      $rootDrillDownNavUmbrella.css({ transform: "translateX(" + translateXVal + "px)" });

      $rootDrillDownNavUmbrella.css({ height: $menuToDrillDownTo.height() });

      if ($menuToDrillDownTo.height() + headerHeight > $(window).height()) {
        $rootElement.css({ overflowY: 'scroll' });
        return
      }

      $rootElement.css({ overflowY: 'hidden' })

      return;
    }

    $rootDrillDownNavMain.find('.drilldown-menu.active').removeClass('active');
    $menuToDrillDownTo.addClass('active');
    $menuToDrillDownTo.show();
    $rootDrillDownNavMain.css({ transform: "translateX(" + translateXVal + "px)" });
    $rootDrillDownNavMain.addClass('drilled-down');
    $rootElement.animate({ scrollTop: 0 }, 'slow');
    if ($menuToDrillDownTo.height() + headerHeight > $(window).height()) {
      $rootElement.css({ overflowY: 'scroll' });
      return
    }

    $rootElement.css({ overflowY: 'hidden' })
    return;
  }

  function drillMenuUp() {
    var umbrellaDrillDown = $(this).parents('#off-canvas-umbrella').length,
      ulCurrentPos = getTranslateXVal($rootDrillDownNavMain),
      translateXVal = ulCurrentPos + menuWidth,
      $parentDrillDownMenu = $(this).closest('.drill-down-list-item').closest('.drilldown-menu');

    if (umbrellaDrillDown) {
      $rootDrillDownNavUmbrella.find('.drilldown-menu.active').removeClass('active');
      $parentDrillDownMenu.addClass('active');
      ulCurrentPos = getTranslateXVal($rootDrillDownNavUmbrella),
        translateXVal = ulCurrentPos + menuWidth;

      if (translateXVal === 0) {
        $rootDrillDownNavUmbrella.removeClass('drilled-down');
      }

      $rootDrillDownNavUmbrella.css({ transform: "translateX(" + translateXVal + "px)" });

      $(this).parent().hide();

      if (translateXVal == 0) {
        $rootDrillDownNavUmbrella.css({ height: $rootDrillDownNavUmbrella.initialHeight });

        if ($rootDrillDownNavUmbrella.initialHeight + headerHeight >= $(window).height()) {
          $rootElement.css({ overflowY: 'scroll' });
        } else {
          $rootElement.css({ overflowY: 'hidden' });
        }

        return;
      };

      $rootDrillDownNavUmbrella.css({ height: $parentDrillDownMenu.height() });

      if ($parentDrillDownMenu.height() + headerHeight >= $(window).height()) {
        $rootElement.css({ overflowY: 'scroll' });
      } else {
        $rootElement.css({ overflowY: 'hidden' });
      }

      return;
    }

    if (translateXVal === 0) {
      $rootDrillDownNavMain.removeClass('drilled-down');
    }

    $rootDrillDownNavMain.find('.drilldown-menu.active').removeClass('active');
    $parentDrillDownMenu.addClass('active');
    $rootDrillDownNavMain.css({ transform: "translateX(" + translateXVal + "px)" });
    $(this).parent().hide();

    if (translateXVal == 0) {
      $rootDrillDownNavMain.css({ height: $rootDrillDownNavMain.initialHeight });

      if ($rootDrillDownNavUmbrella.initialHeight + headerHeight >= $(window).height()) {
        $rootElement.css({ overflowY: 'scroll' });
      } else {
        $rootElement.css({ overflowY: 'hidden' });
      }

      return;
    };

    if ($rootDrillDownNavMain.initialHeight + headerHeight >= $(window).height())
      $rootElement.css({ overflowY: 'scroll' });

    $rootDrillDownNavMain.css({ height: $parentDrillDownMenuHeight });

    return;
  }



  function getTranslateXVal(selector) {
    var transformMatrix = selector.css("-webkit-transform") ||
      selector.css("-moz-transform") ||
      selector.css("-ms-transform") ||
      selector.css("-o-transform") ||
      selector.css("transform");

    transformMatrix = transformMatrix === "none" ? 0 : transformMatrix;
    if (!isNaN(transformMatrix))
      return 0;

    var matrix = transformMatrix.replace(/[^0-9\-.,]/g, '').split(',');
    var x = matrix[12] || matrix[4];//translate x

    return parseInt(x);
  }

  function moveToCurrentSetHeight() {
    var currentPath = $rootElement.find('li.current'),
      umbrellaNav = $rootDrillDownNavUmbrella.length,
      $currentPathDrillDownMenu = currentPath.parent('.drilldown-menu');

    if (currentPath.length) {
      $currentPathDrillDownMenu.addClass('active');
      var $drillDownParents = currentPath.parents('ul.drilldown-menu'),
        umbrellaDrillDown = currentPath.parents('#off-canvas-umbrella').length;

      $drillDownParents.show();
      $rootDrillDownNavUmbrella.initialHeight = $('.root-umbrella-nav').height();

      if (umbrellaDrillDown) {
        $rootUmbrellaDiv.show();
        $rootMainDiv.hide();

        $rootDrillDownNavUmbrella.css({ transform: "translateX(-" + (menuWidth * $drillDownParents.length) + "px" });
        $rootMainDiv.css({ transform: "translateX(-" + menuWidth + "px" });

        if ($currentPathDrillDownMenu.length) {
          $rootDrillDownNavUmbrella.addClass('drilled-down');
          if ($currentPathDrillDownMenu.height() + headerHeight >= $(window).height()) {
            $rootElement.css({ overflowY: 'scroll' });
          } else {
            $rootElement.css({ overflowY: 'hidden' });
          }
        } else {
          if ($rootDrillDownNavUmbrella.initialHeight + headerHeight >= $(window).height()) {
            $rootElement.css({ overflowY: 'scroll' });
          } else {
            $rootElement.css({ overflowY: 'hidden' });
          }
        }

        return;
      }

      $rootMainDiv.show();
      $rootUmbrellaDiv.hide();
      $rootDrillDownNavMain.initialHeight = $('.root-umbrella-nav').height();
      $rootDrillDownNavMain.css({ transform: "translateX(-" + ((menuWidth * 2) * $drillDownParents.length) + "px" });
      $rootUmbrellaDiv.css({ transform: "translateX(-" + menuWidth + "px" });

      if ($currentPathDrillDownMenu.length) {
        $rootDrillDownNavMain.addClass('drilled-down');
        if ($currentPathDrillDownMenu.height() + headerHeight >= $(window).height()) {
          $rootElement.css({ overflowY: 'scroll' });
        } else {
          $rootElement.css({ overflowY: 'hidden' });
        }
      } else {
        if ($rootDrillDownNavMain.initialHeight + headerHeight >= $(window).height()) {
          $rootElement.css({ overflowY: 'scroll' });
        } else {
          $rootElement.css({ overflowY: 'hidden' });
        }
      }
      return;
    }

    if (umbrellaNav) {
      $rootDrillDownNavUmbrella.initialHeight = $('.root-umbrella-nav').height();

      if ($rootDrillDownNavUmbrella.initialHeight + headerHeight >= $(window).height()) {
        $rootElement.css({ overflowY: 'scroll' });
      } else {
        $rootElement.css({ overflowY: 'hidden' });
      }
      return;
    }

    $rootDrillDownNavMain.initialHeight = $('.root-main-nav').height();

    if ($rootDrillDownNavMain.initialHeight + headerHeight >= $(window).height()) {
      $rootElement.css({ overflowY: 'scroll' });
    } else {
      $rootElement.css({ overflowY: 'hidden' });
    }

    return;
  }

  function setSectionMenuButtonSize() {
    var scrollThreshHold = .20 * $(window).height();

    if ($(window).scrollTop() < scrollThreshHold && $sectionMenuButton.hasClass('section-menu-small')) {
      $('.section-menu-text').show();
      $('.section-menu-hamburger-icon').hide();
      $sectionMenuButton.removeClass('section-menu-small');
      return;
    }

    if ($(window).scrollTop() > scrollThreshHold && !$sectionMenuButton.hasClass('section-menu-small')) {
      $('.section-menu-hamburger-icon').show();
      $('.section-menu-text').hide();
      $sectionMenuButton.addClass('section-menu-small');
    }
  }

  function selectLastDrillDownElement() {
    var $umbrellaLastItem = $('#js-off-canvas-nav-container *[tabindex]:visible').last();
    $mainLastItem = $('.off-canvas-utility *[tabindex]:visible').last(),
      $umbrellaDrillDownMenus = $rootDrillDownNavUmbrella.find('.drilldown-menu'),
      $mainDrillDownMenus = $rootDrillDownNavMain.find('.drilldown-menu');

    $umbrellaDrillDownMenus.each(function (idx, drillDownMenu) {

      $(drillDownMenu).children(':last-child').off('focusin').on('focusin', function (e) {
        var drilldown = null,
          self = this,
          eventListeners = {
            click: false,
            shiftTab: false
          }

        $(document).off('click').on('click', function (e) {
          e.stopPropagation();
          $(document).off('click');
          eventListeners.click = true;
        });


        $(this).off("focusout").on("focusout", function (e) {
          e.stopPropagation();

          var $menuBack = $(this).siblings('.menu-back');

          drilldown = setTimeout(function () {
            if ($(self).find('.active').length) {
              return;
            }

            if (!e.relatedTarget) {
              return;
            }

            if (eventListeners.shiftTab) {
              return;
            }

            if (eventListeners.click) {
              return
            }
            $(document.activeElement).blur();
            drillMenuUp.call($menuBack);
            $(self).parent().closest('.drill-down-list-item').children('.drill-down-parent').focus()
            return;
          }, 500);

          return;
        });

        Mousetrap(this).bind('shift+tab', function (e) {
          e.stopPropagation();
          Mousetrap.unbind('shift+tab');

          eventListeners.shiftTab = true;
        });
      });
    });

    $mainDrillDownMenus.each(function (idx, drillDownMenu) {

      $(drillDownMenu).children(':last-child').off('focusin').on('focusin', function (e) {
        var drilldown = null,
          self = this,
          eventListeners = {
            click: false,
            shiftTab: false
          }

        $(document).off('click').on('click', function (e) {
          e.stopPropagation();
          $(document).off('click');
          eventListeners.click = true;
        });


        $(this).off("focusout").on("focusout", function (e) {
          e.stopPropagation();

          var $menuBack = $(this).siblings('.menu-back');

          drilldown = setTimeout(function () {
            if ($(self).find('.active').length) {
              return;
            }

            if (!e.relatedTarget) {
              return;
            }

            if (eventListeners.shiftTab) {
              return;
            }

            if (eventListeners.click) {
              return
            }
            $(document.activeElement).blur();
            drillMenuUp.call($menuBack);
            $(self).parent().closest('.drill-down-list-item').children('.drill-down-parent').focus()
            return;
          }, 500);

          return;
        });

        Mousetrap(this).bind('shift+tab', function (e) {
          e.stopPropagation();
          Mousetrap.unbind('shift+tab');

          eventListeners.shiftTab = true;
        });
      });
    });

    $umbrellaLastItem.on('keydown', function (e) {

      if (e.key === "Tab") {
        if (e.shiftKey) {
          return;
        }

        $offCanvasNavContainer.css({
          transform: "translateX(-" + menuWidth + "px)",
          visibility: 'hidden'
        });
        $offCanvasOverlay.hide();
        focusMainContent();
      }
    });



    $mainLastItem.on('keydown', function (e) {
      if (e.key === "Tab") {
        if (e.shiftKey) {
          return;
        }

        $offCanvasNavContainer.css({
          transform: "translateX(-" + menuWidth + "px)",
          visibility: 'hidden'
        });
        $offCanvasOverlay.hide();
        focusMainContent();
      }
    });
  }

  $('.off-canvas-utility').on('focusin', function (e) {
    console.log('focus')

    $('.off-canvas-utility').find('*[tabindex]:visible').last().on("keydown", function (e) {
      if (e.key === "Tab") {
        console.log('tab')
        if (e.shiftKey) {
          return;
        }

        console.log('focus out')
        $offCanvasNavContainer.css({
          transform: "translateX(-" + menuWidth + "px)",
          visibility: 'hidden'
        });
        $offCanvasOverlay.hide();
        focusMainContent();
      }



    })

  });

  // $('.off-canvas-utility').find('*[tabindex]:visible').last().on("focusin", function (e) {
  //   console.log('focus')


  // })



  $offCanvasNavContainer.find('.toggle-menu-label').off('focusin').on('focusin', function () {
    var eventListeners = { shiftTab: false };
    setTabFocus = null;


    Mousetrap(this).bind('shift+tab', function (e) {
      Mousetrap.unbind('shift+tab');
      eventListeners.shiftTab = true;
      return;
    });

    $(this).off('focusout').on('focusout', function () {
      if (eventListeners.shiftTab === true) {
        eventListeners.shiftTab = false;
        return;
      }

      var umbrellaNav = $rootUmbrellaDiv.is(':visible');

      if (umbrellaNav) {
        var $activeUmbrellaDrillDown = $rootDrillDownNavUmbrella.find('.drilldown-menu.active').children('.menu-back');
        if ($activeUmbrellaDrillDown.length) {
          $activeUmbrellaDrillDown.focus();
          return;
        }

        var $firstMenuItem = $rootDrillDownNavUmbrella.find('.drill-down-list-item:first');

        if ($firstMenuItem.find('.drilldown-menu').length) {
          $firstMenuItem.find('.drill-down-parent').focus();
          return;
        }

        $firstMenuItem.find('a').focus();
        return;
      }

      var $activeMainDrillDown = $rootDrillDownNavMain.find('.drilldown-menu.active').children('.menu-back');
      if ($activeMainDrillDown.length) {
        $activeMainDrillDown.focus();
        return;
      }

      var $firstMenuItem = $rootDrillDownNavMain.find('.drill-down-list-item:first');

      if ($firstMenuItem.find('.drilldown-menu').length) {
        $firstMenuItem.find('.drill-down-parent').focus();
        return;
      }

      $firstMenuItem.find('a').focus();

      return;
    });
  });

  function resizeRootDrillDown() {
    var $umbrellaActiveDrillDown = $rootDrillDownNavUmbrella.find('.drilldown-menu.active'),
      $mainActiveDrillDown = $rootDrillDownNavMain.find('.drilldown-menu.active'),
      umbrellaActiveDrillDownParents = $umbrellaActiveDrillDown.parents('.drilldown-menu').length,
      mainActiveDrillDownParents = $mainActiveDrillDown.parents('.drilldown-menu').length;

    if ($(window).width() < 600) {
      menuWidth = 350;
    } else {
      menuWidth = 410;
    }

    if ($umbrellaActiveDrillDown.length) {
      if (umbrellaActiveDrillDownParents) {
        $rootDrillDownNavUmbrella.css({ transform: "translateX(-" + ((menuWidth * 2) * umbrellaActiveDrillDownParents) + "px" });
      } else {
        $rootDrillDownNavUmbrella.css({ transform: "translateX(-" + menuWidth + "px" });
      }
    }

    if ($mainActiveDrillDown.length) {
      if (mainActiveDrillDownParents) {
        $rootDrillDownNavMain.css({ transform: "translateX(-" + ((menuWidth * 2) * mainActiveDrillDownParents) + "px" });
      } else {
        $rootDrillDownNavMain.css({ transform: "translateX(-" + menuWidth + "px" });
      }
    }
  }

  function checkResizeRootDrillDown() {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(resizeRootDrillDown, 500);
  };

  function addTopLevelDrillDownClasses() {
    $rootDrillDownNavMain.children().addClass('top-drill-down-list-item');
    $rootDrillDownNavUmbrella.children().addClass('top-drill-down-list-item');
  }

  addTopLevelDrillDownClasses();
  selectLastDrillDownElement();
  moveToCurrentSetHeight();
});



function focusMainContent() {
  var scrollTarget = $('#main').length ? $('#main').first() : $('h1').first();
  if (scrollTarget.is(":hidden")) {
    if ($('#scrollToMe').length == 0) {
      scrollTarget.after("<div id='scrollToMe'></div>");
    }
    scrollTarget = $("#scrollToMe");
  }
  $('html,body').animate({ scrollTop: scrollTarget.offset().top + 100 }, 500);
  scrollTarget.attr('tabindex', -1).on('blur focusout', function () {
    // when focus leaves this element, remove the tabindex attribute
    $(this).removeAttr('tabindex');
  }).focus(); // focus on the content container
  return false;
}
;
$(function () {
    $("#uninav-static-close").click(function () {
        $('.uninav-static-placeholder__notice').fadeOut(1200);
        $('.uninav__logo, .uninav__global-nav, .uninav__utility-nav--wrapper, .uninav__cta').css('filter', 'blur(0)');
    });
});
// uninav accessibility
$(function () {
  hideCurrentDropdownWhenLoseFocus();
  closePrevDropdownWhenFocusChanges();
  toggleAriaExpandVal();
  handleEscapeKeypress();
  gs__setSearchResultsZIndex();

  // $('#off-canvas-umbrella-navigation .root-main-nav').find('*[tabindex]:visible').last().addClass('last-item');

});
function closePrevDropdownWhenFocusChanges() {
  $(".uninav__dropdown--parent").on("click keypress", function (e) {
    $(".uninav__dropdown--parent")
      .not(this)
      .each(function () {
        $(this).attr("aria-expanded", "false");
      });
  });
}
function handleEscapeKeypress() {
  document.onkeydown = function (evt) {
    evt = evt || window.event;
    if (evt.keyCode == 27) {
      $(".uninav__dropdown--parent").attr("aria-expanded", "false");
    }
  };
}
function toggleAriaExpandVal() {
  $("#uninav li").on("click keypress", function (e) {
    if (accessibleClick(e) === true) {
      var menuItem = $(e.currentTarget);
      if (menuItem.attr("aria-expanded") === "true") {
        $(this).attr("aria-expanded", "false");
      } else {
        $(this).attr("aria-expanded", "true");
      }
    }
  });
}




function hideCurrentDropdownWhenLoseFocus() {
  $(".uninav__dropdown--child li:last-of-type").on("keydown blur", function (e) {
    // SHIFT TAB KEY COMBO
    if (e.shiftKey && e.keyCode === 9) {
      $(dropdownParent).attr("aria-expanded", "false");
      //     return false;
    } else if (e.keyCode === 9) {
      // TAB KEY PRESS
      var dropdownParent = $(this).closest(".uninav__dropdown--parent");
      $(dropdownParent).attr("aria-expanded", "false");
      // return false;
    } else if (e.type == "blur") {
      $(dropdownParent).attr("aria-expanded", "false");
    }
  });
  $(".uninav__dropdown--child li:first-child").on("keydown blur", function (e) {
    // SHIFT TAB KEY COMBO
    var dropdownParent = $(this).closest(".uninav__dropdown--parent");
    if (e.shiftKey && e.keyCode === 9) {
      $(dropdownParent).attr("aria-expanded", "false");
      //     return false;
    }
  });
  // handle clicking outside of dropdown item
  $(document).on("click keydown blur focusOut", function (e) {
    if ($(e.target).closest(".uninav__dropdown--parent").length === 0) {
      $(".uninav__dropdown--parent").attr("aria-expanded", "false");
    }
  });
}
function collapseAriaWhenClickOutside() {
  $(document).mouseup(function (e) {
    var container = $(".uninav__dropdown--parent");
    // if the target of the click isn't the container nor a descendant of the container
    if (!container.is(e.target) && container.has(e.target).length === 0) {
      container.hide();
    }
  });
}
function a11yClick(e) {
  if (event.type === "click") {
    return true;
  } else if (event.type === "keypress") {
    var code = event.charCode || event.keyCode;
    if (code === 32 || code === 13) {
      return true;
    }
  } else {
    return false;
  }
}
// end uninav accessibility

// gs = Google Search
// replace Google Custom Search default placeholder
window.onload = gs__customPlaceholder;
function gs__customPlaceholder() {
  document.getElementById("gsc-i-id1").setAttribute("placeholder", "Search...");
  document.getElementById("gsc-i-id1").style.opacity = "1";
  $('.gsc-search-button.gsc-search-button-v2').attr('tabindex', '-1');
}
// TODO: iOS style frosted/blurred background. CSS filter: blur(2px) performance is terrible
$(window).load(function () {
  if ($('table.gstl_50').length) {
    $('#gsc-i-id1').attr('aria-label', 'Search');
    $('table.gstl_50:not([role])').attr('role', 'presentation');
    $("#gsc-i-id1").on("input focus click", function () {
      gs__blurBg();
      // Google Search Table - add aria role
      $('table.gstl_50:not([role])').attr('role', 'presentation');
    });
  }
});
$(window).on("load resize", function (e) {
  gs__mobileReveal();
});
function gs__mobileReveal() {
  var searchInputDesktop = $(".uninav__search-input--desktop");
  var searchButtonMobile = $("#uninav__search-button--mobile");
  $(searchButtonMobile).click(function () {
    $(this).addClass('uninav__hidden');
    $('#uninav').addClass('utility-only');
    $('.uninav__logo, .uninav__hamburger-menu').addClass('logo--underneath');
    $(searchInputDesktop).addClass('uninav__reveal').addClass('slide-left');
    $("#gsc-i-id1").focus();
    $('.gsst_a').show()
    $('#gs_st50, .gsc-results-close-btn').click(function () {
      $('#uninav').removeClass('utility-only');
      $(searchInputDesktop).removeClass('uninav__reveal');
      $('.uninav__logo, .uninav__hamburger-menu').removeClass('logo--underneath');
      $('.uninav__cta--wrapper').removeClass('cta--underneath');
      $('.uninav__cta--wrapper').css('z-index', 'initial');
      $('.uninav__cta--wrapper').css('position', 'initial');
      $('.uninav__cta--wrapper').css('opacity', 'initial');
      $(searchButtonMobile).removeClass('uninav__hidden');
      $(searchInputDesktop).removeClass('uninav__reveal');
      $(searchButtonMobile).removeClass('uninav__hidden');
      $(searchInputDesktop).find('input').val('');
    });
  });
}
function gs__setSearchResultsZIndex() {
  $(".gssb_c[style]").css("z-index", "999999999999999999999999999999");
}
function gs__blurBg() {
  $(".gsc-completion-container").css("background", "transparent");
  $(".gsc-completion-container").css(
    "background-color",
    "rgba(255, 255, 255, 0.98)"
  );
}


function a11yClick(e) {
  if (event.type === 'click') {
    return true;
  } else if (event.type === 'keypress') {
    var code = event.charCode || event.keyCode;
    if ((code === 32) || (code === 13)) {
      return true;
    }
  } else {
    return false;
  }
}
;
function accessibleClick(event) {
    if (event.type === 'click') {
        return true;
    } else if (event.type === 'keypress') {
        var code = event.charCode || event.keyCode;
        if ((code === 32) || (code === 13)) {
            return true;
        }
    } else {
        return false;
    }
}

;
//these 2 functions not present in IE9 so had to add:
function addClass(el, newClassName){
    el.className += ' ' + newClassName;   
}

function removeClass(el, removeClassName){
    var elClass = el.className;
    while(elClass.indexOf(removeClassName) != -1) {
        elClass = elClass.replace(removeClassName, '');
        elClass = elClass.trim();
    }
    el.className = elClass;
}

// you get an svg
(function (document, uses, requestAnimationFrame, CACHE) {
	function embed(svg, g) {
		if (g) {
			var
			viewBox = g.getAttribute('viewBox'),
			fragment = document.createDocumentFragment(),
			clone = g.cloneNode(true);

			if (viewBox) {
				svg.setAttribute('viewBox', viewBox);
			}

			while (clone.childNodes.length) {
				fragment.appendChild(clone.childNodes[0]);
			}

			svg.appendChild(fragment);
		}
	}

	function onload() {
		var xhr = this, x = document.createElement('x'), s = xhr.s;

		x.innerHTML = xhr.responseText;

		xhr.onload = function () {
			s.splice(0).map(function (array) {
				embed(array[0], x.querySelector('#' + array[1].replace(/(\W)/g, '\\$1')));
			});
		};

		xhr.onload();
	}

	function onframe() {
		var use;

		while ((use = uses[0])) {
			var
			svg = use.parentNode,
			url = use.getAttribute('xlink:href').split('#'),
			url_root = url[0],
			url_hash = url[1];

			svg.removeChild(use);

			if (url_root.length) {
				var xhr = CACHE[url_root] = CACHE[url_root] || new XMLHttpRequest();

				if (!xhr.s) {
					xhr.s = [];

					xhr.open('GET', url_root);

					xhr.onload = onload;

					xhr.send();
				}

				xhr.s.push([svg, url_hash]);

				if (xhr.readyState === 4) {
					xhr.onload();
				}

			} else {
				embed(svg, document.getElementById(url_hash));
			}
		}

		requestAnimationFrame(onframe);
	}

	onframe();
})(
	document,
	document.getElementsByTagName('use'),
	window.requestAnimationFrame || window.setTimeout,
	{}
);

// gimme some sugar
(function (ARRAY, ELEMENT, NODELIST, HTMLCOLLECTION, PREFIX) {
	// <Element>.matches
	ELEMENT.matches = ELEMENT.matches || ELEMENT[PREFIX + 'MatchesSelector'];

	// <Element>.closest
	ELEMENT.closest = ELEMENT.closest || function (selector) {
		var node = this;

		while (node) {
			if (node.matches(selector)) {
				return node;
			} else {
				node = node.parentElement;
			}
		}

		return null;
	};

	// <NodeList>.each
	NODELIST.each = HTMLCOLLECTION.each = NODELIST.each || ARRAY.forEach;

	// <NodeList>.filter
	NODELIST.filter = HTMLCOLLECTION.filter = NODELIST.filter || function (selector) {
		return ARRAY.filter.call(this, typeof selector === 'string' ? function (node) {
			return node.matches(selector);
		} : typeof selector === 'function' ? selector : function (node) {
			return node === selector;
		});
	};

	// <NodeList>.indexOf
	NODELIST.indexOf = HTMLCOLLECTION.indexOf = NODELIST.indexOf || function (selector) {
		return ARRAY.indexOf.call(this, this.filter(selector)[0]);
	};

	// <NodeList>.toArray
	NODELIST.toArray = HTMLCOLLECTION.toArray = NODELIST.toArray || function () {
		return ARRAY.slice.call(this);
	};
})(
	Array.prototype,
	Element.prototype,
	NodeList.prototype,
	HTMLCollection.prototype,
	([].slice.call(getComputedStyle(document.documentElement)).join().match(/-(moz|ms|webkit)-/) || [])[1] || ''
);

//
(function () {
	// <Window>.Carousel
	function Carousel() {
		this.init.apply(this, arguments);
	}

	Carousel.init = function (node) {
		return new Carousel(node);
	};

	Carousel.initAll = function () {
		document.querySelectorAll('[data-carousel]').each(Carousel.init);

		document.addEventListener('DOMContentLoaded', Carousel.initAll);
	};

	Carousel.prototype = {
		// constructor
		constructor: Carousel,

		// init
		init: function (node) {
			this.node = node;

			this.initNode();
			this.initItems();
			this.initPrevnext();
		},
		initNode: function () {
			// update carousel
			this.node.removeAttribute('data-carousel');
			//DOESNT WORK IN IE9: this.node.classList.add('carousel');
			this.node.className += ' carousel';
			
		},
		initItems: function () {
			// get items
			this.items = this.node.querySelectorAll('figure');

			// update active item
			this.move(Math.max(this.items.indexOf('.active'), 0));
		},
		initPrevnext: function () {
			// add prev and next links
			var
			self = this,
			prev = self.node.appendChild(document.createElement('a')),
			next = self.node.appendChild(document.createElement('a'));

			prev.className = 'carousel-prevnext carousel-prev';
			next.className = 'carousel-prevnext carousel-next';

			// Removing for accessibility purposes
			// WAVE tool views these as broken same page links
			// prev.href = '#prev';
			// next.href = '#next';

			prev.title = 'Move to the previous slide in the carousel';
			next.title = 'Move to the next slide in the carousel';

			// add prev and next events
			prev.addEventListener('click', function (event) {
				event.preventDefault();

				self.prev();
			});
			next.addEventListener('click', function (event) {
				event.preventDefault();

				self.next();
			});
		},

		// action
		move: function (nextIndex) {
			var items = this.items, length = items.length, index = this.index;

			// get next index as modulus
			nextIndex = nextIndex % length;
			nextIndex = nextIndex < 0 ? length + nextIndex : nextIndex;

			// if index has changed
			if (index !== nextIndex && items[nextIndex]) {
				// update items
				if (items[index]) {
					//DOESNT WORK IN IE9: items[index].classList.remove('active');
					removeClass(items[index],'active'); 					
				}

				items[nextIndex].className += ' active';

				// add backgrounds
				updateDataImages();

				this.index = nextIndex;
			}
		},
		prev: function () {
			return this.move(this.index - 1);
		},
		next: function () {
			return this.move(this.index + 1);
		}
	};

	// <Window>.updateDataImages
	function updateDataImages() {
		var maxWidth = window.innerWidth, maxHeight = window.innerHeight, sway = updateDataImages.sway;

		document.querySelectorAll('[data-src][data-img]').each(function (element) {
			var rect = element.getBoundingClientRect();

			if (rect.bottom >= -sway && rect.top <= maxHeight+sway && rect.right >= -sway && rect.left <= maxWidth+sway) {
				element.style.backgroundImage = 'url(' + element.getAttribute('data-src') + ')';

				element.removeAttribute('data-src');
			}
		});
	}

	updateDataImages.initAll = function () {
		updateDataImages();

		document.addEventListener('DOMContentLoaded', updateDataImages);

		window.addEventListener('scroll', updateDataImages);
	};

	updateDataImages.sway = 128;

	// init
	window.Carousel = Carousel;
	window.updateDataImages = updateDataImages;

	Carousel.initAll();
	updateDataImages.initAll();
})();
document.addEventListener("DOMContentLoaded", function () {
    const unibuddy = document.getElementById("unibuddy-popcard-iframe");
    const uninav = document.getElementById("uninav");
    uninav.after(unibuddy);
});
$(function () {
    if ($('#covid19-callout-box').length > 0) {
        $('#covid19-callout-box').on("keypress", function (e) {
            if (a11yClick(event) === true) {
                _toggleContactEl();
            }
        });

        function a11yClick(event) {
            if (event.type === 'click') {
                return true;
            } else if (event.type === 'keypress') {
                var code = event.charCode || event.keyCode;
                if ((code === 32) || (code === 13)) {
                    return true;
                }
            } else {
                return false;
            }
        }
        $("#covid19-callout-box").detach().prependTo('#main');
    }
});
// Floating back-to-top button
$(function() {
  var ua = window.navigator.userAgent;
  var msie = ua.indexOf("MSIE ");

  if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) {
    // If Internet Explorer, return version number
    console.log(parseInt(ua.substring(msie + 5, ua.indexOf(".", msie))));
  } // If another browser, return 0
  else {
    if ($("#back2top").length) {
      var didScroll;
      var lastScrollTop = 0;
      var delta = 5;
      var topFloat = $("#back2top").outerHeight();
      $(window).scroll(function(event) {
        didScroll = true;
      });
      setInterval(function() {
        if (didScroll) {
          hasScrolled();
          didScroll = false;
        }
      }, 250);
      // Hide on load
      $("#back2top").hide();
      if ($(window).scrollTop() === 0) {
        $("#back2top").hide();
      }

      function hasScrolled() {
        var st = $(this).scrollTop();
        // Make sure they scroll more than delta
        if (Math.abs(lastScrollTop - st) <= delta) return;
        if (st > lastScrollTop && st > topFloat) {
          // Scroll Down
          $("#back2top").fadeIn(500);
        } else {
          // Scroll Up
          if (
            st + $(window).height() < $(document).height() ||
            $(window).scrollTop() === 0
          ) {
            $("#back2top").fadeOut(500);
          }
        }
        lastScrollTop = st;
      }
    }
    // Shimmer
    $(".circle-bg").hover(
      function() {
        $("span.fa-chevron-up").addClass("shimmer");
      },
      function() {
        $("span.fa-chevron-up").removeClass("shimmer");
      }
    );
    $("#back2top").on("click", function(e) {
      e.preventDefault();
      $("html,body").animate(
        {
          scrollTop: 0
        },
        500
      );
    });
  }
});
$(function () {

	/* Small view hide/show top menus
    ------------------------------------------------------------------------------------------------*/

    $(".collapsedInfoForHeading").click(function () {
        $(this).add(".infoFor").toggleClass("active");
        $(this).siblings("h5, div").removeClass("active");
        $(".resources-subNav-login, .resources-subNav-search").removeClass("active");
    });

    $(".collapsedResourcesHeading").click(function () {
        $(this).add(".resources-subNav-login").toggleClass("active");
        $(this).siblings("h5, div").removeClass("active");
        $(".infoFor, .resources-subNav-search").removeClass("active");
    });

    $(".collapsedSearchHeading").click(function () {
        $(this).add(".resources-subNav-search").toggleClass("active");
        $(this).siblings("h5, div").removeClass("active");
        $(".infoFor, .resources-subNav-login").removeClass("active");
        // autofocus search box
        $("#smallSearchBox").css({
            fontSize: '16px'
        }).focus();
    });

});
// usage: log('inside coolFunc', this, arguments);
// paulirish.com/2009/log-a-lightweight-wrapper-for-consolelog/
window.log = function f() {
    log.history = log.history || [];
    log.history.push(arguments);
    if (this.console) {
        var args = arguments;
        var newarr;

        try {
            args.callee = f.caller;
        } catch(e) {

        }

        newarr = [].slice.call(args);

        if (typeof console.log === 'object') {
            log.apply.call(console.log, console, newarr);
        } else {
            console.log.apply(console, newarr);
        }
    }
};

// make it safe to use console.log always
(function(a) {
    function b() {}
    var c = "assert,count,debug,dir,dirxml,error,exception,group,groupCollapsed,groupEnd,info,log,markTimeline,profile,profileEnd,time,timeEnd,trace,warn";
    var d;
    for (c = c.split(","); !!(d = c.pop());) {
        a[d] = a[d] || b;
    }
})(function() {
    try {
        console.log();
        return window.console;
    } catch(a) {
        return (window.console = {});
    }
}());
function removeSrc() {
	$('script').each(function() {
		var old_src = jQuery(this).attr('src');
		$(this).attr('src', 'about:blank');
		//console.log('removed source');
	});
}

$(function() {
	$('.footer .footer-menu .links-header').on('click', function() {
		if ($(document).width() > 420 && $(window).width() > 420) return;

		if ($(this).siblings('ul').hasClass('linksIn')) {
			$(this).siblings('ul').removeClass('linksIn').addClass('linksOut');
			return;
		}

		if ($(this).siblings('ul').hasClass('linksOut')) {
			$(this).siblings('ul').removeClass('linksOut').addClass('linksIn');
			return;
		}

		$(this).siblings('ul').addClass('linksIn');
	});

	$(".footer a[href='#']").click(function() {
		$('html, body').animate({ scrollTop: 0 }, 'slow');
		return false;
	});
});
(function ($) {
  $(document).ready(function () {
    var onHomePage = $('.homepage').length > 0;
    if (onHomePage) {
      cu_window_manager.initialize();
      cu_hero_area.initialize();
      //cu_stories_area.initialize();
      cu_admission_area.initialize();

      heroModalViewer.initialize();
      setGeneralInfoMinHeight();
      animateOnScroll();
      setTimeout(function () { addSquigglyUnderline() }, 1000);

    }
  });

  $(window).on("resize", function (e) {
    setGeneralInfoMinHeight();
  });

  function addSquigglyUnderline() {
    if ($('a.tag').length > 1) {
      $('a.tag').wrapInner("<span class='squiggle squiggle-2-2'></span>");
    }
  }

  function animateOnScroll() {
    $('#generalInformation h2').attr({
      'data-aos': "fade-up",
      'data-aos-duration': "500",
    });

    $('#generalInformation .third:first-of-type').attr({
      'data-aos': "fade-left",
      'data-aos-duration': "500"
    });

    $('#generalInformation .third:nth-child(2n)').attr({
      'data-aos': "fade-left",
      'data-aos-duration': "500",
      'data-aos-delay': '100'
    });

    $('#generalInformation .third:nth-child(3n)').attr({
      'data-aos': "fade-left",
      'data-aos-duration': "500",
      'data-aos-delay': "200"
    });
    // chapmanFamily

    $('#chapmanFamily h2').attr({
      'data-aos': "zoom-in-up",
      'data-aos-duration': "500",
    });

    $('#chapmanFamily .third:first-of-type').attr({
      'data-aos': "zoom-in-right",
      'data-aos-duration': "500"
    });

    $('#chapmanFamily .third:nth-child(2n)').attr({
      'data-aos': "zoom-in-up",
      'data-aos-duration': "500"
    });


    $('#chapmanFamily .third:nth-child(3n)').attr({
      'data-aos': "zoom-in-left",
      'data-aos-duration': "500"
    });

    $('#accessibility-statement').attr({
      'data-aos': "fade-up",
      'data-aos-duration': "500",
    });

    AOS.init({
      // Global settings:
      disable: false, // accepts following values: 'phone', 'tablet', 'mobile', boolean, expression or function
      startEvent: 'DOMContentLoaded', // name of the event dispatched on the document, that AOS should initialize on
      initClassName: 'aos-init', // class applied after initialization
      animatedClassName: 'aos-animate', // class applied on animation
      useClassNames: false, // if true, will add content of `data-aos` as classes on scroll
      disableMutationObserver: false, // disables automatic mutations' detections (advanced)
      debounceDelay: 50, // the delay on debounce used while resizing window (advanced)
      throttleDelay: 99, // the delay on throttle used while scrolling the page (advanced)


      // Settings that can be overridden on per-element basis, by `data-aos-*` attributes:
      offset: 122, // offset (in px) from the original trigger point
      delay: 0, // values from 0 to 3000, with step 50ms
      duration: 400, // values from 0 to 3000, with step 50ms
      easing: 'ease', // default easing for AOS animations
      once: false, // whether animation should happen only once - while scrolling down
      mirror: false, // whether elements should animate out while scrolling past them
      anchorPlacement: 'top-bottom', // defines which position of the element regarding to window should trigger the animation

    });
  }

  function setGeneralInfoMinHeight() {
    var minHeight = 'auto';

    if ($(window).width() < 600) {
      $('#generalInformation .third').attr('height', 'max-content');
    }
    else {
      $('#generalInformation .third').each(function () {
        var thisH = $(this).height();
        if (thisH > minHeight) { minHeight = thisH; }
      });
    }

    $('#generalInformation .third').height(minHeight);
  }
  // A class to manage window resizer and scroller functions
  var cu_window_manager = {
    // Manual Configs
    resizerLatency: 20, // in milliseconds. Higher = less CPU, lower = faster UI
    // Automagic Configs (changed by the script)
    useTransitions: true,
    useParallax: true,
    cannotAutoplayVideo: false,
    // Vars to initialize
    resizeTimeout: null,
    windowWidth: null,
    windowHeight: null,
    scrollTop: null,
    scrollBot: null,
    getVars: null,
    initialize: function () {
      // Check device type
      var i = 0,
        is_iOS = false,
        iDevice = ['iPad', 'iPhone', 'iPod'];
      for (; i < iDevice.length; i++) {
        if (navigator.platform === iDevice[i]) {
          is_iOS = true;
          break;
        }
      }
      var ua = navigator.userAgent.toLowerCase();
      var is_Android = ua.indexOf('android') > -1; //&& ua.indexOf("mobile");
      // Determine if this device cannot autoplay HTML5 video
      if (is_Android || is_iOS) {
        cu_window_manager.cannotAutoplayVideo = true;
        cu_window_manager.useTransitions = true;
      }
      if (
        !/Android|iPhone|iPad|iPod|BlackBerry|Windows Phone/i.test(
          navigator.userAgent || navigator.vendor || window.opera
        )
      ) {
        cu_window_manager.useParallax = true;
        cu_parallax_fx.setupFX();
      } else {
        cu_window_manager.useParallax = false;
      }
      // Set up window change events
      if (window.addEventListener) {
        window.addEventListener('scroll', cu_window_manager.scroller, false);
        window.addEventListener('resize', cu_window_manager.resizer, false);
      } else if (window.attachEvent) {
        window.attachEvent('onscroll', cu_window_manager.scroller);
        window.attachEvent('onresize', cu_window_manager.resizer);
      }
      // Intial vars
      cu_window_manager.scrollTop = $(window).scrollTop();
      cu_window_manager.windowWidth = $(window).width();
      cu_window_manager.windowHeight = $(window).height();
      // Featured story image rotator
      $('#featured_stories').find('.imagerotator').cycle({
        next: '.imagerotator', // selector to advance slide on click
        delay: 0, // additional delay before starting slideshow
        timeout: 2000, // time between transitions
        speed: 1400, // speed of transition
        pause: false, // pause on mouse hover?
        slideExpr: 'img' // only select child elements that match this
      });
      var speeds = [];
      speeds[0] = 0;
      speeds[1] = 4000;
      speeds[2] = 2000;
      $('#generalInformation').find('.imagerotator').each(function (i) {
        $(this).cycle({
          delay: speeds[i], // additional delay before starting slideshow
          timeout: 7000, // time between transitions
          speed: 2000, // speed of transition
          pause: false, // pause on mouse hover?
          slideExpr: 'img' // only select child elements that match this
        });
      });
    }, // end initialize
    /***************************************************
     * The purpose of the resizer function is to act as a buffer to prevent rapid execution of the functions which must run on window resize.
     * By using a timetout, we can reduce the number of times these functions are called to increase browser performance.
     ***************************************************/
    resizer: function () {
      if (cu_window_manager.resizeTimeout != null) {
        clearTimeout(cu_window_manager.resizeTimeout);
      }
      cu_window_manager.resizeTimeout = setTimeout(function () {
        cu_window_manager.resizeTimeout = null;
        // Update vars
        cu_window_manager.windowWidth = $(window).width();
        cu_window_manager.windowHeight = $(window).height();
        // FUNCTIONS TO FIRE ON RESIZE HERE:
        cu_hero_area.adjustVideoSize();
      }, cu_window_manager.resizerLatency);
    }, // end resizer
    scroller: function () {
      // Update vars
      cu_window_manager.scrollTop = $(window).scrollTop();
      cu_window_manager.scrollBot = cu_window_manager.scrollTop + cu_window_manager.windowHeight;
      // FUNCTIONS TO FIRE ON SCROLL HERE:
      if (cu_window_manager.useParallax) cu_parallax_fx.process();
    } // end scroller
  }; // end cu_window_manager
  // Contains the animation FX
  var cu_parallax_fx = {
    enabled: false, // starts false
    skrollr: null,
    admissionStartPX: null,
    admissionAnimationReady: false,
    $undergraduateAdmission: null,
    graduateAdmissionStartPX: null,
    graduateAdmissionAnimationReady: false,
    $graduateAdmission: null,
    // Prep the elements by hiding them as needed. Run only once.
    setupFX: function () {
      /*
       * Undergraduate Admission
       *************************/
      this.$undergraduateAdmission = $('#undergraduateAdmission');
      //This is causing a breaking change "Uncaught TypeError: Cannot read property 'top' of null" in development
      if (this.$undergraduateAdmission.find('.statistics').length > 0) {
        this.admissionStartPX = this.$undergraduateAdmission.find('.statistics').offset().top;
      } else {
        this.admissionStartPX = 0;
      }
      this.$undergraduateAdmission.find('.fade-elem').css('opacity', 0); // prep for fade in
      /*
       * Graduate Admission
       *************************/
      this.$graduateAdmission = $('#graduateAdmission');
      if (this.$graduateAdmission.length > 0) {
        this.graduateAdmissionStartPX = this.$graduateAdmission.offset().top;
      } else {
        this.graduateAdmissionStartPX = 0;
      }
      this.process(); // in case we already scrolled
    },
    // Re-run as needed.
    enable: function () {
      // DO ENABLE TASKS
      try {
        // Do not initialize Skrollr on mobile.
        if (
          !/Android|iPhone|iPad|iPod|BlackBerry|Windows Phone/i.test(
            navigator.userAgent || navigator.vendor || window.opera
          )
        ) {
          cu_parallax_fx.skrollr = skrollr.init({
            forceHeight: false
          });
        }
      } catch (e) {
        // No Skrollr support
      }
      this.graduateAdmissionAnimationReady = true;
      this.admissionAnimationReady = true;
      cu_parallax_fx.enabled = true;
    },
    // Re-run as needed.
    disable: function () {
      // DO DISABLE TASKS
      cu_parallax_fx.skrollr.destroy();
      cu_parallax_fx.enabled = false;
      this.$graduateAdmission.css('background-size', '');
    },
    // Fire on scroll to position elements
    process: function () {
      if (!cu_parallax_fx.enabled && cu_window_manager.windowWidth > 640) {
        cu_parallax_fx.enable();
      } else if (cu_parallax_fx.enabled && cu_window_manager.windowWidth < 640) {
        cu_parallax_fx.disable();
      }
      if (!cu_parallax_fx.enabled) return false;
      /*
       * Undergraduate Admission | number counter
       *************************/
      if (this.admissionAnimationReady && cu_window_manager.scrollBot > this.admissionStartPX) {
        this.animateAdmissionNumbers();
        this.$undergraduateAdmission.find('.fade-elem').each(function (i) {
          var $elem = $(this);
          setTimeout(function () {
            $elem.animate({
              opacity: '1'
            }, 1000, 'linear');
          }, 600 * i);
        });
        this.admissionAnimationReady = false;
      }
      /*
       * Graduate Admission | ken burns
       *************************/
      // TODO: dead code - remove in future.
      // if (this.graduateAdmissionAnimationReady && cu_window_manager.scrollBot > this.graduateAdmissionStartPX ) {
      //  // this.kenBurns(this.$graduateAdmission);
      //  this.graduateAdmissionAnimationReady = false;
      // }
      if (cu_window_manager.scrollTop < 100) {
        // Reset the animation if the user goes to the top.
        this.graduateAdmissionAnimationReady = true;
        this.admissionAnimationReady = true;
      }
    },
    /***************************************************
     * Ken burns FX for BG image of element
     ***************************************************/
    kenBurns: function ($elem) {
      // Do not fire if frame is already visible
      if ($elem.css('background-size') == '100%') {
        $elem.animate({
          'background-size': '120%'
        }, 10000, 'swing');
      } else {
        $elem.css('background-size', '120%');
        $elem.animate({
          'background-size': '100%'
        }, 10000, 'swing');
      }
    },
    animateAdmissionNumbers: function () {
      this.$undergraduateAdmission.find('.statistics').find('li').each(function (i) {
        var $label = $(this).find('.label');
        var $bigstat = $(this).find('.bigstat');
        $bigstat.css('opacity', 0);
        $label.css('opacity', 0);
        setTimeout(function () {
          cu_parallax_fx.animateSingleNumber($bigstat);
          increaseOpactiyWhenVisible();
        }, 100 * Math.floor(Math.random() * 10 + 1));

        function increaseOpactiyWhenVisible() {
          $(window).scroll(function () {
            var scrollTop = $('#undergraduateAdmission').scrollTop();
            $bigstat.animate({
              opacity: 1
            }, 600);
            $label.animate({
              opacity: 1
            }, 400);
          });
        }
      });
    },
    /***************************************************
     * Takes a jQuery element $elem and animates the inner HTML if it is a number.
     * Counts up to 'final_num' from 'start_num' over 'duration' milliseconds.
     ***************************************************/
    animateSingleNumber: function ($elem, final_num, start_num, duration) {
      var original_num = $elem.html();
      // If not set, take inner HTML of elem
      if (!final_num) final_num = parseFloat($elem.html().replace(/,/, ''));
      if ($($elem.attr('data-count').length)) {
        var original_num = $elem.attr('data-count');
      }
      // If not set, count up from zero
      if (!start_num) start_num = 0;
      // If no set, default duration
      if (!duration) duration = 1000;
      // Find number of decimal places
      var decimalPlaces =
        Math.floor(final_num) !== final_num ? final_num.toString().split('.')[1].length || 0 : 0;
      /* jshint ignore:start */
      // complains "Do not use Number as a constructor" but maybe that's needed for test?
      // Test for correct EN locale string conversion
      var goodLocaleStringSupport = new Number(10).toLocaleString() == '10';
      /* jshint ignore:end */
      //Parking count animation
      $({
        countNum: 0
      }).animate({
        countNum: final_num
      }, {
        duration: duration,
        easing: 'swing',
        step: function () {
          // Round to decimal places
          var stepNum = this.countNum.toFixed(decimalPlaces);
          // Add a comma if not a decimal
          if (decimalPlaces == 0 && goodLocaleStringSupport)
            stepNum = parseInt(stepNum).toLocaleString('en');
          $elem.html(stepNum);
        },
        complete: function () {
          $elem.html(original_num);
        }
      });
    }
  }; // end cu_parallax_fx
  var hero_stories_hostname = document.location.hostname == 'localhost' ? 'https://www.chapman.edu/' : 'https://www.chapman.edu/';
  var cu_hero_area = {
    // Configurations
    contentTransitionSpeed: 2000,
    hero_stories_html_dir: hero_stories_hostname.concat('_hero_stories/'),
    // Do not configure these
    videoPlayer: null,
    pastCampaigns: null, // array of campaigns with some data
    currentCampaign: null, // int - the position in the pastCampaigns array
    videoTransitionTimeout: null,
    isChanging: false,
    initialize: function () {
      var requested_story_slug = (location.hash.match(/story-([\w-]+)/) || [])[1]; // undefined, or a string with the story slug
      // Check if we want to start with an older story
      if (requested_story_slug) {
        // Mask the hero space while we load
        $('#mastheadNavigation').hide();
        $('#hero').css('visibility', 'hidden'); // we hide this so it does not fade in on the transition
      } else {
        // Set up the current content
        cu_hero_area.setupContent($('#hero'));
        cu_hero_area.queueExcerptEntrance(100);
      }
      // Fetch past content
      $.getJSON(cu_hero_area.hero_stories_html_dir + 'listing_order.json.txt', function (data) {
        cu_hero_area.currentCampaign = 0;
        cu_hero_area.pastCampaigns = [];
        var keys = data ? Object.keys(data) : [];
        keys.forEach(function (key) {
          /* jshint -W069: ['foo'] is better written in dot notation. */
          // set the slug for this stage
          data[key]['slug'] = data[key]['filename'].substr(0, data[key]['filename'].indexOf('.'));
          // Add to our array
          cu_hero_area.pastCampaigns.push(data[key]);
          // If an older story was requested
          if (requested_story_slug) {
            // Look for the slug filename
            if (data[key]['slug'] == requested_story_slug) {
              cu_hero_area.currentCampaign = cu_hero_area.pastCampaigns.length - 1;
            }
          }
          /* jshint -W069 */
        });
        // If an older story is found and can be loaded
        if (cu_hero_area.currentCampaign != 0) {
          cu_hero_area.processNavigation(cu_hero_area.currentCampaign);
        } else {
          // The older story was requested, but we did not find it. Load default content.
          $('#mastheadNavigation').show();
          $('#hero').css('visibility', '');
          cu_hero_area.setupContent($('#hero'));
          cu_hero_area.queueExcerptEntrance(100);
        }
        if (cu_hero_area.pastCampaigns.length > 1) $('#showOlderContent').removeClass('disabled');
        $('#showOlderContent').hammer().on('tap', function (e) {
          cu_hero_area.processNavigation('older');
          // _gaq.push(['_trackEvent', "Homepage UI Interaction", "Switch hero story", "older"]);
          if (typeof ga !== 'undefined')
            ga('send', 'event', 'Homepage UI Interaction', 'Switch hero story', 'older');
        });
        $('#showNewerContent').hammer().on('tap', function (e) {
          cu_hero_area.processNavigation('newer');
          // _gaq.push(['_trackEvent', "Homepage UI Interaction", "Switch hero story", "newer"]);
          if (typeof ga !== 'undefined')
            ga('send', 'event', 'Homepage UI Interaction', 'Switch hero story', 'newer');
        });
      });
    },
    /***************************************************
     * This function resizes the HTML5 video so that it covers the entire #mastheadBackground element.
     * This simulates the property background-size:cover;
     * This needs to be run every time the browser window is resized.
     ***************************************************/
    adjustVideoSize: function () {
      if (!cu_hero_area.videoPlayer) return false;
      // Get the current video area size
      var container_width = $('#mastheadBackground').outerWidth();
      var container_height = $('#mastheadBackground').outerHeight();
      // use largest scale factor of horizontal/vertical
      var scale_h = container_height / cu_hero_area.videoPlayer.videoHeight;
      var scale_v = container_width / cu_hero_area.videoPlayer.videoWidth;
      var scale = scale_h > scale_v ? scale_h : scale_v;
      var new_video_width = scale * cu_hero_area.videoPlayer.videoWidth;
      var new_video_height = scale * cu_hero_area.videoPlayer.videoHeight;
      // now scale the video
      $('#mastheadVideo').width(new_video_width);
      $('#mastheadVideo').height(new_video_height);
      // and center it by scrolling the video viewport
      $('#mastheadBackground').scrollLeft((new_video_width - container_width) / 2);
      $('#mastheadBackground').scrollTop((new_video_height - container_height) / 2);
    },
    absoluteUrls: function () {
      $('#mastheadVideo source').each(function () {
        videoUrl = $(this).attr('src').replace('/_files', 'http://www.chapman.edu/_files');
        $(this).attr('src', videoUrl);
      });
      if ($('#mastheadImage').length) {
        imageUrl = $('#mastheadImage').attr('src').replace('../', 'http://www.chapman.edu/');
        $('#mastheadImage').attr('src', imageUrl);
        fallbackUrl = $('#hero').css('background-image').replace('localhost:5000', 'www.chapman.edu');
        $('#hero').css('background-image', fallbackUrl);
      }
    },
    setupContent: function ($content) {
      // This fires if working on a development server to change relative image urls to absolute urls
      if (document.location.hostname == 'localhost') cu_hero_area.absoluteUrls();
      // This clears any remaining transitions from the previous content
      if (cu_hero_area.videoTransitionTimeout != null) {
        clearTimeout(cu_hero_area.videoTransitionTimeout);
      }
      cu_hero_area.videoPlayer = $content.find('#mastheadVideo')[0];
      // If video content
      if (
        cu_hero_area.videoPlayer &&
        !cu_window_manager.cannotAutoplayVideo &&
        cu_hero_area.videoPlayer.addEventListener
      ) {
        cu_hero_area.videoPlayer.muted = true; // REQUIRED TO MUTE FOR SAFARI 5.1.3!!!! Does not obey mute property without this line
        cu_hero_area.videoPlayer.addEventListener('canplay', function () {
          // Start the video player
          cu_hero_area.videoPlayer.play();
          // Show the video
          $content.find('#mastheadVideo').fadeIn(1000);
          cu_hero_area.videoTransitionTimeout = setTimeout(function () {
            $content.addClass('video-playing');
          }, 1000);
          cu_hero_area.adjustVideoSize();
        });
      } else {
        // No video content
        $content.removeClass('video-playing');
      }
    },
    queueExcerptEntrance: function (delay_ms) {
      if (!cu_window_manager.useTransitions) return false;
      var $hero = $('#hero');
      $hero.find('.excerpt').css({
        position: 'relative',
        left: '50px',
        opacity: '0'
        // Apply animations to the old outgoing content
      });
      $hero.find('.actions').css({
        position: 'relative',
        left: '100px',
        opacity: '0'
        // Apply animations to the old outgoing content
      });
      setTimeout(function () {
        $hero.find('.excerpt').addClass('fast_transition').css({
          left: '0px',
          opacity: '1'
        });
        $hero.find('.actions').addClass('fast_transition').css({
          left: '0',
          opacity: '1'
        });
      }, delay_ms);
    },
    queueTitleAndExcerptEntrance: function (delay_ms) {
      // Fancy text animations
      if (!cu_window_manager.useTransitions) return false;
      var $hero = $('#hero');
      $('#hero').find('.heading').css({
        position: 'relative',
        left: '50px',
        opacity: '0'
        // Apply animations to the old outgoing content
      });
      $('#hero').find('.subheading').css({
        position: 'relative',
        left: '50px',
        opacity: '0'
        // Apply animations to the old outgoing content
      });
      setTimeout(function () {
        $('#hero').find('.heading').addClass('fast_transition').css({
          left: '0',
          opacity: '1'
        });
        $('#hero').find('.subheading').addClass('fast_transition').css({
          left: '0',
          opacity: '1'
        });
      }, delay_ms);
      cu_hero_area.queueExcerptEntrance(delay_ms * 1.5);
    },
    // Accepts an int ID of a slide, or the string 'older' or 'newer' then transitions to that slide.
    processNavigation: function (input) {
      if (cu_hero_area.isChanging) return false;
      cu_hero_area.isChanging = true;
      var max = cu_hero_area.pastCampaigns.length - 1; // zero based
      var min = 0;
      var direction = 'older'; // default transition
      var current_num = cu_hero_area.currentCampaign;
      if (input == 'newer') {
        direction = 'newer';
        current_num--;
      } else if (input == 'older') {
        direction = 'older';
        current_num++;
      } else if (typeof input === 'number' && input % 1 == 0) {
        current_num = input;
      }
      if (current_num < min) return false;
      if (current_num > max) return false;
      cu_hero_area.currentCampaign = current_num;
      if (cu_window_manager.useTransitions) {
        $('#mastheadNavigation').fadeOut();
      }
      /* jshint -W069: ['foo'] is better written in dot notation. */
      // Check for a local cached copy of this HTML
      if (cu_hero_area.pastCampaigns[current_num]['html']) {
        cu_hero_area.transitionToStory(cu_hero_area.pastCampaigns[current_num]['html'], direction);
      } else {
        var newFile = cu_hero_area.pastCampaigns[current_num]['filename'];
        $.get(cu_hero_area.hero_stories_html_dir + newFile, function (data) {
          cu_hero_area.pastCampaigns[current_num]['html'] = data;
          cu_hero_area.transitionToStory(data, direction);
        });
      }
      // Update the URL
      location.hash = '#story-' + cu_hero_area.pastCampaigns[current_num]['slug'];
      /* jshint +W069 */
    }, // end processNavigation
    transitionToStory: function (raw_html, direction) {
      $new_content = $(raw_html);
      $old_content = $('#hero');
      // Check for extra HTML wrap
      if ($new_content.find('#hero').length > 0) {
        $new_content = $new_content.find('#hero');
      }
      if (cu_window_manager.useTransitions) {
        $new_content
          .css({
            opacity: 0
          })
          .addClass('fast_transition');
        $old_content
          .css({
            opacity: 1,
            'margin-top': '-' + $('#hero').outerHeight() + 'px'
          })
          .addClass('fast_transition');
        $old_content.before($new_content);
        // Need to wait until the transition class is in the DOM
        setTimeout(
          function () {
            $new_content.css({
              opacity: 1
            });
            $old_content.css({
              opacity: 0
            });
          },
          250,
          $new_content,
          $old_content
        );
        // Wait until the transition is complete
        setTimeout(
          function () {
            // Remove the old content from the DOM
            $old_content.remove();
          },
          cu_hero_area.contentTransitionSpeed,
          $old_content
        );
      } else {
        $('#hero').before(raw_html).remove();
      }
      cu_hero_area.setupContent($new_content);
      if (direction == 'newer') {
        cu_hero_area.queueTitleAndExcerptEntrance(cu_hero_area.contentTransitionSpeed / 2.5);
      } else {
        cu_hero_area.queueTitleAndExcerptEntrance(cu_hero_area.contentTransitionSpeed / 3.3);
      }
      var timeToHideNav = cu_window_manager.useTransitions ? cu_hero_area.contentTransitionSpeed : 10;
      // Tasks after the switch is complete
      setTimeout(function () {
        var current_num = cu_hero_area.currentCampaign;
        var max = cu_hero_area.pastCampaigns.length - 1; // zero based
        var min = 0;
        $('#mastheadNavigation').fadeIn();
        if (current_num == min) $('#showNewerContent').addClass('disabled');
        if (current_num == max) $('#showOlderContent').addClass('disabled');
        // Show the buttons if we aren't at an end of the list
        if (current_num != min) $('#showNewerContent').removeClass('disabled');
        if (current_num != max) $('#showOlderContent').removeClass('disabled');
        cu_hero_area.isChanging = false;
      }, timeToHideNav);
    }
  }; // end cu_hero_area
  var cu_admission_area = {
    formTransitionSpeed: 400,
    $admissionCTA: null,
    initialize: function () {
      this.$admissionCTA = $('#admissionCTA');
      this.switchToMode('hide');
      $('.admissionCTA_start').on('click', function (e) {
        cu_admission_area.setupFormHTML(e);
        // cu_admission_area.switchToMode('hide');
        $(this)
          .slideUp(cu_admission_area.formTransitionSpeed)
          .siblings('a')
          .slideUp(cu_admission_area.formTransitionSpeed);
        cu_admission_area.switchToMode('student_type');
      });
      $('input[name="student_type"]').on('change', function () {
        cu_admission_area.switchToMode('student_details');
      });
      this.$admissionCTA.find('#admissionCTA_form').on('submit', function (e) {
        e.preventDefault();
        cu_admission_area.submitForm();
        return false;
      });
    },
    setupFormHTML: function (e) {
      if (!$(e.currentTarget).siblings('#admissionCTA').length) {
        // Move the form here
        $(e.currentTarget).parent().append(cu_admission_area.$admissionCTA.detach());
      }
    },
    switchToMode: function (mode) {
      if (mode == 'student_type') {
        // this.$admissionCTA.css('max-height', '0px');
        this.$admissionCTA.find('#admissionCTA_form').show();
        this.$admissionCTA.find('.student_type_section').slideDown(cu_admission_area.formTransitionSpeed);
        // Uncheck radio button
        this.$admissionCTA.find('input[type="radio"]').prop('checked', false);
      } else if (mode == 'student_details') {
        // this.$admissionCTA.css('max-height', '999px');
        this.$admissionCTA.find('#admissionCTA_form').show();
        this.$admissionCTA.find('.student_details_section').slideDown(cu_admission_area.formTransitionSpeed);
      } else if (mode == 'hide') {
        var $student_type_section = this.$admissionCTA.find('.student_type_section');
        var $student_details_section = this.$admissionCTA.find('.student_details_section');
        $student_type_section.css('height', $student_type_section.height()).hide();
        $student_details_section.css('height', $student_details_section.outerHeight()).hide();
        this.$admissionCTA.find('#admissionCTA_form').hide();
      }
      return;
    },
    submitForm: function () {
      var name = this.$admissionCTA.find('input:text[name=name]').val();
      var email = this.$admissionCTA.find('input:text[name=email]').val();
      var email_regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
      var is_valid_email = email_regex.test(email);
      if (name == 'Full Name' || name.length < 2) {
        // alert("Please enter your name.");
        // return false;
      }
      if (email == 'Email Address' || email.length < 2 || !is_valid_email) {
        // alert("Please enter a valid email address.");
        // return false;
      }
      this.$admissionCTA.find('.student_type_section').slideUp(cu_admission_area.formTransitionSpeed);
      this.$admissionCTA.find('.student_details_section').slideUp(cu_admission_area.formTransitionSpeed);
      setTimeout(function () {
        cu_admission_area.$admissionCTA.find('#admissionCTA_form').hide();
      }, cu_admission_area.formTransitionSpeed);
      this.$admissionCTA
        .find('.status')
        .hide()
        .html(
          '<b>Thanks, ' +
          name +
          '! </b><br><small>The <a href="http://www.chapman.edu/admission/">CU admissions</a> team will be in touch soon.</small>'
        )
        .fadeIn();
      $('.admissionCTA_start').hide();
      return false;
    }
  }; // end cu_admission_area
  /*
   * Hero Modal Viewer
   * Creates in-page modal view for videos and images.
   *
   * Refactors an existing home-rolled modal, which includes preserving some design quirks
   * where the logic behind them was not explained and the effects of changing them unknown.
   * Prompted by https://github.com/chapmanu/cascade-assets/issues/93.
   */
  var heroModalViewer = (function () {
    // Selectors
    // These are inherited from legacy version and tied to existing stylesheets.
    var HERO_WRAPPER_SELECTOR = 'div#heroWrapper';
    var MODAL_ID = 'heroQuickView';
    var MODAL_CELL_ID = 'heroQuickViewCell';
    var TRIGGER_SELECTOR = 'a[data-quickview-content]';
    var MODAL_OPEN_CLASS = 'heroQuickViewOpen';
    // Data Attribute IDs
    var PREVIOUS_OVERFLOW_DATA_ID = 'hero-previous-overflow';
    var SCROLL_POSITION_DATA_ID = 'hero-scroll-position';
    // jQuery DOM Elements
    var $modal = null;
    var $modalCell = null;
    var $window = null;
    var $html = null;
    var $body = null;
    var $heroWrapper = null;
    // Other Variables
    var isLocked = false;
    // Public Functions
    var initialize = function () {
      // Initalize DOM elements.
      $window = $(window);
      $html = $('html');
      $body = $('body');
      $heroWrapper = $(HERO_WRAPPER_SELECTOR);
      // Build and attach modal to DOM.
      $modal = buildModal();
      $heroWrapper.after($modal);
      // Handle modal events.
      $heroWrapper.on('click', TRIGGER_SELECTOR, function (e) {
        openModal(e);
      });
      $modal.on('click', closeModal);
      $body.on('keyup', function (e) {
        closeModalOnEscape(e);
      });
    };
    // Private Functions
    var buildModal = function () {
      $modal = $('<div />').attr('id', MODAL_ID);
      $modalCell = $('<div />').attr('id', MODAL_CELL_ID);
      $modal.append($modalCell);
      return $modal;
    };
    var openModal = function (e) {
      var MIN_WINDOW_WIDTH = 640;
      var modifierKey = e.metaKey || e.ctrlKey;
      var modalContent = $(e.currentTarget).attr('data-quickview-content');
      // Do not intercept URLs that are alt clicked or in small windows.
      if (modifierKey) {
        return;
      } else if ($window.width() <= MIN_WINDOW_WIDTH) {
        // Do not intercept in small windows.
        return;
      } else if (!modalContent) {
        // Do not intercept if content is empty.
        return;
      } else {
        // Go!
        fadeInModal(modalContent, 500);
        // Disable redirect.
        e.preventDefault();
        return false;
      }
    };
    var fadeInModal = function (modalContent, milliSecDuration) {
      var cellHeight = $window.height() + 'px';
      var cellWidth = $window.width() + 'px';
      $modalCell.append(modalContent).css('height', cellHeight).css('width', cellWidth);
      $modal.fadeIn(milliSecDuration);
      lockScroll();
      $body.addClass(MODAL_OPEN_CLASS);
    };
    var closeModal = function () {
      $modal.fadeOut(40, function () {
        $modalCell.empty();
      });
      unlockScroll();
      $body.removeClass(MODAL_OPEN_CLASS);
    };
    var lockScroll = function () {
      // Retain settings for later.
      var scrollPosition = [
        document.documentElement.scrollLeft || document.body.scrollLeft,
        document.documentElement.scrollTop || document.body.scrollTop
      ];
      $html.data(SCROLL_POSITION_DATA_ID, scrollPosition);
      $html.data(PREVIOUS_OVERFLOW_DATA_ID, $html.css('overflow'));
      // Lock scroll position.
      // IE7 requires applying this to html rather than body.
      isScrollLocked = true;
      $html.css('overflow', 'hidden');
      // Note: this needs to be window not $window.
      window.scrollTo(scrollPosition[0], scrollPosition[1]);
    };
    var unlockScroll = function () {
      if (!isScrollLocked) {
        return false;
      }
      var previousOverflow = $html.data(PREVIOUS_OVERFLOW_DATA_ID);
      var scrollPosition = $html.data(SCROLL_POSITION_DATA_ID);
      $html.css('overflow', previousOverflow);
      // Note: this needs to be window not $window.q
      window.scrollTo(scrollPosition[0], scrollPosition[1]);
    };
    var closeModalOnEscape = function (e) {
      if (e.which == 27) {
        closeModal();
      }
    };
    // Public API
    return {
      initialize: initialize
    };
  })(); // End heroModalViewer.
})(jQuery);
// Define Lazybind
(function ($) {
  $.fn.lazybind = function (event, fn, timeout, abort) {
    var timer = null;
    $(this).bind(event, function (e) {
      var ev = e;
      timer = setTimeout(function () {
        fn(ev);
      }, timeout);
    });
    if (abort == undefined) {
      return;
    }
    $(this).bind(abort, function () {
      if (timer != null) {
        clearTimeout(timer);
      }
    });
  };
})(jQuery);
// Object.keys pollyfill for older IE
if (!Object.keys) {
  Object.keys = (function () {
    var hasOwnProperty = Object.prototype.hasOwnProperty,
      hasDontEnumBug = !{
        toString: null
      }.propertyIsEnumerable('toString'),
      dontEnums = [
        'toString',
        'toLocaleString',
        'valueOf',
        'hasOwnProperty',
        'isPrototypeOf',
        'propertyIsEnumerable',
        'constructor'
      ],
      dontEnumsLength = dontEnums.length;
    return function (obj) {
      if ((typeof obj !== 'object' && typeof obj !== 'function') || obj === null)
        throw new TypeError('Object.keys called on non-object');
      var result = [];
      for (var prop in obj) {
        if (hasOwnProperty.call(obj, prop)) result.push(prop);
      }
      if (hasDontEnumBug) {
        for (var i = 0; i < dontEnumsLength; i++) {
          if (hasOwnProperty.call(obj, dontEnums[i])) result.push(dontEnums[i]);
        }
      }
      return result;
    };
  })();
}
// Array.forEach pollyfill for older IE
if (!Array.prototype.forEach) {
  Array.prototype.forEach = function (fun /*, thisp*/) {
    var len = this.length;
    if (typeof fun != 'function') throw new TypeError();
    var thisp = arguments[1];
    for (var i = 0; i < len; i++) {
      if (i in this) fun.call(thisp, this[i], i, this);
    }
  };
  if ($($elem.attr('data-count').length)) {
    var original_num = $elem.attr('data-count');
  }
}

// FIX MOBILE UNDERGRADUATE SECTION
if ($(window).width() < 678 && $('.homepage').length > 0) {
  $(window).on('scroll', function () {
    $('#undergraduateAdmission').find('.fade-elem').each(function (i) {
      var el = $(this);
      setTimeout(function () {
        el.animate({
          opacity: '1'
        }, 1000, 'linear');
      }, 600 * i);
    });
    $('#undergraduateAdmission').find('.bigstat').each(function (i) {
      var el = $(this);
      if ($(el.attr('data-count').length)) {
        var original_num = $(el).attr('data-count');
        $(el).html(original_num);
      }
      setTimeout(function () {
        el.animate({
          opacity: '1'
        }, 1000, 'linear');
      }, 600 * i);
    });
  });
}



;
$(function () {
    // IMPORTANT for ie11 CSS fallbacks
    var isIE11 = !!navigator.userAgent.match(/Trident.*rv\:11\./);
    if (isIE11) {
        // $('html').addClass('ie');
    }
    /* IE 7 dialog */
    var IE7Dialog = '<div style="position: relative; margin-top: -15px; top: 0; height: 45px; background: #f2e842;" id="ie7_dialog"><p style="color: #5d591c; line-height: 45px; text-align: center; font-weight: bold;">It would appear you are running an outdated version of Internet Explorer. Please <a style="color: #5d591c; text-decoration: underline;" href="/upgrade-browser.aspx">download a modern browser</a> to ensure a pleasant browsing experience.</p></div>';
    $('body.ie7').prepend(IE7Dialog);
    /* end IE 7 dialog */
    // JSON, because IE7 smells funny and is made fun of at school
    var JSON; if (!JSON) { JSON = {} } (function () { function f(a) { return a < 10 ? "0" + a : a } function quote(a) { escapable.lastIndex = 0; return escapable.test(a) ? '"' + a.replace(escapable, function (a) { var b = meta[a]; return typeof b === "string" ? b : "\\u" + ("0000" + a.charCodeAt(0).toString(16)).slice(-4) }) + '"' : '"' + a + '"' } function str(a, b) { var c, d, e, f, g = gap, h, i = b[a]; if (i && typeof i === "object" && typeof i.toJSON === "function") { i = i.toJSON(a) } if (typeof rep === "function") { i = rep.call(b, a, i) } switch (typeof i) { case "string": return quote(i); case "number": return isFinite(i) ? String(i) : "null"; case "boolean": case "null": return String(i); case "object": if (!i) { return "null" } gap += indent; h = []; if (Object.prototype.toString.apply(i) === "[object Array]") { f = i.length; for (c = 0; c < f; c += 1) { h[c] = str(c, i) || "null" } e = h.length === 0 ? "[]" : gap ? "[\n" + gap + h.join(",\n" + gap) + "\n" + g + "]" : "[" + h.join(",") + "]"; gap = g; return e } if (rep && typeof rep === "object") { f = rep.length; for (c = 0; c < f; c += 1) { if (typeof rep[c] === "string") { d = rep[c]; e = str(d, i); if (e) { h.push(quote(d) + (gap ? ": " : ":") + e) } } } } else { for (d in i) { if (Object.prototype.hasOwnProperty.call(i, d)) { e = str(d, i); if (e) { h.push(quote(d) + (gap ? ": " : ":") + e) } } } } e = h.length === 0 ? "{}" : gap ? "{\n" + gap + h.join(",\n" + gap) + "\n" + g + "}" : "{" + h.join(",") + "}"; gap = g; return e } } "use strict"; if (typeof Date.prototype.toJSON !== "function") { Date.prototype.toJSON = function (a) { return isFinite(this.valueOf()) ? this.getUTCFullYear() + "-" + f(this.getUTCMonth() + 1) + "-" + f(this.getUTCDate()) + "T" + f(this.getUTCHours()) + ":" + f(this.getUTCMinutes()) + ":" + f(this.getUTCSeconds()) + "Z" : null }; String.prototype.toJSON = Number.prototype.toJSON = Boolean.prototype.toJSON = function (a) { return this.valueOf() } } var cx = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g, escapable = /[\\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g, gap, indent, meta = { "\b": "\\b", "   ": "\\t", "\n": "\\n", "\f": "\\f", "\r": "\\r", '"': '\\"', "\\": "\\\\" }, rep; if (typeof JSON.stringify !== "function") { JSON.stringify = function (a, b, c) { var d; gap = ""; indent = ""; if (typeof c === "number") { for (d = 0; d < c; d += 1) { indent += " " } } else if (typeof c === "string") { indent = c } rep = b; if (b && typeof b !== "function" && (typeof b !== "object" || typeof b.length !== "number")) { throw new Error("JSON.stringify") } return str("", { "": a }) } } if (typeof JSON.parse !== "function") { JSON.parse = function (text, reviver) { function walk(a, b) { var c, d, e = a[b]; if (e && typeof e === "object") { for (c in e) { if (Object.prototype.hasOwnProperty.call(e, c)) { d = walk(e, c); if (d !== undefined) { e[c] = d } else { delete e[c] } } } } return reviver.call(a, b, e) } var j; text = String(text); cx.lastIndex = 0; if (cx.test(text)) { text = text.replace(cx, function (a) { return "\\u" + ("0000" + a.charCodeAt(0).toString(16)).slice(-4) }) } if (/^[\],:{}\s]*$/.test(text.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, "@").replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, "]").replace(/(?:^|:|,)(?:\s*\[)+/g, ""))) { j = eval("(" + text + ")"); return typeof reviver === "function" ? walk({ "": j }, "") : j } throw new SyntaxError("JSON.parse") } } })();
});
'use strict';

/* global BREI, _gaq */

var chapman = chapman || {};
var main = chapman.main || {};

(function ($, Modernizr, window, document) {

	/**
	 * Main
	 */
	main.mainInit = function()
	{
		main.ui();

		$('.footer-links-group > h2, .footer-links-group > h3').click(function() {
			$(this).parent().toggleClass('is-visible');
		});
	};

	main.ui = function()
	{
		var $visibleUi;
		var $body = $('body');

        function documentTap(e)
	    {

	    	if(!$(e.target).hasClass('resources-nav-btn'))
	    	{
		    	var $target = $(e.target);
		    	var $parents = $target.parents('.resources-subNav');
		    	var $audienceNav = $target.parents('.infoFor-menu');

		    	if($visibleUi !== undefined) {
		    		if($audienceNav.length === 0 && $parents.length === 0 && $visibleUi && $visibleUi[0] !== $target[0])
		        		hideUi(e);
		        }
		    }
	    }

	    $body.on('click touchstart', function(e)
    	{
    		documentTap(e);
    	});

	    function hideUi(e)
	    {
	    	if($visibleUi)
	        	$visibleUi.removeClass('is-visible');

	        $('.resources-nav-btn').removeClass('is-active');

	        $visibleUi = null;
	    }

	    function isSame($el)
	    {
	    	var isSame = false;

	    	if($visibleUi)
	    	{
	    		if($el[0] === $visibleUi[0])
	    			isSame = true;
	    	}

	    	return isSame;
	    }

	    function toggleUi($el, e)
	    {
	    	var isVisible = $el.hasClass('is-visible') ? true : false;

	    	if($visibleUi)
	    	{
	    		if($el[0] !== $visibleUi[0])
	    			hideUi();
	    	}

	        $visibleUi = $el;

	        if(!isVisible)
	        {
	            $el.addClass('is-visible');

	            if(e != undefined)
	            {
	            	$(e.currentTarget).addClass('is-active');
	            }
	        }
	        else
	        {
	            $el.removeClass('is-visible');
	            if(e != undefined)
	            {
	            	$(e.currentTarget).removeClass('is-active');
	            }
	            $visibleUi = null;
	        }
	    }

	    // mir.aculo.us/2011/03/09/little-helpers-a-tweet-sized-javascript-templating-engine/
		function t(s, d)
		{
		    for(var p in d)
		        s=s.replace(new RegExp('{'+p+'}','g'), d[p]);
		    return s;
		};

		/**
	     * Main Nav li:hover show/hide subNav
	     */
	    if(!Modernizr.csstransitions)
	    {
		    $('.mainNavLinks .has-dropdown').hoverIntent(
	            function()
	            {
	                $(this).children('.subNavLinks').addClass('is-visible');
	            },
	            function()
	            {
	                $(this).children('.subNavLinks').removeClass('is-visible');
	            }
	        );
		}

	    /**
	     * Resources nav li:hover show/hide subNav
	     */
	    $('.resources-nav .resources-nav-btn').click(function(e)
	    {
	    	var toggle = $(this).parent().children('div');
	        toggleUi(toggle, e);

	        return false;
	    });

	    /**
	     *
	     */
	    $('#infoFor-btn').click(function()
	    {
	    	var toggle = $(this).parent('div').children('.infoFor-menu');

	        if(!isSame(toggle))
	        	toggleUi(toggle);

	        return false;
	    });

	    /**
		 * enables the fancy triangle rollover
		 */
		$('#mainNavLinks li:first').hover(function() {
	        $('#mainNavLinks').addClass('active');
	    }, function () {
	        $('#mainNavLinks').removeClass('active');
	    });

	    /* Set copyright date to current year
	    ------------------------------------------------------------------------------------------------*/

	    (function () {
	        var today = new Date();
	        $(".copyrightYear").html(today.getFullYear());
	    })();

	    //$.getScript("/_files/level/js/welcome.js");

	    /* New Nav */
	    $('.mainNavExpand').bind('click', function() {
	        $('.mainNav').toggleClass('open');
	        if ($('.mainNav').hasClass('open')) {
	            $('.mainNavExpand .arrow').html('&#8963;');
	        } else {
	            $('.mainNavExpand .arrow').html('&#8964;');
	        }
	    });

	};

	$(function()
	{
		main.mainInit();
	});

})(window.jQuery, window.Modernizr, window, window.document);
// <!--
  //this copy of js file from _chapman_common
  
    //added so can replace (dynamically when page is viewed in browser) with domain of server that webpage is being viewed on. will put V_HTTP_HOST in redirect_url field in hidden form field:
    $( document ).ready(function() {
        var elements = document.getElementsByName("redirect_url");
        for (var i = 0; i < elements.length; i++){
            var old_value = elements[i].value;
            var new_value = old_value.replace("V_HTTP_HOST", document.location.host);
            elements[i].value = new_value;
        }
    });


    //used to populate a dropdown with times. 
    // selector is fieldname, 
    // startTime or endTime is 0 for 12am, 30 for 12:30am etc.
    // increment is how many minutes different each value in dropdown is eg 30 for every 30 minutes, 60 for each hour etc)
    function populateTime(selector, startTime, endTime, increment) {
        var select = $(selector);
        var hours, minutes, ampm;
		var finaltime;
        for(var i = startTime; i <= endTime; i += increment){
            hours = Math.floor(i / 60);
            minutes = i % 60;
            if (minutes < 10){
                minutes = '0' + minutes; // adding leading zero
            }
            ampm = hours % 24 < 12 ? 'AM' : 'PM';
            hours = hours % 12;
            if (hours === 0){
                hours = 12;
            }
			finaltime = hours + ':' + minutes + ' ' + ampm;
            select.append($('<option></option>')
                .attr('value', finaltime)
                .text(finaltime)); 
        }
    }


    // used to validate radio button collection (tests if at least 1 is checked):
    function checkRadioSelected (obj) 
    {           
        for (i=0, n=obj.length; i<n; i++) 
        {
            if (obj[i].checked) 
            {
                //var checkvalue = obj[i].value;
                return true;
                break;
            }
        }
    }


    //used to validate drop-down list boxes:
    function ChkSelected(fld,fldNam)
    {
        if (fld.selectedIndex == -1 || fld.value=="") 
        {   alert (fldNam + " is required. Please select one");
            fld.focus();
            return false;
        }
        else return true;
    }

    //used to validate check boxes:
    function ChkBoxChecked(fld,fldNam)
    {   
        var checkbox_choices = 0;
        
        //Loop from zero to the one minus the number of checkbox button selections
        
        for (counter = 0; counter < fld.length; counter++)
        {   
            // If a checkbox has been selected it will return true, otherwise false
            if (fld[counter].checked)
            {
                checkbox_choices = checkbox_choices + 1; 
            }
        }
        
        if (checkbox_choices == 0) 
        {   alert (fldNam + " is required. Please check at least one");
            //fld[0].focus();
            return false;
        }
        else return true;
    }

    function SingleChkBoxChecked(fld,fldNam)
    {   
    
            // If a checkbox has been selected it will return true, otherwise false
            if (fld.checked != true) {  
                alert (fldNam + " is required.");
                return false;
            }
            else return true;
    }

    
    //used to validate text boxes:
    function ChkLength(fld,minAllowed,fldNam,ReqdFlag) {
                //alert("fld: " + fld);
                //alert("minAllowed: " + minAllowed);
                //alert("fldNam: " + fldNam);
                //alert(".value: " + fld.value);
                //alert(".value.length: " + fld.value.length);
               if (ReqdFlag == "y" && fld.value.length == 0)
                {
                            window.alert(fldNam + " is required.");
                            fld.focus();
                        return false;
                }
 
                else if (ReqdFlag == "y" && fld.value.length < minAllowed)
                {
                            window.alert(fldNam + " should be at least " + minAllowed + " characters");
                            fld.focus();
                        return false;
                }
               
                else if (fld.value.length < minAllowed && fld.value.length > 1)
                {
                        window.alert(fldNam + " should be at least " + minAllowed + " characters");
                        fld.focus();
                        return false;
                }
              
                else return true;
    }
    
// general purpose function to see if an input value has been entered at all
    function isEmpty(inputStr) {
        if ((inputStr == null) || (inputStr == "")) {
            return true;
        }
        return false;
    }
//general purpose function to see if a suspected number is a number, (only positive number)
    function isNumber(inputVal) {
        
        for (var i=0; i < inputVal.length; i++) {
            var oneChar = inputVal.charAt(i);
            if ((oneChar < "0") || (oneChar > "9")) {
                return false;
            }
        }
        return true;
    }
    
//general purpose function to see if a suspected number is a positive integer
    function isInteger(inputVal) {
        inputStr = inputVal.toString();
        for (var i=0; i < inputStr.length; i++) {
            var oneChar = inputStr.charAt(i);
            if ((oneChar < "0") || (oneChar > "9")) {
                return false;
            }
        }
        return true;
    }
 
// THIS ONE DOESN'T SEEM TO WORK -- USE checkEmail function which follows this one instead:
    function validEmail(v_string) {
            var v_cnt=0;
            inputStr = v_string.toString();
            if (inputStr != null) {
                    for (i = 0; i < inputStr.length; i++) {
                            v_char = inputStr.substring(i, i+1);
                            if (v_char == "@" || v_char == ".") 
                            v_cnt = v_cnt + 1;
                    }
            }
            //  if (v_string.length == 0 || v_cnt >= 2) {
            if (inputStr == null || inputStr.length == 0 || v_cnt >= 2) { 
                        return true; 
        }
            else  {
            //alert("v_cnt: " + v_cnt + " inputStr.length: " + inputStr.length);
            return false; 
        }
    }
    
    // <!-- This script and many more are available free online at -->
// <!-- The JavaScript Source. http://javascript.internet.com -->

// <!-- Begin
function checkEmail_OLD(frmFld) {
if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(frmFld.value)){
return (true)
}
alert("Invalid E-mail Address. Please re-enter.")
return (false)
}
//  End -->

// <!-- Begin (9/21/12 added trimmed_email to remove leading and trailing spaces)
function checkEmail(frmFld) {
var trimmed_email = frmFld.value.replace(/^\s+|\s+$/g,"");
if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(trimmed_email)){
return (true)
}
alert("Invalid e-mail Address. Please re-enter.")
return (false)
}
//  End -->


// <!-- These DATE VALIDATION scripts and many more are available free online at -->
// <!-- The JavaScript Source. http://javascript.internet.com -->

//  Beginning of Date Validaton routines 
function checkdate(objName,fldNam) {
var datefield = objName;
if (chkdate(objName) == false) {
datefield.select();
alert(fldNam + " is not a valid date");
datefield.focus();
return false;
}
else {
return true;
   }
}
function chkdate(objName) {
var strDatestyle = "US"; //United States date style
//var strDatestyle = "EU";  //European date style
var strDate;
var strDateArray;
var strDay;
var strMonth;
var strYear;
var intday;
var intMonth;
var intYear;
var booFound = false;
var datefield = objName;
var strSeparatorArray = new Array("-"," ","/",".");
var intElementNr;
var err = 0;
var strMonthArray = new Array(12);
strMonthArray[0] = "Jan";
strMonthArray[1] = "Feb";
strMonthArray[2] = "Mar";
strMonthArray[3] = "Apr";
strMonthArray[4] = "May";
strMonthArray[5] = "Jun";
strMonthArray[6] = "Jul";
strMonthArray[7] = "Aug";
strMonthArray[8] = "Sep";
strMonthArray[9] = "Oct";
strMonthArray[10] = "Nov";
strMonthArray[11] = "Dec";
strDate = datefield.value;
if (strDate.length < 1) {
return true;
}
for (intElementNr = 0; intElementNr < strSeparatorArray.length; intElementNr++) {
if (strDate.indexOf(strSeparatorArray[intElementNr]) != -1) {
strDateArray = strDate.split(strSeparatorArray[intElementNr]);
if (strDateArray.length != 3) {
err = 1;
return false;
}
else {
strDay = strDateArray[0];
strMonth = strDateArray[1];
strYear = strDateArray[2];
}
booFound = true;
   }
}
if (booFound == false) {
if (strDate.length>5) {
strDay = strDate.substr(0, 2);
strMonth = strDate.substr(2, 2);
strYear = strDate.substr(4);
   }
}
if (strYear.length == 2) {
strYear = '20' + strYear;
}
// US style
if (strDatestyle == "US") {
strTemp = strDay;
strDay = strMonth;
strMonth = strTemp;
}
intday = parseInt(strDay, 10);
if (isNaN(intday)) {
err = 2;
return false;
}
intMonth = parseInt(strMonth, 10);
if (isNaN(intMonth)) {
for (i = 0;i<12;i++) {
if (strMonth.toUpperCase() == strMonthArray[i].toUpperCase()) {
intMonth = i+1;
strMonth = strMonthArray[i];
i = 12;
   }
}
if (isNaN(intMonth)) {
err = 3;
return false;
   }
}
intYear = parseInt(strYear, 10);
if (isNaN(intYear)) {
err = 4;
return false;
}
if (intMonth>12 || intMonth<1) {
err = 5;
return false;
}
if ((intMonth == 1 || intMonth == 3 || intMonth == 5 || intMonth == 7 || intMonth == 8 || intMonth == 10 || intMonth == 12) && (intday > 31 || intday < 1)) {
err = 6;
return false;
}
if ((intMonth == 4 || intMonth == 6 || intMonth == 9 || intMonth == 11) && (intday > 30 || intday < 1)) {
err = 7;
return false;
}
if (intMonth == 2) {
if (intday < 1) {
err = 8;
return false;
}
if (LeapYear(intYear) == true) {
if (intday > 29) {
err = 9;
return false;
}
}
else {
if (intday > 28) {
err = 10;
return false;
}
}
}
if (strDatestyle == "US") {
//datefield.value = strMonthArray[intMonth-1] + " " + intday+" " + strYear;
datefield.value = intMonth + "/" + intday +"/" + strYear;
}
else {
//datefield.value = intday + " " + strMonthArray[intMonth-1] + " " + strYear;
datefield.value = intday + "/" + intMonth + "/" + strYear;
}
return true;
}
function LeapYear(intYear) {
if (intYear % 100 == 0) {
if (intYear % 400 == 0) { return true; }
}
else {
if ((intYear % 4) == 0) { return true; }
}
return false;
}
function doDateCheck(from, to) {
if (Date.parse(from.value) <= Date.parse(to.value)) {
alert("The dates are valid.");
}
else {
if (from.value == "" || to.value == "") 
alert("Both dates must be entered.");
else 
alert("To date must occur after the from date.");
   }
}
//  End of Date Validaton routines 


//-->
;
$(function () {

    if ( $('html').find('#omni-nav-v2').length === 0 ) {
        /* evaluate query string to see if param to set an open collapsible or tab 
        ---------------------------------------------------------------------------*/
        var urlParams = {};
        (function () {
            var e,
                a = /\+/g,  // Regex for replacing addition symbol with a space
                r = /([^&=]+)=?([^&]*)/g,
                d = function (s) { return decodeURIComponent(s.replace(a, " ")); },
                q = window.location.search.substring(1);

            while (e = r.exec(q))
            urlParams[d(e[1])] = d(e[2]);
        })();  

        /* Used with Collapsibles widget. 
        ----------------------------------*/
        if ((urlParams["openregion"] != undefined) && (urlParams["openregion"] == parseInt(urlParams["openregion"])) && urlParams["openregion"] - 1 < $(".collapsibles-widget .accordion").length) {

            // Offset for zero based arrays
            if (urlParams["openregion"] != 0) 
                urlParams["openregion"] = urlParams["openregion"] - 1;
            
            var $activeElementRegion = $(".collapsibles-widget .accordion").eq(urlParams["openregion"]);

            // Add the active class to nth accordion and remove all other active classes
            $activeElementRegion.addClass("active").siblings().removeClass("active");

            // Display the current region
            $activeElementRegion.find("div.collapsibles-widget").show();

            // Hide the other regions
            $activeElementRegion.siblings().find("div.content").hide();
            
            // Scroll to the active element (offset by 50 because behind omni-nav)
            setTimeout(function(){
               $('html, body').stop().animate({
                    scrollTop:$activeElementRegion.offset().top -50 
                },1000) ;
            },250);
        }
        /* End open collapsible */
        
        /* Used with Tabs widget.
        -------------------------*/ 
        if ((urlParams["startingtab"] != undefined) && (urlParams["startingtab"] == parseInt(urlParams["startingtab"])) && (urlParams["startingtab"] - 1 < $(".main .tabs-nav li").length)) {
            // Offset for zero based arrays
            if (urlParams["startingtab"] != 0)
                urlParams["startingtab"] = urlParams["startingtab"] - 1;
            
            var $activeElementTab = $(".main .tabs-nav li").eq(urlParams["startingtab"]);

            // Set active class
            $activeElementTab.addClass("active").siblings().removeClass("active");
            // Update the content section - set active content to display
            //$activeElementTab.siblings().find("div.content").hide();
            $activeElementTab.parent().siblings().children("li:eq(" + urlParams["startingtab"] + ")").addClass("active").siblings().removeClass("active");

            // Scroll to the active element (offset by 50 because behind omni-nav)
            setTimeout(function(){
                $('html, body').stop().animate({
                    scrollTop:$activeElementTab.offset().top -50
                },1000) ;
            },250);
        }
        /* end open tab */
    }

});
$(function () {


  if ($(".rotatorContainer").parent(".homepage").length > 0) {
    $('.flexslider').flexslider({
      animation: "slide",
      touchSwipe: true,
      controlNav: false,
      pauseOnHover: true,
      pauseOnAction: true,
      pausePlay: true,
      randomize: false,
      slideshowSpeed: 10000,
      slideToStart: startingPane,
      slideshow: autoplay,
      start: function (slider) {
        g_mySlider = slider;
        var currentSlide = slider.slides[slider.currentSlide];
        if ($('html').hasClass("opacity")) {
          $('.slide').not(currentSlide).fadeTo(0, 0.1,
            function () { }
          );
        } else {
          if ($(".ie7").length) {
            $('.rotatorContainer').css('overflow', 'hidden');
            $('.slide').not(currentSlide).css('margin-top', '-9999999px');
          } else {
            $('.slide').not(currentSlide).css('visibility', 'hidden');
          }
        }
      },
      before: function (slider) {
        var nextSlide = slider.slides[slider.animatingTo],
          $nextSlide = $(nextSlide),
          difference = (parseInt(slider.currentSlide) - parseInt(slider.animatingTo)),
          offset = '100px',
          currentSlide = slider.slides[slider.currentSlide],
          $currentSlide = $(currentSlide);
        if (difference === 1 || difference === -2) {
          offset = '-100px';
        }
        $nextSlide.children(".bg1, .bg2, .bg3").stop().animate({
          marginLeft: offset
        }, 300, function () {
          $nextSlide.children(".bg3").animate({
            marginLeft: '0'
          }, 500, function () { });
          $nextSlide.children(".bg2").animate({
            marginLeft: '0'
          }, 900, function () { });
          $nextSlide.children(".bg1").animate({
            marginLeft: '0'
          }, 700, function () { });
        });
        if ($('html').hasClass("opacity")) {
          $('.slide').not(nextSlide).stop().fadeTo(500, .1, function () { });
          $nextSlide.stop().fadeTo(500, 1, function () { });
        }
      },
      after: function (slider) {
        var currentSlide = slider.slides[slider.currentSlide],
          $currentSlide = $(currentSlide);
        $currentSlide.css({
          'opacity': 1
        })
        if (!$('html').hasClass("opacity")) {
          if ($('.ie7').length) {
            $('.slide').not(currentSlide).css('margin-top', '-99999999px');
            $currentSlide.css('margin-top', '0px');
          } else {
            $('.slide').not(currentSlide).css('visibility', 'hidden');
            $currentSlide.css('visibility', 'visible');
          }
        }
      }
    });
  }
  // Remove :focus outline from rotator nav arrows
  $(".flex-direction-nav li a").each(function () {
    $(this).attr("hideFocus", "true").css("outline", "none");
  });
  // Pause the slider once the user interacts with the slider
  $(".flex-direction-nav li a").on("click", function (event) {
    g_mySlider.pause();
    g_mySlider.resume = function () { };
  });
  // Flex navigation hover 
  $('.flex-direction-nav li a').hover(
    function () {
      $(this).animate({
        opacity: 1
      }, 200);
    },
    function () {
      $(this).animate({
        opacity: .3
      }, 100);
    }
  );
});
$(function () {
  if ($(".miniRotatorNav").length > 0) {
    // Trigger next on enter key
    $('a.next').keydown(function (event) {
      var keyCode = (event.keyCode ? event.keyCode : event.which);
      if (keyCode == 13) {
        $('a.next').trigger('click');
      }
    });
    // Trigger previous on enter key
    $('a.prev').keydown(function (event) {
      var keyCode = (event.keyCode ? event.keyCode : event.which);
      if (keyCode == 13) {
        $('a.prev').trigger('click');
        pauseAutoScroll();
      }
    });

    function pauseAutoScroll() {
      $('.miniRotatorContainer').jcarousel({
        auto: 0,
      })
      //console.log('pausing autoscroll')
    }

    function resumeAutoScroll() {
      //console.log('resuming auto scroll')
      // resetSlideOrder();
      $('.miniRotatorContainer').jcarousel({
        scroll: 1,
      })
      carousel.startAuto();
      // $('a.next').trigger('click');
    }
    // remove margin on shift-tab
    var boxItemWidth = '-' + $('.jcarousel-list').outerWidth()
    $(".miniRotator li").on('keydown', function (e) {
      // Shift tab
      if (e.shiftKey && e.keyCode === 9) {
        //console.log('shift tab')
        return true;
      }
      // Tab
      else if (e.keyCode === 9) {
        //console.log('tab')
        pauseAutoScroll();
        // return true;
      }
    });

    function defaultSettings() {
      //console.log('resetting')
      $('.miniRotatorContainer').jcarousel({
        // visible: 4,
        wrap: "circular",
        auto: 1000,
        hoverPause: true,
      });
    }
    $("a.next").focusin(function () {
      pauseAutoScroll();
    });
    $("a.next").focusout(function () {
      resumeAutoScroll();
      var carousel = $('.miniRotatorContainer').jcarousel
      carousel.startAuto();
    });
    $("a.prev").focusin(function () {
      // resetSlideOrder();
    });
  }
});
$(function () {
  if ($('#uninav').length > 0) {
    var uninavHeight = $('#uninav').outerHeight();
  }

  if ($(".miniRotatorNav, .slider.version-201611").length > 0) {
    // Pause carousel via button
    $('div.pause').click(function () {
      pauseAutoScroll();
    })
    $('div.pause').keydown(function (event) {
      var keyCode = (event.keyCode ? event.keyCode : event.which);
      if (keyCode == 13) {
        $('div.pause').trigger('click');
      }
    });
  }
});
$(function () {

	/* Search
    ------------------------------------------------------------------------------------------------*/

    $(".searchButton").click(function () {
        var searchTerm = $(this).siblings(".searchBox").val();
        search(searchTerm);
    });

    $(".searchBox").keypress(function (e) {
        if ((e.which && e.which == 13) || (e.keyCode && e.keyCode == 13)) {
            var searchTerm = $(this).val();
            search(searchTerm);
        }
    });

    function search(searchTerm) {
        window.location = "/search_results.asp?cx=003348829706320756496%3Adbv13petw_8&cof=FORID%3A9&ie=UTF-8&q=" + searchTerm + "&sa=Search&siteurl=chapman.edu%252F";
    }

    /***************************************************
	* This code watches what the user types into our search field
	* and displays a helpful tooltip if they are looking for Blackboard
	* or Webadvisor
	***************************************************/

	// Run when the page is ready
	$(document).ready(function () {
		cu_search_helper.initialize();

		cu_search_autofocus.initialize();
	});

	var
	keyCodes = {
		'search': 191
	},
	focusableElements = /a|button|input|option|select|textarea/i,
	$elements = {
		btnSearch: $('a.resources-nav-btn-search'),
		navSearch: $('div.resources-subNav-search'),
		inpSearch: $('#smallSearchBox')
	},
	cu_search_autofocus = {
		initialize: function () {
			$(window).on('keydown', function (event) {
				if (!cu_search_autofocus.elementSupportsFocus(document.activeElement) && event.keyCode === keyCodes.search) {
					event.preventDefault();

					cu_search_autofocus.openSearch();
					cu_search_autofocus.focusSearch();
				}
			});

			$elements.btnSearch.on('click', cu_search_autofocus.focusSearch);
		},
		focusSearch: function () {
			$elements.inpSearch.focus();
		},
		openSearch: function () {
			$elements.btnSearch.addClass('is-active');
			$elements.navSearch.addClass('is-visible');
		},
		elementSupportsFocus: function (element) {
			return element.nodeName.match(focusableElements) || element.hasAttribute('tabindex');
		}
	},
	cu_search_helper = {
		tooltip_visible: false,

		initialize: function () {

			// Do not run this object on small viewports
			if ($(window).width() < 780) return false;

			// Run this each time they type a letter
			$('#smallSearchBox').on('keyup', function() {

				var query_substring = $(this).val().substring(0,3).toLowerCase();

				if (query_substring === 'bla') {
					cu_search_helper.showHelpfulTip('Blackboard');
				} else if (query_substring === 'web') {
					cu_search_helper.showHelpfulTip('WebAdvisor');
				} else {
					cu_search_helper.hideHelpfulTip();
				}

			});
		},

		// Show the tooltip
		showHelpfulTip : function(serviceName) {
			if (this.tooltip_visible) return false;

			this.tooltip_visible = true;
			// Add overlay
			$('<div id="cuNavBarMasks"><div class="mask_1"></div><div class="mask_2"></div></div>').prependTo($('.resources-subNav-search')).hide().fadeIn(600);

			// Add a tooltip
			$('<div id="cuSearchHelper"><span class="title">Looking for <b>'+serviceName+'</b>?</span><br /><span class="label">We added a faster way to find our web services. </span></div>').prependTo($('.resources-subNav-search')).hide().slideDown(300);

			$('.resources-subNav-search').addClass('show-helper');

			// Hide Google autocomplete
			$('.gssb_c').hide();
			setTimeout(function() {
				$('.gssb_c').hide();
			}, 300);

		},

		// Hide the tooltip
		hideHelpfulTip : function() {
			if (!this.tooltip_visible) return false;

			this.tooltip_visible = false;

			// Remove the tooltip
			$('.resources-subNav-search').removeClass('show-helper');

			$('#cuSearchHelper').slideUp(300,function() { 
				$('#cuSearchHelper').remove(); 
			});

			// Remove the overlay
			$('#cuNavBarMasks').fadeOut(300,function() { 
				$('#cuNavBarMasks').remove(); 
			});

		}
	};

	var $formClone = $('#cse-search-form form').clone(),
        $searchButtonClone = $('#cse-search-form form input.gsc-search-button').clone(true),
        $formCloneSmall = $('#cse-search-form-small form').clone(),
        $searchButtonCloneSmall = $('#cse-search-form-small form input.gsc-search-button').clone(true);

    $('#cse-search-form form').remove();
    $formClone.appendTo('#cse-search-form');  
    $('#cse-search-form form input.gsc-search-button').replaceWith($searchButtonClone);

    $('#cse-search-form-small form').remove();
    $formCloneSmall.appendTo('#cse-search-form-small');  
    $('#cse-search-form-small form input.gsc-search-button').replaceWith($searchButtonCloneSmall);

    $('#cse-search-form form input, #cse-search-form-small form input').removeAttr('disabled');

    $('#cse-search-form form input, #cse-search-form-small form input').on('keydown', function(e){
     
        if ((e.which && e.which == 13) || (e.keyCode && e.keyCode == 13)) {
            e.preventDefault();
        }
        $(this).css({background:'none'});

    }); 

    $('#cse-search-form-small form input').on('focus', function(){
        $('.rotatorContainer').css("visibility", "hidden");
    });

    $('#cse-search-form-small form input').on('blur', function(){
        $('.rotatorContainer').css("visibility", "visible");
    });

    $('#cse-search-form form input, #cse-search-form-small form input').on('keydown', function(e){
        
        if ((e.which && e.which == 13) || (e.keyCode && e.keyCode == 13)) {
            BREI.Personalization.pushToRecentSearches($(this).val());
            googleSearch($(this).val());
        }

    });

    $('#cse-search-form form input.gsc-search-button').click(function(){
        googleSearch($('#cse-search-form form input').val());
    });

    $('#cse-search-form-small form input.gsc-search-button').click(function(){
        googleSearch($('#cse-search-form-small form input').val());
    });

    function googleSearch(value){
        window.location = "/search-results/index.aspx?q=" + value;
    }
            
});
$(function () {

	/* Video overlay
    ------------------------------------------------------------------------------------------------*/

    $(".videoLink").on("click", function (event) {
        event.preventDefault();
        var src = $(this).attr("data-video");
        $("#videoContainer .video").attr('src', src);


        $(".overlay").show(0).animate({ top: 0 }, 1e3, function () { g_mySlider.manualPause = true; g_mySlider.pause(); });
    });

    $(".closeButton").on("click", function () {
        $(".overlay").animate({ top: "700px" }, 1e3, function () { }).hide(0);
        var videoClone = $('#videoContainer').html();
        $('#videoContainer div').remove();
        $("#videoContainer").html(videoClone);
        g_mySlider.resume();
    });

});
$(function () {
  /* Populate weather from json feed; default on page is 65 until modified by this routine
  ------------------------------------------------------------------------------------------------*/
  //sample data: {"weather":{"icon_path":"\/images\/icons\/weather\/2cloud_norain.png","temp_f":"66","temp_c":"19"}}
  $.getJSON("https://forecast.chapman.edu/chapman/banner-json.php?callback=orange", function (data) {
    var iconPath = data.weather.icon_path,
      tempF = data.weather.temp_f,
      tempC = data.weather.temp_c,
      url = "//www.chapman.edu",
      $weather = $(".weather");
    //find weather class in html and substitute placeholders with current temp
    $weather.find("img").attr("src", url + iconPath);
    $weather.find(".temp #tempF").html(tempF);
    $weather.find(".temp #tempC").html(tempC);
  });
});
/*!
 * AmplifyJS 1.1.0 - Core, Store, Request
 * 
 * Copyright 2011 appendTo LLC. (http://appendto.com/team)
 * Dual licensed under the MIT or GPL licenses.
 * http://appendto.com/open-source-licenses
 * 
 * http://amplifyjs.com
 */

(function(a,b){var c=[].slice,d={},e=a.amplify={publish:function(a){var b=c.call(arguments,1),e,f,g,h=0,i;if(!d[a])return!0;e=d[a].slice();for(g=e.length;h<g;h++){f=e[h],i=f.callback.apply(f.context,b);if(i===!1)break}return i!==!1},subscribe:function(a,b,c,e){arguments.length===3&&typeof c=="number"&&(e=c,c=b,b=null),arguments.length===2&&(c=b,b=null),e=e||10;var f=0,g=a.split(/\s/),h=g.length,i;for(;f<h;f++){a=g[f],i=!1,d[a]||(d[a]=[]);var j=d[a].length-1,k={callback:c,context:b,priority:e};for(;j>=0;j--)if(d[a][j].priority<=e){d[a].splice(j+1,0,k),i=!0;break}i||d[a].unshift(k)}return c},unsubscribe:function(a,b){if(!!d[a]){var c=d[a].length,e=0;for(;e<c;e++)if(d[a][e].callback===b){d[a].splice(e,1);break}}}}})(this),function(a,b){function e(a,e){c.addType(a,function(f,g,h){var i,j,k,l,m=g,n=(new Date).getTime();if(!f){m={},l=[],k=0;try{f=e.length;while(f=e.key(k++))d.test(f)&&(j=JSON.parse(e.getItem(f)),j.expires&&j.expires<=n?l.push(f):m[f.replace(d,"")]=j.data);while(f=l.pop())e.removeItem(f)}catch(o){}return m}f="__amplify__"+f;if(g===b){i=e.getItem(f),j=i?JSON.parse(i):{expires:-1};if(j.expires&&j.expires<=n)e.removeItem(f);else return j.data}else if(g===null)e.removeItem(f);else{j=JSON.stringify({data:g,expires:h.expires?n+h.expires:null});try{e.setItem(f,j)}catch(o){c[a]();try{e.setItem(f,j)}catch(o){throw c.error()}}}return m})}var c=a.store=function(a,b,d,e){var e=c.type;d&&d.type&&d.type in c.types&&(e=d.type);return c.types[e](a,b,d||{})};c.types={},c.type=null,c.addType=function(a,b){c.type||(c.type=a),c.types[a]=b,c[a]=function(b,d,e){e=e||{},e.type=a;return c(b,d,e)}},c.error=function(){return"amplify.store quota exceeded"};var d=/^__amplify__/;for(var f in{localStorage:1,sessionStorage:1})try{window[f].getItem&&e(f,window[f])}catch(g){}if(window.globalStorage)try{e("globalStorage",window.globalStorage[window.location.hostname]),c.type==="sessionStorage"&&(c.type="globalStorage")}catch(g){}(function(){if(!c.types.localStorage){var a=document.createElement("div"),d="amplify";a.style.display="none",document.getElementsByTagName("head")[0].appendChild(a);try{a.addBehavior("#default#userdata"),a.load(d)}catch(e){a.parentNode.removeChild(a);return}c.addType("userData",function(e,f,g){a.load(d);var h,i,j,k,l,m=f,n=(new Date).getTime();if(!e){m={},l=[],k=0;while(h=a.XMLDocument.documentElement.attributes[k++])i=JSON.parse(h.value),i.expires&&i.expires<=n?l.push(h.name):m[h.name]=i.data;while(e=l.pop())a.removeAttribute(e);a.save(d);return m}e=e.replace(/[^-._0-9A-Za-z\xb7\xc0-\xd6\xd8-\xf6\xf8-\u037d\u37f-\u1fff\u200c-\u200d\u203f\u2040\u2070-\u218f]/g,"-");if(f===b){h=a.getAttribute(e),i=h?JSON.parse(h):{expires:-1};if(i.expires&&i.expires<=n)a.removeAttribute(e);else return i.data}else f===null?a.removeAttribute(e):(j=a.getAttribute(e),i=JSON.stringify({data:f,expires:g.expires?n+g.expires:null}),a.setAttribute(e,i));try{a.save(d)}catch(o){j===null?a.removeAttribute(e):a.setAttribute(e,j),c.userData();try{a.setAttribute(e,i),a.save(d)}catch(o){j===null?a.removeAttribute(e):a.setAttribute(e,j);throw c.error()}}return m})}})(),function(){function e(a){return a===b?b:JSON.parse(JSON.stringify(a))}var a={},d={};c.addType("memory",function(c,f,g){if(!c)return e(a);if(f===b)return e(a[c]);d[c]&&(clearTimeout(d[c]),delete d[c]);if(f===null){delete a[c];return null}a[c]=f,g.expires&&(d[c]=setTimeout(function(){delete a[c],delete d[c]},g.expires));return f})}()}(this.amplify=this.amplify||{}),function(a,b){function e(a){var b=!1;setTimeout(function(){b=!0},1);return function(){var c=this,d=arguments;b?a.apply(c,d):setTimeout(function(){a.apply(c,d)},1)}}function d(a){return{}.toString.call(a)==="[object Function]"}function c(){}a.request=function(b,f,g){var h=b||{};typeof h=="string"&&(d(f)&&(g=f,f={}),h={resourceId:b,data:f||{},success:g});var i={abort:c},j=a.request.resources[h.resourceId],k=h.success||c,l=h.error||c;h.success=e(function(b,c){c=c||"success",a.publish("request.success",h,b,c),a.publish("request.complete",h,b,c),k(b,c)}),h.error=e(function(b,c){c=c||"error",a.publish("request.error",h,b,c),a.publish("request.complete",h,b,c),l(b,c)});if(!j){if(!h.resourceId)throw"amplify.request: no resourceId provided";throw"amplify.request: unknown resourceId: "+h.resourceId}if(!a.publish("request.before",h))h.error(null,"abort");else{a.request.resources[h.resourceId](h,i);return i}},a.request.types={},a.request.resources={},a.request.define=function(b,c,d){if(typeof c=="string"){if(!(c in a.request.types))throw"amplify.request.define: unknown type: "+c;d.resourceId=b,a.request.resources[b]=a.request.types[c](d)}else a.request.resources[b]=c}}(amplify),function(a,b,c){var d=["status","statusText","responseText","responseXML","readyState"],e=/\{([^\}]+)\}/g;a.request.types.ajax=function(e){e=b.extend({type:"GET"},e);return function(f,g){function n(a,e){b.each(d,function(a,b){try{m[b]=h[b]}catch(c){}}),/OK$/.test(m.statusText)&&(m.statusText="success"),a===c&&(a=null),l&&(e="abort"),/timeout|error|abort/.test(e)?m.error(a,e):m.success(a,e),n=b.noop}var h,i=e.url,j=g.abort,k=b.extend(!0,{},e,{data:f.data}),l=!1,m={readyState:0,setRequestHeader:function(a,b){return h.setRequestHeader(a,b)},getAllResponseHeaders:function(){return h.getAllResponseHeaders()},getResponseHeader:function(a){return h.getResponseHeader(a)},overrideMimeType:function(a){return h.overrideMideType(a)},abort:function(){l=!0;try{h.abort()}catch(a){}n(null,"abort")},success:function(a,b){f.success(a,b)},error:function(a,b){f.error(a,b)}};a.publish("request.ajax.preprocess",e,f,k,m),b.extend(k,{success:function(a,b){n(a,b)},error:function(a,b){n(null,b)},beforeSend:function(b,c){h=b,k=c;var d=e.beforeSend?e.beforeSend.call(this,m,k):!0;return d&&a.publish("request.before.ajax",e,f,k,m)}}),b.ajax(k),g.abort=function(){m.abort(),j.call(this)}}},a.subscribe("request.ajax.preprocess",function(a,c,d){var f=[],g=d.data;typeof g!="string"&&(g=b.extend(!0,{},a.data,g),d.url=d.url.replace(e,function(a,b){if(b in g){f.push(b);return g[b]}}),b.each(f,function(a,b){delete g[b]}),d.data=g)}),a.subscribe("request.ajax.preprocess",function(a,c,d){var e=d.data,f=a.dataMap;!!f&&typeof e!="string"&&(b.isFunction(f)?d.data=f(e):(b.each(a.dataMap,function(a,b){a in e&&(e[b]=e[a],delete e[a])}),d.data=e))});var f=a.request.cache={_key:function(a,b,c){function g(){return c.charCodeAt(e++)<<24|c.charCodeAt(e++)<<16|c.charCodeAt(e++)<<8|c.charCodeAt(e++)<<0}c=b+c;var d=c.length,e=0,f=g();while(e<d)f^=g();return"request-"+a+"-"+f},_default:function(){var a={};return function(b,c,d,e){var g=f._key(c.resourceId,d.url,d.data),h=b.cache;if(g in a){e.success(a[g]);return!1}var i=e.success;e.success=function(b){a[g]=b,typeof h=="number"&&setTimeout(function(){delete a[g]},h),i.apply(this,arguments)}}}()};a.store&&(b.each(a.store.types,function(b){f[b]=function(c,d,e,g){var h=f._key(d.resourceId,e.url,e.data),i=a.store[b](h);if(i){e.success(i);return!1}var j=g.success;g.success=function(d){a.store[b](h,d,{expires:c.cache.expires}),j.apply(this,arguments)}}}),f.persist=f[a.store.type]),a.subscribe("request.before.ajax",function(a){var b=a.cache;if(b){b=b.type||b;return f[b in f?b:"_default"].apply(this,arguments)}}),a.request.decoders={jsend:function(a,b,c,d,e){a.status==="success"?d(a.data):a.status==="fail"?e(a.data,"fail"):a.status==="error"&&(delete a.status,e(a,"error"))}},a.subscribe("request.before.ajax",function(c,d,e,f){function k(a,b){h(a,b)}function j(a,b){g(a,b)}var g=f.success,h=f.error,i=b.isFunction(c.decoder)?c.decoder:c.decoder in a.request.decoders?a.request.decoders[c.decoder]:a.request.decoders._default;!i||(f.success=function(a,b){i(a,b,f,j,k)},f.error=function(a,b){i(a,b,f,j,k)})})}(amplify,jQuery);
!function (e, t) { "object" == typeof exports && "undefined" != typeof module ? module.exports = t() : "function" == typeof define && define.amd ? define(t) : e.AOS = t() }(this, function () { "use strict"; var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}, t = "Expected a function", n = NaN, o = "[object Symbol]", i = /^\s+|\s+$/g, a = /^[-+]0x[0-9a-f]+$/i, r = /^0b[01]+$/i, c = /^0o[0-7]+$/i, s = parseInt, u = "object" == typeof e && e && e.Object === Object && e, d = "object" == typeof self && self && self.Object === Object && self, l = u || d || Function("return this")(), f = Object.prototype.toString, m = Math.max, p = Math.min, b = function () { return l.Date.now() }; function v(e, n, o) { var i, a, r, c, s, u, d = 0, l = !1, f = !1, v = !0; if ("function" != typeof e) throw new TypeError(t); function y(t) { var n = i, o = a; return i = a = void 0, d = t, c = e.apply(o, n) } function h(e) { var t = e - u; return void 0 === u || t >= n || t < 0 || f && e - d >= r } function k() { var e = b(); if (h(e)) return x(e); s = setTimeout(k, function (e) { var t = n - (e - u); return f ? p(t, r - (e - d)) : t }(e)) } function x(e) { return s = void 0, v && i ? y(e) : (i = a = void 0, c) } function O() { var e = b(), t = h(e); if (i = arguments, a = this, u = e, t) { if (void 0 === s) return function (e) { return d = e, s = setTimeout(k, n), l ? y(e) : c }(u); if (f) return s = setTimeout(k, n), y(u) } return void 0 === s && (s = setTimeout(k, n)), c } return n = w(n) || 0, g(o) && (l = !!o.leading, r = (f = "maxWait" in o) ? m(w(o.maxWait) || 0, n) : r, v = "trailing" in o ? !!o.trailing : v), O.cancel = function () { void 0 !== s && clearTimeout(s), d = 0, i = u = a = s = void 0 }, O.flush = function () { return void 0 === s ? c : x(b()) }, O } function g(e) { var t = typeof e; return !!e && ("object" == t || "function" == t) } function w(e) { if ("number" == typeof e) return e; if (function (e) { return "symbol" == typeof e || function (e) { return !!e && "object" == typeof e }(e) && f.call(e) == o }(e)) return n; if (g(e)) { var t = "function" == typeof e.valueOf ? e.valueOf() : e; e = g(t) ? t + "" : t } if ("string" != typeof e) return 0 === e ? e : +e; e = e.replace(i, ""); var u = r.test(e); return u || c.test(e) ? s(e.slice(2), u ? 2 : 8) : a.test(e) ? n : +e } var y = function (e, n, o) { var i = !0, a = !0; if ("function" != typeof e) throw new TypeError(t); return g(o) && (i = "leading" in o ? !!o.leading : i, a = "trailing" in o ? !!o.trailing : a), v(e, n, { leading: i, maxWait: n, trailing: a }) }, h = "Expected a function", k = NaN, x = "[object Symbol]", O = /^\s+|\s+$/g, j = /^[-+]0x[0-9a-f]+$/i, E = /^0b[01]+$/i, N = /^0o[0-7]+$/i, z = parseInt, C = "object" == typeof e && e && e.Object === Object && e, A = "object" == typeof self && self && self.Object === Object && self, q = C || A || Function("return this")(), L = Object.prototype.toString, T = Math.max, M = Math.min, S = function () { return q.Date.now() }; function D(e) { var t = typeof e; return !!e && ("object" == t || "function" == t) } function H(e) { if ("number" == typeof e) return e; if (function (e) { return "symbol" == typeof e || function (e) { return !!e && "object" == typeof e }(e) && L.call(e) == x }(e)) return k; if (D(e)) { var t = "function" == typeof e.valueOf ? e.valueOf() : e; e = D(t) ? t + "" : t } if ("string" != typeof e) return 0 === e ? e : +e; e = e.replace(O, ""); var n = E.test(e); return n || N.test(e) ? z(e.slice(2), n ? 2 : 8) : j.test(e) ? k : +e } var $ = function (e, t, n) { var o, i, a, r, c, s, u = 0, d = !1, l = !1, f = !0; if ("function" != typeof e) throw new TypeError(h); function m(t) { var n = o, a = i; return o = i = void 0, u = t, r = e.apply(a, n) } function p(e) { var n = e - s; return void 0 === s || n >= t || n < 0 || l && e - u >= a } function b() { var e = S(); if (p(e)) return v(e); c = setTimeout(b, function (e) { var n = t - (e - s); return l ? M(n, a - (e - u)) : n }(e)) } function v(e) { return c = void 0, f && o ? m(e) : (o = i = void 0, r) } function g() { var e = S(), n = p(e); if (o = arguments, i = this, s = e, n) { if (void 0 === c) return function (e) { return u = e, c = setTimeout(b, t), d ? m(e) : r }(s); if (l) return c = setTimeout(b, t), m(s) } return void 0 === c && (c = setTimeout(b, t)), r } return t = H(t) || 0, D(n) && (d = !!n.leading, a = (l = "maxWait" in n) ? T(H(n.maxWait) || 0, t) : a, f = "trailing" in n ? !!n.trailing : f), g.cancel = function () { void 0 !== c && clearTimeout(c), u = 0, o = s = i = c = void 0 }, g.flush = function () { return void 0 === c ? r : v(S()) }, g }, W = function () { }; function P(e) { e && e.forEach(function (e) { var t = Array.prototype.slice.call(e.addedNodes), n = Array.prototype.slice.call(e.removedNodes); if (function e(t) { var n = void 0, o = void 0; for (n = 0; n < t.length; n += 1) { if ((o = t[n]).dataset && o.dataset.aos) return !0; if (o.children && e(o.children)) return !0 } return !1 }(t.concat(n))) return W() }) } function Y() { return window.MutationObserver || window.WebKitMutationObserver || window.MozMutationObserver } var _ = { isSupported: function () { return !!Y() }, ready: function (e, t) { var n = window.document, o = new (Y())(P); W = t, o.observe(n.documentElement, { childList: !0, subtree: !0, removedNodes: !0 }) } }, B = function (e, t) { if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function") }, F = function () { function e(e, t) { for (var n = 0; n < t.length; n++) { var o = t[n]; o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, o.key, o) } } return function (t, n, o) { return n && e(t.prototype, n), o && e(t, o), t } }(), I = Object.assign || function (e) { for (var t = 1; t < arguments.length; t++) { var n = arguments[t]; for (var o in n) Object.prototype.hasOwnProperty.call(n, o) && (e[o] = n[o]) } return e }, K = /(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i, G = /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i, J = /(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino|android|ipad|playbook|silk/i, Q = /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i; function R() { return navigator.userAgent || navigator.vendor || window.opera || "" } var U = new (function () { function e() { B(this, e) } return F(e, [{ key: "phone", value: function () { var e = R(); return !(!K.test(e) && !G.test(e.substr(0, 4))) } }, { key: "mobile", value: function () { var e = R(); return !(!J.test(e) && !Q.test(e.substr(0, 4))) } }, { key: "tablet", value: function () { return this.mobile() && !this.phone() } }, { key: "ie11", value: function () { return "-ms-scroll-limit" in document.documentElement.style && "-ms-ime-align" in document.documentElement.style } }]), e }()), V = function (e, t) { var n = void 0; return U.ie11() ? (n = document.createEvent("CustomEvent")).initCustomEvent(e, !0, !0, { detail: t }) : n = new CustomEvent(e, { detail: t }), document.dispatchEvent(n) }, X = function (e) { return e.forEach(function (e, t) { return function (e, t) { var n = e.options, o = e.position, i = e.node, a = (e.data, function () { e.animated && (function (e, t) { t && t.forEach(function (t) { return e.classList.remove(t) }) }(i, n.animatedClassNames), V("aos:out", i), e.options.id && V("aos:in:" + e.options.id, i), e.animated = !1) }); n.mirror && t >= o.out && !n.once ? a() : t >= o.in ? e.animated || (function (e, t) { t && t.forEach(function (t) { return e.classList.add(t) }) }(i, n.animatedClassNames), V("aos:in", i), e.options.id && V("aos:in:" + e.options.id, i), e.animated = !0) : e.animated && !n.once && a() }(e, window.pageYOffset) }) }, Z = function (e) { for (var t = 0, n = 0; e && !isNaN(e.offsetLeft) && !isNaN(e.offsetTop);)t += e.offsetLeft - ("BODY" != e.tagName ? e.scrollLeft : 0), n += e.offsetTop - ("BODY" != e.tagName ? e.scrollTop : 0), e = e.offsetParent; return { top: n, left: t } }, ee = function (e, t, n) { var o = e.getAttribute("data-aos-" + t); if (void 0 !== o) { if ("true" === o) return !0; if ("false" === o) return !1 } return o || n }, te = function (e, t) { return e.forEach(function (e, n) { var o = ee(e.node, "mirror", t.mirror), i = ee(e.node, "once", t.once), a = ee(e.node, "id"), r = t.useClassNames && e.node.getAttribute("data-aos"), c = [t.animatedClassName].concat(r ? r.split(" ") : []).filter(function (e) { return "string" == typeof e }); t.initClassName && e.node.classList.add(t.initClassName), e.position = { in: function (e, t, n) { var o = window.innerHeight, i = ee(e, "anchor"), a = ee(e, "anchor-placement"), r = Number(ee(e, "offset", a ? 0 : t)), c = a || n, s = e; i && document.querySelectorAll(i) && (s = document.querySelectorAll(i)[0]); var u = Z(s).top - o; switch (c) { case "top-bottom": break; case "center-bottom": u += s.offsetHeight / 2; break; case "bottom-bottom": u += s.offsetHeight; break; case "top-center": u += o / 2; break; case "center-center": u += o / 2 + s.offsetHeight / 2; break; case "bottom-center": u += o / 2 + s.offsetHeight; break; case "top-top": u += o; break; case "bottom-top": u += o + s.offsetHeight; break; case "center-top": u += o + s.offsetHeight / 2 }return u + r }(e.node, t.offset, t.anchorPlacement), out: o && function (e, t) { window.innerHeight; var n = ee(e, "anchor"), o = ee(e, "offset", t), i = e; return n && document.querySelectorAll(n) && (i = document.querySelectorAll(n)[0]), Z(i).top + i.offsetHeight - o }(e.node, t.offset) }, e.options = { once: i, mirror: o, animatedClassNames: c, id: a } }), e }, ne = function () { var e = document.querySelectorAll("[data-aos]"); return Array.prototype.map.call(e, function (e) { return { node: e } }) }, oe = [], ie = !1, ae = { offset: 120, delay: 0, easing: "ease", duration: 400, disable: !1, once: !1, mirror: !1, anchorPlacement: "top-bottom", startEvent: "DOMContentLoaded", animatedClassName: "aos-animate", initClassName: "aos-init", useClassNames: !1, disableMutationObserver: !1, throttleDelay: 99, debounceDelay: 50 }, re = function () { return document.all && !window.atob }, ce = function () { arguments.length > 0 && void 0 !== arguments[0] && arguments[0] && (ie = !0), ie && (oe = te(oe, ae), X(oe), window.addEventListener("scroll", y(function () { X(oe, ae.once) }, ae.throttleDelay))) }, se = function () { if (oe = ne(), de(ae.disable) || re()) return ue(); ce() }, ue = function () { oe.forEach(function (e, t) { e.node.removeAttribute("data-aos"), e.node.removeAttribute("data-aos-easing"), e.node.removeAttribute("data-aos-duration"), e.node.removeAttribute("data-aos-delay"), ae.initClassName && e.node.classList.remove(ae.initClassName), ae.animatedClassName && e.node.classList.remove(ae.animatedClassName) }) }, de = function (e) { return !0 === e || "mobile" === e && U.mobile() || "phone" === e && U.phone() || "tablet" === e && U.tablet() || "function" == typeof e && !0 === e() }; return { init: function (e) { return ae = I(ae, e), oe = ne(), ae.disableMutationObserver || _.isSupported() || (console.info('\n      aos: MutationObserver is not supported on this browser,\n      code mutations observing has been disabled.\n      You may have to call "refreshHard()" by yourself.\n    '), ae.disableMutationObserver = !0), ae.disableMutationObserver || _.ready("[data-aos]", se), de(ae.disable) || re() ? ue() : (document.querySelector("body").setAttribute("data-aos-easing", ae.easing), document.querySelector("body").setAttribute("data-aos-duration", ae.duration), document.querySelector("body").setAttribute("data-aos-delay", ae.delay), -1 === ["DOMContentLoaded", "load"].indexOf(ae.startEvent) ? document.addEventListener(ae.startEvent, function () { ce(!0) }) : window.addEventListener("load", function () { ce(!0) }), "DOMContentLoaded" === ae.startEvent && ["complete", "interactive"].indexOf(document.readyState) > -1 && ce(!0), window.addEventListener("resize", $(ce, ae.debounceDelay, !0)), window.addEventListener("orientationchange", $(ce, ae.debounceDelay, !0)), oe) }, refresh: ce, refreshHard: se } });
// Cookie
(function(a){a.cookie=function(b,c,d){if(arguments.length>1&&(!/Object/.test(Object.prototype.toString.call(c))||c===null||c===undefined)){d=a.extend({},d);if(c===null||c===undefined){d.expires=-1}if(typeof d.expires==="number"){var e=d.expires,f=d.expires=new Date;f.setDate(f.getDate()+e)}c=String(c);return document.cookie=[encodeURIComponent(b),"=",d.raw?c:encodeURIComponent(c),d.expires?"; expires="+d.expires.toUTCString():"",d.path?"; path="+d.path:"",d.domain?"; domain="+d.domain:"",d.secure?"; secure":""].join("")}d=c||{};var g=d.raw?function(a){return a}:decodeURIComponent;var h=document.cookie.split("; ");for(var i=0,j;j=h[i]&&h[i].split("=");i++){if(g(j[0])===b)return g(j[1]||"")}return null}})(jQuery)
;
/**
 * Cross browser Ellipsis
 */

(function(e){e.fn.ellipsis=function(){return this.each(function(){var t=e(this);if(t.css("overflow")=="hidden"){var n=t.html();var r=t.hasClass("multiline");var i=e(this.cloneNode(true)).hide().css("position","absolute").css("overflow","visible").width(r?t.width():"auto").height(r?"auto":t.height());t.after(i);function s(){return i.height()>t.height()}function o(){return i.width()>t.width()}var u=r?s:o;while(n.length>0&&u()){n=n.substr(0,n.length-1);i.html(n+"...")}t.html(i.html());i.remove()}})}})(jQuery);
/*
 * jQuery FlexSlider v2.6.3
 * Copyright 2012 WooThemes
 * Contributing Author: Tyler Smith
 */

/* CHANGES:
* Added descriptive title attributes to paging navigation - Mirabel
*/

  
;
(function ($) {

  var focused = true;

  //FlexSlider: Object Instance
  $.flexslider = function(el, options) {
    var slider = $(el);

    // making variables public
    slider.vars = $.extend({}, $.flexslider.defaults, options);

    var namespace = slider.vars.namespace,
        msGesture = window.navigator && window.navigator.msPointerEnabled && window.MSGesture,
        touch = (( "ontouchstart" in window ) || msGesture || window.DocumentTouch && document instanceof DocumentTouch) && slider.vars.touch,
        // depricating this idea, as devices are being released with both of these events
        eventType = "click touchend MSPointerUp keyup",
        watchedEvent = "",
        watchedEventClearTimer,
        vertical = slider.vars.direction === "vertical",
        reverse = slider.vars.reverse,
        carousel = (slider.vars.itemWidth > 0),
        fade = slider.vars.animation === "fade",
        asNav = slider.vars.asNavFor !== "",
        methods = {};

    // Store a reference to the slider object
    $.data(el, "flexslider", slider);

    // Private slider methods
    methods = {
      init: function() {
        slider.animating = false;
        // Get current slide and make sure it is a number
        slider.currentSlide = parseInt( ( slider.vars.startAt ? slider.vars.startAt : 0), 10 );
        if ( isNaN( slider.currentSlide ) ) { slider.currentSlide = 0; }
        slider.animatingTo = slider.currentSlide;
        slider.atEnd = (slider.currentSlide === 0 || slider.currentSlide === slider.last);
        slider.containerSelector = slider.vars.selector.substr(0,slider.vars.selector.search(' '));
        slider.slides = $(slider.vars.selector, slider);
        slider.container = $(slider.containerSelector, slider);
        slider.count = slider.slides.length;
        // SYNC:
        slider.syncExists = $(slider.vars.sync).length > 0;
        // SLIDE:
        if (slider.vars.animation === "slide") { slider.vars.animation = "swing"; }
        slider.prop = (vertical) ? "top" : "marginLeft";
        slider.args = {};
        // SLIDESHOW:
        slider.manualPause = false;
        slider.stopped = false;
        //PAUSE WHEN INVISIBLE
        slider.started = false;
        slider.startTimeout = null;
        // TOUCH/USECSS:
        slider.transitions = !slider.vars.video && !fade && slider.vars.useCSS && (function() {
          var obj = document.createElement('div'),
              props = ['perspectiveProperty', 'WebkitPerspective', 'MozPerspective', 'OPerspective', 'msPerspective'];
          for (var i in props) {
            if ( obj.style[ props[i] ] !== undefined ) {
              slider.pfx = props[i].replace('Perspective','').toLowerCase();
              slider.prop = "-" + slider.pfx + "-transform";
              return true;
            }
          }
          return false;
        }());
        slider.ensureAnimationEnd = '';
        // CONTROLSCONTAINER:
        if (slider.vars.controlsContainer !== "") slider.controlsContainer = $(slider.vars.controlsContainer).length > 0 && $(slider.vars.controlsContainer);
        // MANUAL:
        if (slider.vars.manualControls !== "") slider.manualControls = $(slider.vars.manualControls).length > 0 && $(slider.vars.manualControls);

        // CUSTOM DIRECTION NAV:
        if (slider.vars.customDirectionNav !== "") slider.customDirectionNav = $(slider.vars.customDirectionNav).length === 2 && $(slider.vars.customDirectionNav);

        // RANDOMIZE:
        if (slider.vars.randomize) {
          slider.slides.sort(function() { return (Math.round(Math.random())-0.5); });
          slider.container.empty().append(slider.slides);
        }

        slider.doMath();

        // INIT
        slider.setup("init");

        // CONTROLNAV:
        if (slider.vars.controlNav) { methods.controlNav.setup(); }

        // DIRECTIONNAV:
        if (slider.vars.directionNav) { methods.directionNav.setup(); }

        // KEYBOARD:
        if (slider.vars.keyboard && ($(slider.containerSelector).length === 1 || slider.vars.multipleKeyboard)) {
          $(document).bind('keyup', function(event) {
            var keycode = event.keyCode;
            if (!slider.animating && (keycode === 39 || keycode === 37)) {
              var target = (keycode === 39) ? slider.getTarget('next') :
                           (keycode === 37) ? slider.getTarget('prev') : false;
              slider.flexAnimate(target, slider.vars.pauseOnAction);
            }
          });
        }
        // MOUSEWHEEL:
        if (slider.vars.mousewheel) {
          slider.bind('mousewheel', function(event, delta, deltaX, deltaY) {
            event.preventDefault();
            var target = (delta < 0) ? slider.getTarget('next') : slider.getTarget('prev');
            slider.flexAnimate(target, slider.vars.pauseOnAction);
          });
        }

        // PAUSEPLAY
        if (slider.vars.pausePlay) { methods.pausePlay.setup(); }

        //PAUSE WHEN INVISIBLE
        if (slider.vars.slideshow && slider.vars.pauseInvisible) { methods.pauseInvisible.init(); }

        // SLIDSESHOW
        if (slider.vars.slideshow) {
          if (slider.vars.pauseOnHover) {
            slider.hover(function() {
              if (!slider.manualPlay && !slider.manualPause) { slider.pause(); }
            }, function() {
              if (!slider.manualPause && !slider.manualPlay && !slider.stopped) { slider.play(); }
            });
          }
          // initialize animation
          //If we're visible, or we don't use PageVisibility API
          if(!slider.vars.pauseInvisible || !methods.pauseInvisible.isHidden()) {
            (slider.vars.initDelay > 0) ? slider.startTimeout = setTimeout(slider.play, slider.vars.initDelay) : slider.play();
          }
        }

        // ASNAV:
        if (asNav) { methods.asNav.setup(); }

        // TOUCH
        if (touch && slider.vars.touch) { methods.touch(); }

        // FADE&&SMOOTHHEIGHT || SLIDE:
        if (!fade || (fade && slider.vars.smoothHeight)) { $(window).bind("resize orientationchange focus", methods.resize); }

        slider.find("img").attr("draggable", "false");

        // API: start() Callback
        setTimeout(function(){
          slider.vars.start(slider);
        }, 200);
      },
      asNav: {
        setup: function() {
          slider.asNav = true;
          slider.animatingTo = Math.floor(slider.currentSlide/slider.move);
          slider.currentItem = slider.currentSlide;
          slider.slides.removeClass(namespace + "active-slide").eq(slider.currentItem).addClass(namespace + "active-slide");
          if(!msGesture){
              slider.slides.on(eventType, function(e){
                e.preventDefault();
                var $slide = $(this),
                    target = $slide.index();
                var posFromLeft = $slide.offset().left - $(slider).scrollLeft(); // Find position of slide relative to left of slider container
                if( posFromLeft <= 0 && $slide.hasClass( namespace + 'active-slide' ) ) {
                  slider.flexAnimate(slider.getTarget("prev"), true);
                } else if (!$(slider.vars.asNavFor).data('flexslider').animating && !$slide.hasClass(namespace + "active-slide")) {
                  slider.direction = (slider.currentItem < target) ? "next" : "prev";
                  slider.flexAnimate(target, slider.vars.pauseOnAction, false, true, true);
                }
              });
          }else{
              el._slider = slider;
              slider.slides.each(function (){
                  var that = this;
                  that._gesture = new MSGesture();
                  that._gesture.target = that;
                  that.addEventListener("MSPointerDown", function (e){
                      e.preventDefault();
                      if(e.currentTarget._gesture) {
                        e.currentTarget._gesture.addPointer(e.pointerId);
                      }
                  }, false);
                  that.addEventListener("MSGestureTap", function (e){
                      e.preventDefault();
                      var $slide = $(this),
                          target = $slide.index();
                      if (!$(slider.vars.asNavFor).data('flexslider').animating && !$slide.hasClass('active')) {
                          slider.direction = (slider.currentItem < target) ? "next" : "prev";
                          slider.flexAnimate(target, slider.vars.pauseOnAction, false, true, true);
                      }
                  });
              });
          }
        }
      },
      controlNav: {
        setup: function() {
          if (!slider.manualControls) {
            methods.controlNav.setupPaging();
          } else { // MANUALCONTROLS:
            methods.controlNav.setupManual();
          }
        },
        setupPaging: function() {
          var type = (slider.vars.controlNav === "thumbnails") ? 'control-thumbs' : 'control-paging',
              j = 1,
              item,
              slide;

          slider.controlNavScaffold = $('<ol class="'+ namespace + 'control-nav ' + namespace + type + '"></ol>');

          if (slider.pagingCount > 1) {
            for (var i = 0; i < slider.pagingCount; i++) {
              slide = slider.slides.eq(i);
              if ( undefined === slide.attr( 'data-thumb-alt' ) ) { slide.attr( 'data-thumb-alt', '' ); }
              var altText = ( '' !== slide.attr( 'data-thumb-alt' ) ) ? altText = ' alt="' + slide.attr( 'data-thumb-alt' ) + '"' : '';
              title = ""
              item = (slider.vars.controlNav === "thumbnails") ? '<img src="' + slide.attr( 'data-thumb' ) + '"' + altText + '/>' : '<a href="#" title="Jump to slide '+ j +'">' + j + '</a>';
              if ( 'thumbnails' === slider.vars.controlNav && true === slider.vars.thumbCaptions ) {
                var captn = slide.attr( 'data-thumbcaption' );
                if ( '' !== captn && undefined !== captn ) { item += '<span class="' + namespace + 'caption">' + captn + '</span>'; }
              }
              slider.controlNavScaffold.append('<li>' + item + '</li>');
              j++;
            }
          }

          // CONTROLSCONTAINER:
          (slider.controlsContainer) ? $(slider.controlsContainer).append(slider.controlNavScaffold) : slider.append(slider.controlNavScaffold);
          methods.controlNav.set();

          methods.controlNav.active();

          slider.controlNavScaffold.delegate('a, img', eventType, function(event) {
            event.preventDefault();

            if (watchedEvent === "" || watchedEvent === event.type) {
              var $this = $(this),
                  target = slider.controlNav.index($this);

              if (!$this.hasClass(namespace + 'active')) {
                slider.direction = (target > slider.currentSlide) ? "next" : "prev";
                slider.flexAnimate(target, slider.vars.pauseOnAction);
              }
            }

            // setup flags to prevent event duplication
            if (watchedEvent === "") {
              watchedEvent = event.type;
            }
            methods.setToClearWatchedEvent();

          });
        },
        setupManual: function() {
          slider.controlNav = slider.manualControls;
          methods.controlNav.active();

          slider.controlNav.bind(eventType, function(event) {
            event.preventDefault();

            if (watchedEvent === "" || watchedEvent === event.type) {
              var $this = $(this),
                  target = slider.controlNav.index($this);

              if (!$this.hasClass(namespace + 'active')) {
                (target > slider.currentSlide) ? slider.direction = "next" : slider.direction = "prev";
                slider.flexAnimate(target, slider.vars.pauseOnAction);
              }
            }

            // setup flags to prevent event duplication
            if (watchedEvent === "") {
              watchedEvent = event.type;
            }
            methods.setToClearWatchedEvent();
          });
        },
        set: function() {
          var selector = (slider.vars.controlNav === "thumbnails") ? 'img' : 'a';
          slider.controlNav = $('.' + namespace + 'control-nav li ' + selector, (slider.controlsContainer) ? slider.controlsContainer : slider);
        },
        active: function() {
          slider.controlNav.removeClass(namespace + "active").eq(slider.animatingTo).addClass(namespace + "active");
        },
        update: function(action, pos) {
          if (slider.pagingCount > 1 && action === "add") {
            slider.controlNavScaffold.append($('<li><a href="#">' + slider.count + '</a></li>'));
          } else if (slider.pagingCount === 1) {
            slider.controlNavScaffold.find('li').remove();
          } else {
            slider.controlNav.eq(pos).closest('li').remove();
          }
          methods.controlNav.set();
          (slider.pagingCount > 1 && slider.pagingCount !== slider.controlNav.length) ? slider.update(pos, action) : methods.controlNav.active();
        }
      },
      directionNav: {
        setup: function() {
          var directionNavScaffold = $('<ul class="' + namespace + 'direction-nav"><li class="' + namespace + 'nav-prev"><a class="' + namespace + 'prev" href="#">' + slider.vars.prevText + '</a></li><li class="' + namespace + 'nav-next"><a class="' + namespace + 'next" href="#">' + slider.vars.nextText + '</a></li></ul>');

          // CUSTOM DIRECTION NAV:
          if (slider.customDirectionNav) {
            slider.directionNav = slider.customDirectionNav;
          // CONTROLSCONTAINER:
          } else if (slider.controlsContainer) {
            $(slider.controlsContainer).append(directionNavScaffold);
            slider.directionNav = $('.' + namespace + 'direction-nav li a', slider.controlsContainer);
          } else {
            slider.append(directionNavScaffold);
            slider.directionNav = $('.' + namespace + 'direction-nav li a', slider);
          }

          methods.directionNav.update();

          slider.directionNav.bind(eventType, function(event) {
            event.preventDefault();
            var target;

            if (watchedEvent === "" || watchedEvent === event.type) {
              target = ($(this).hasClass(namespace + 'next')) ? slider.getTarget('next') : slider.getTarget('prev');
              slider.flexAnimate(target, slider.vars.pauseOnAction);
            }

            // setup flags to prevent event duplication
            if (watchedEvent === "") {
              watchedEvent = event.type;
            }
            methods.setToClearWatchedEvent();
          });
        },
        update: function() {
          var disabledClass = namespace + 'disabled';
          if (slider.pagingCount === 1) {
            slider.directionNav.addClass(disabledClass).attr('tabindex', '-1');
          } else if (!slider.vars.animationLoop) {
            if (slider.animatingTo === 0) {
              slider.directionNav.removeClass(disabledClass).filter('.' + namespace + "prev").addClass(disabledClass).attr('tabindex', '-1');
            } else if (slider.animatingTo === slider.last) {
              slider.directionNav.removeClass(disabledClass).filter('.' + namespace + "next").addClass(disabledClass).attr('tabindex', '-1');
            } else {
              slider.directionNav.removeClass(disabledClass).removeAttr('tabindex');
            }
          } else {
            slider.directionNav.removeClass(disabledClass).removeAttr('tabindex');
          }
        }
      },
      pausePlay: {
        setup: function() {
          var pausePlayScaffold = $('<div class="' + namespace + 'pauseplay"><a href="#"></a></div>');

          // CONTROLSCONTAINER:
          if (slider.controlsContainer) {
            slider.controlsContainer.append(pausePlayScaffold);
            slider.pausePlay = $('.' + namespace + 'pauseplay a', slider.controlsContainer);
          } else {
            slider.append(pausePlayScaffold);
            slider.pausePlay = $('.' + namespace + 'pauseplay a', slider);
          }

          methods.pausePlay.update((slider.vars.slideshow) ? namespace + 'pause' : namespace + 'play');

          slider.pausePlay.bind(eventType, function(event) {
            event.preventDefault();

            if (watchedEvent === "" || watchedEvent === event.type) {
              if ($(this).hasClass(namespace + 'pause')) {
                slider.manualPause = true;
                slider.manualPlay = false;
                slider.pause();
              } else {
                slider.manualPause = false;
                slider.manualPlay = true;
                slider.play();
              }
            }

            // setup flags to prevent event duplication
            if (watchedEvent === "") {
              watchedEvent = event.type;
            }
            methods.setToClearWatchedEvent();
          });
        },
        update: function(state) {
          (state === "play") ? slider.pausePlay.removeClass(namespace + 'pause').addClass(namespace + 'play').html(slider.vars.playText) : slider.pausePlay.removeClass(namespace + 'play').addClass(namespace + 'pause').html(slider.vars.pauseText);
        }
      },
      touch: function() {
        var startX,
          startY,
          offset,
          cwidth,
          dx,
          startT,
          onTouchStart,
          onTouchMove,
          onTouchEnd,
          scrolling = false,
          localX = 0,
          localY = 0,
          accDx = 0;

        if(!msGesture){
            onTouchStart = function(e) {
              if (slider.animating) {
                e.preventDefault();
              } else if ( ( window.navigator.msPointerEnabled ) || e.touches.length === 1 ) {
                slider.pause();
                // CAROUSEL:
                cwidth = (vertical) ? slider.h : slider. w;
                startT = Number(new Date());
                // CAROUSEL:

                // Local vars for X and Y points.
                localX = e.touches[0].pageX;
                localY = e.touches[0].pageY;

                offset = (carousel && reverse && slider.animatingTo === slider.last) ? 0 :
                         (carousel && reverse) ? slider.limit - (((slider.itemW + slider.vars.itemMargin) * slider.move) * slider.animatingTo) :
                         (carousel && slider.currentSlide === slider.last) ? slider.limit :
                         (carousel) ? ((slider.itemW + slider.vars.itemMargin) * slider.move) * slider.currentSlide :
                         (reverse) ? (slider.last - slider.currentSlide + slider.cloneOffset) * cwidth : (slider.currentSlide + slider.cloneOffset) * cwidth;
                startX = (vertical) ? localY : localX;
                startY = (vertical) ? localX : localY;

                el.addEventListener('touchmove', onTouchMove, false);
                el.addEventListener('touchend', onTouchEnd, false);
              }
            };

            onTouchMove = function(e) {
              // Local vars for X and Y points.

              localX = e.touches[0].pageX;
              localY = e.touches[0].pageY;

              dx = (vertical) ? startX - localY : startX - localX;
              scrolling = (vertical) ? (Math.abs(dx) < Math.abs(localX - startY)) : (Math.abs(dx) < Math.abs(localY - startY));

              var fxms = 500;

              if ( ! scrolling || Number( new Date() ) - startT > fxms ) {
                e.preventDefault();
                if (!fade && slider.transitions) {
                  if (!slider.vars.animationLoop) {
                    dx = dx/((slider.currentSlide === 0 && dx < 0 || slider.currentSlide === slider.last && dx > 0) ? (Math.abs(dx)/cwidth+2) : 1);
                  }
                  slider.setProps(offset + dx, "setTouch");
                }
              }
            };

            onTouchEnd = function(e) {
              // finish the touch by undoing the touch session
              el.removeEventListener('touchmove', onTouchMove, false);

              if (slider.animatingTo === slider.currentSlide && !scrolling && !(dx === null)) {
                var updateDx = (reverse) ? -dx : dx,
                    target = (updateDx > 0) ? slider.getTarget('next') : slider.getTarget('prev');

                if (slider.canAdvance(target) && (Number(new Date()) - startT < 550 && Math.abs(updateDx) > 50 || Math.abs(updateDx) > cwidth/2)) {
                  slider.flexAnimate(target, slider.vars.pauseOnAction);
                } else {
                  if (!fade) { slider.flexAnimate(slider.currentSlide, slider.vars.pauseOnAction, true); }
                }
              }
              el.removeEventListener('touchend', onTouchEnd, false);

              startX = null;
              startY = null;
              dx = null;
              offset = null;
            };

            el.addEventListener('touchstart', onTouchStart, false);
        }else{
            el.style.msTouchAction = "none";
            el._gesture = new MSGesture();
            el._gesture.target = el;
            el.addEventListener("MSPointerDown", onMSPointerDown, false);
            el._slider = slider;
            el.addEventListener("MSGestureChange", onMSGestureChange, false);
            el.addEventListener("MSGestureEnd", onMSGestureEnd, false);

            function onMSPointerDown(e){
                e.stopPropagation();
                if (slider.animating) {
                    e.preventDefault();
                }else{
                    slider.pause();
                    el._gesture.addPointer(e.pointerId);
                    accDx = 0;
                    cwidth = (vertical) ? slider.h : slider. w;
                    startT = Number(new Date());
                    // CAROUSEL:

                    offset = (carousel && reverse && slider.animatingTo === slider.last) ? 0 :
                        (carousel && reverse) ? slider.limit - (((slider.itemW + slider.vars.itemMargin) * slider.move) * slider.animatingTo) :
                            (carousel && slider.currentSlide === slider.last) ? slider.limit :
                                (carousel) ? ((slider.itemW + slider.vars.itemMargin) * slider.move) * slider.currentSlide :
                                    (reverse) ? (slider.last - slider.currentSlide + slider.cloneOffset) * cwidth : (slider.currentSlide + slider.cloneOffset) * cwidth;
                }
            }

            function onMSGestureChange(e) {
                e.stopPropagation();
                var slider = e.target._slider;
                if(!slider){
                    return;
                }
                var transX = -e.translationX,
                    transY = -e.translationY;

                //Accumulate translations.
                accDx = accDx + ((vertical) ? transY : transX);
                dx = accDx;
                scrolling = (vertical) ? (Math.abs(accDx) < Math.abs(-transX)) : (Math.abs(accDx) < Math.abs(-transY));

                if(e.detail === e.MSGESTURE_FLAG_INERTIA){
                    setImmediate(function (){
                        el._gesture.stop();
                    });

                    return;
                }

                if (!scrolling || Number(new Date()) - startT > 500) {
                    e.preventDefault();
                    if (!fade && slider.transitions) {
                        if (!slider.vars.animationLoop) {
                            dx = accDx / ((slider.currentSlide === 0 && accDx < 0 || slider.currentSlide === slider.last && accDx > 0) ? (Math.abs(accDx) / cwidth + 2) : 1);
                        }
                        slider.setProps(offset + dx, "setTouch");
                    }
                }
            }

            function onMSGestureEnd(e) {
                e.stopPropagation();
                var slider = e.target._slider;
                if(!slider){
                    return;
                }
                if (slider.animatingTo === slider.currentSlide && !scrolling && !(dx === null)) {
                    var updateDx = (reverse) ? -dx : dx,
                        target = (updateDx > 0) ? slider.getTarget('next') : slider.getTarget('prev');

                    if (slider.canAdvance(target) && (Number(new Date()) - startT < 550 && Math.abs(updateDx) > 50 || Math.abs(updateDx) > cwidth/2)) {
                        slider.flexAnimate(target, slider.vars.pauseOnAction);
                    } else {
                        if (!fade) { slider.flexAnimate(slider.currentSlide, slider.vars.pauseOnAction, true); }
                    }
                }

                startX = null;
                startY = null;
                dx = null;
                offset = null;
                accDx = 0;
            }
        }
      },
      resize: function() {
        if (!slider.animating && slider.is(':visible')) {
          if (!carousel) { slider.doMath(); }

          if (fade) {
            // SMOOTH HEIGHT:
            methods.smoothHeight();
          } else if (carousel) { //CAROUSEL:
            slider.slides.width(slider.computedW);
            slider.update(slider.pagingCount);
            slider.setProps();
          }
          else if (vertical) { //VERTICAL:
            slider.viewport.height(slider.h);
            slider.setProps(slider.h, "setTotal");
          } else {
            // SMOOTH HEIGHT:
            if (slider.vars.smoothHeight) { methods.smoothHeight(); }
            slider.newSlides.width(slider.computedW);
            slider.setProps(slider.computedW, "setTotal");
          }
        }
      },
      smoothHeight: function(dur) {
        if (!vertical || fade) {
          var $obj = (fade) ? slider : slider.viewport;
          (dur) ? $obj.animate({"height": slider.slides.eq(slider.animatingTo).innerHeight()}, dur) : $obj.innerHeight(slider.slides.eq(slider.animatingTo).innerHeight());
        }
      },
      sync: function(action) {
        var $obj = $(slider.vars.sync).data("flexslider"),
            target = slider.animatingTo;

        switch (action) {
          case "animate": $obj.flexAnimate(target, slider.vars.pauseOnAction, false, true); break;
          case "play": if (!$obj.playing && !$obj.asNav) { $obj.play(); } break;
          case "pause": $obj.pause(); break;
        }
      },
      uniqueID: function($clone) {
        // Append _clone to current level and children elements with id attributes
        $clone.filter( '[id]' ).add($clone.find( '[id]' )).each(function() {
          var $this = $(this);
          $this.attr( 'id', $this.attr( 'id' ) + '_clone' );
        });
        return $clone;
      },
      pauseInvisible: {
        visProp: null,
        init: function() {
          var visProp = methods.pauseInvisible.getHiddenProp();
          if (visProp) {
            var evtname = visProp.replace(/[H|h]idden/,'') + 'visibilitychange';
            document.addEventListener(evtname, function() {
              if (methods.pauseInvisible.isHidden()) {
                if(slider.startTimeout) {
                  clearTimeout(slider.startTimeout); //If clock is ticking, stop timer and prevent from starting while invisible
                } else {
                  slider.pause(); //Or just pause
                }
              }
              else {
                if(slider.started) {
                  slider.play(); //Initiated before, just play
                } else {
                  if (slider.vars.initDelay > 0) {
                    setTimeout(slider.play, slider.vars.initDelay);
                  } else {
                    slider.play(); //Didn't init before: simply init or wait for it
                  }
                }
              }
            });
          }
        },
        isHidden: function() {
          var prop = methods.pauseInvisible.getHiddenProp();
          if (!prop) {
            return false;
          }
          return document[prop];
        },
        getHiddenProp: function() {
          var prefixes = ['webkit','moz','ms','o'];
          // if 'hidden' is natively supported just return it
          if ('hidden' in document) {
            return 'hidden';
          }
          // otherwise loop over all the known prefixes until we find one
          for ( var i = 0; i < prefixes.length; i++ ) {
              if ((prefixes[i] + 'Hidden') in document) {
                return prefixes[i] + 'Hidden';
              }
          }
          // otherwise it's not supported
          return null;
        }
      },
      setToClearWatchedEvent: function() {
        clearTimeout(watchedEventClearTimer);
        watchedEventClearTimer = setTimeout(function() {
          watchedEvent = "";
        }, 3000);
      }
    };

    // public methods
    slider.flexAnimate = function(target, pause, override, withSync, fromNav) {
      if (!slider.vars.animationLoop && target !== slider.currentSlide) {
        slider.direction = (target > slider.currentSlide) ? "next" : "prev";
      }

      if (asNav && slider.pagingCount === 1) slider.direction = (slider.currentItem < target) ? "next" : "prev";

      if (!slider.animating && (slider.canAdvance(target, fromNav) || override) && slider.is(":visible")) {
        if (asNav && withSync) {
          var master = $(slider.vars.asNavFor).data('flexslider');
          slider.atEnd = target === 0 || target === slider.count - 1;
          master.flexAnimate(target, true, false, true, fromNav);
          slider.direction = (slider.currentItem < target) ? "next" : "prev";
          master.direction = slider.direction;

          if (Math.ceil((target + 1)/slider.visible) - 1 !== slider.currentSlide && target !== 0) {
            slider.currentItem = target;
            slider.slides.removeClass(namespace + "active-slide").eq(target).addClass(namespace + "active-slide");
            target = Math.floor(target/slider.visible);
          } else {
            slider.currentItem = target;
            slider.slides.removeClass(namespace + "active-slide").eq(target).addClass(namespace + "active-slide");
            return false;
          }
        }

        slider.animating = true;
        slider.animatingTo = target;

        // SLIDESHOW:
        if (pause) { slider.pause(); }

        // API: before() animation Callback
        slider.vars.before(slider);

        // SYNC:
        if (slider.syncExists && !fromNav) { methods.sync("animate"); }

        // CONTROLNAV
        if (slider.vars.controlNav) { methods.controlNav.active(); }

        // !CAROUSEL:
        // CANDIDATE: slide active class (for add/remove slide)
        if (!carousel) { slider.slides.removeClass(namespace + 'active-slide').eq(target).addClass(namespace + 'active-slide'); }

        // INFINITE LOOP:
        // CANDIDATE: atEnd
        slider.atEnd = target === 0 || target === slider.last;

        // DIRECTIONNAV:
        if (slider.vars.directionNav) { methods.directionNav.update(); }

        if (target === slider.last) {
          // API: end() of cycle Callback
          slider.vars.end(slider);
          // SLIDESHOW && !INFINITE LOOP:
          if (!slider.vars.animationLoop) { slider.pause(); }
        }

        // SLIDE:
        if (!fade) {
          var dimension = (vertical) ? slider.slides.filter(':first').height() : slider.computedW,
              margin, slideString, calcNext;

          // INFINITE LOOP / REVERSE:
          if (carousel) {
            margin = slider.vars.itemMargin;
            calcNext = ((slider.itemW + margin) * slider.move) * slider.animatingTo;
            slideString = (calcNext > slider.limit && slider.visible !== 1) ? slider.limit : calcNext;
          } else if (slider.currentSlide === 0 && target === slider.count - 1 && slider.vars.animationLoop && slider.direction !== "next") {
            slideString = (reverse) ? (slider.count + slider.cloneOffset) * dimension : 0;
          } else if (slider.currentSlide === slider.last && target === 0 && slider.vars.animationLoop && slider.direction !== "prev") {
            slideString = (reverse) ? 0 : (slider.count + 1) * dimension;
          } else {
            slideString = (reverse) ? ((slider.count - 1) - target + slider.cloneOffset) * dimension : (target + slider.cloneOffset) * dimension;
          }
          slider.setProps(slideString, "", slider.vars.animationSpeed);
          if (slider.transitions) {
            if (!slider.vars.animationLoop || !slider.atEnd) {
              slider.animating = false;
              slider.currentSlide = slider.animatingTo;
            }

            // Unbind previous transitionEnd events and re-bind new transitionEnd event
            slider.container.unbind("webkitTransitionEnd transitionend");
            slider.container.bind("webkitTransitionEnd transitionend", function() {
              clearTimeout(slider.ensureAnimationEnd);
              slider.wrapup(dimension);
            });

            // Insurance for the ever-so-fickle transitionEnd event
            clearTimeout(slider.ensureAnimationEnd);
            slider.ensureAnimationEnd = setTimeout(function() {
              slider.wrapup(dimension);
            }, slider.vars.animationSpeed + 100);

          } else {
            slider.container.animate(slider.args, slider.vars.animationSpeed, slider.vars.easing, function(){
              slider.wrapup(dimension);
            });
          }
        } else { // FADE:
          if (!touch) {
            slider.slides.eq(slider.currentSlide).css({"zIndex": 1}).animate({"opacity": 0}, slider.vars.animationSpeed, slider.vars.easing);
            slider.slides.eq(target).css({"zIndex": 2}).animate({"opacity": 1}, slider.vars.animationSpeed, slider.vars.easing, slider.wrapup);
          } else {
            slider.slides.eq(slider.currentSlide).css({ "opacity": 0, "zIndex": 1 });
            slider.slides.eq(target).css({ "opacity": 1, "zIndex": 2 });
            slider.wrapup(dimension);
          }
        }
        // SMOOTH HEIGHT:
        if (slider.vars.smoothHeight) { methods.smoothHeight(slider.vars.animationSpeed); }
      }
    };
    slider.wrapup = function(dimension) {
      // SLIDE:
      if (!fade && !carousel) {
        if (slider.currentSlide === 0 && slider.animatingTo === slider.last && slider.vars.animationLoop) {
          slider.setProps(dimension, "jumpEnd");
        } else if (slider.currentSlide === slider.last && slider.animatingTo === 0 && slider.vars.animationLoop) {
          slider.setProps(dimension, "jumpStart");
        }
      }
      slider.animating = false;
      slider.currentSlide = slider.animatingTo;
      // API: after() animation Callback
      slider.vars.after(slider);
    };

    // SLIDESHOW:
    slider.animateSlides = function() {
      if (!slider.animating && focused ) { slider.flexAnimate(slider.getTarget("next")); }
    };
    // SLIDESHOW:
    slider.pause = function() {
      clearInterval(slider.animatedSlides);
      slider.animatedSlides = null;
      slider.playing = false;
      // PAUSEPLAY:
      if (slider.vars.pausePlay) { methods.pausePlay.update("play"); }
      // SYNC:
      if (slider.syncExists) { methods.sync("pause"); }
    };
    // SLIDESHOW:
    slider.play = function() {
      if (slider.playing) { clearInterval(slider.animatedSlides); }
      slider.animatedSlides = slider.animatedSlides || setInterval(slider.animateSlides, slider.vars.slideshowSpeed);
      slider.started = slider.playing = true;
      // PAUSEPLAY:
      if (slider.vars.pausePlay) { methods.pausePlay.update("pause"); }
      // SYNC:
      if (slider.syncExists) { methods.sync("play"); }
    };
    // STOP:
    slider.stop = function () {
      slider.pause();
      slider.stopped = true;
    };
    slider.canAdvance = function(target, fromNav) {
      // ASNAV:
      var last = (asNav) ? slider.pagingCount - 1 : slider.last;
      return (fromNav) ? true :
             (asNav && slider.currentItem === slider.count - 1 && target === 0 && slider.direction === "prev") ? true :
             (asNav && slider.currentItem === 0 && target === slider.pagingCount - 1 && slider.direction !== "next") ? false :
             (target === slider.currentSlide && !asNav) ? false :
             (slider.vars.animationLoop) ? true :
             (slider.atEnd && slider.currentSlide === 0 && target === last && slider.direction !== "next") ? false :
             (slider.atEnd && slider.currentSlide === last && target === 0 && slider.direction === "next") ? false :
             true;
    };
    slider.getTarget = function(dir) {
      slider.direction = dir;
      if (dir === "next") {
        return (slider.currentSlide === slider.last) ? 0 : slider.currentSlide + 1;
      } else {
        return (slider.currentSlide === 0) ? slider.last : slider.currentSlide - 1;
      }
    };

    // SLIDE:
    slider.setProps = function(pos, special, dur) {
      var target = (function() {
        var posCheck = (pos) ? pos : ((slider.itemW + slider.vars.itemMargin) * slider.move) * slider.animatingTo,
            posCalc = (function() {
              if (carousel) {
                return (special === "setTouch") ? pos :
                       (reverse && slider.animatingTo === slider.last) ? 0 :
                       (reverse) ? slider.limit - (((slider.itemW + slider.vars.itemMargin) * slider.move) * slider.animatingTo) :
                       (slider.animatingTo === slider.last) ? slider.limit : posCheck;
              } else {
                switch (special) {
                  case "setTotal": return (reverse) ? ((slider.count - 1) - slider.currentSlide + slider.cloneOffset) * pos : (slider.currentSlide + slider.cloneOffset) * pos;
                  case "setTouch": return (reverse) ? pos : pos;
                  case "jumpEnd": return (reverse) ? pos : slider.count * pos;
                  case "jumpStart": return (reverse) ? slider.count * pos : pos;
                  default: return pos;
                }
              }
            }());

            return (posCalc * -1) + "px";
          }());

      if (slider.transitions) {
        target = (vertical) ? "translate3d(0," + target + ",0)" : "translate3d(" + target + ",0,0)";
        dur = (dur !== undefined) ? (dur/1000) + "s" : "0s";
        slider.container.css("-" + slider.pfx + "-transition-duration", dur);
         slider.container.css("transition-duration", dur);
      }

      slider.args[slider.prop] = target;
      if (slider.transitions || dur === undefined) { slider.container.css(slider.args); }

      slider.container.css('transform',target);
    };

    slider.setup = function(type) {
      // SLIDE:
      if (!fade) {
        var sliderOffset, arr;

        if (type === "init") {
          slider.viewport = $('<div class="' + namespace + 'viewport"></div>').css({"overflow": "hidden", "position": "relative"}).appendTo(slider).append(slider.container);
          // INFINITE LOOP:
          slider.cloneCount = 0;
          slider.cloneOffset = 0;
          // REVERSE:
          if (reverse) {
            arr = $.makeArray(slider.slides).reverse();
            slider.slides = $(arr);
            slider.container.empty().append(slider.slides);
          }
        }
        // INFINITE LOOP && !CAROUSEL:
        if (slider.vars.animationLoop && !carousel) {
          slider.cloneCount = 2;
          slider.cloneOffset = 1;
          // clear out old clones
          if (type !== "init") { slider.container.find('.clone').remove(); }
          slider.container.append(methods.uniqueID(slider.slides.first().clone().addClass('clone')).attr('aria-hidden', 'true'))
                          .prepend(methods.uniqueID(slider.slides.last().clone().addClass('clone')).attr('aria-hidden', 'true'));
        }
        slider.newSlides = $(slider.vars.selector, slider);

        sliderOffset = (reverse) ? slider.count - 1 - slider.currentSlide + slider.cloneOffset : slider.currentSlide + slider.cloneOffset;
        // VERTICAL:
        if (vertical && !carousel) {
          slider.container.height((slider.count + slider.cloneCount) * 200 + "%").css("position", "absolute").width("100%");
          setTimeout(function(){
            slider.newSlides.css({"display": "block"});
            slider.doMath();
            slider.viewport.height(slider.h);
            slider.setProps(sliderOffset * slider.h, "init");
          }, (type === "init") ? 100 : 0);
        } else {
          slider.container.width((slider.count + slider.cloneCount) * 200 + "%");
          slider.setProps(sliderOffset * slider.computedW, "init");
          setTimeout(function(){
            slider.doMath();
            slider.newSlides.css({"width": slider.computedW, "marginRight" : slider.computedM, "float": "left", "display": "block"});
            // SMOOTH HEIGHT:
            if (slider.vars.smoothHeight) { methods.smoothHeight(); }
          }, (type === "init") ? 100 : 0);
        }
      } else { // FADE:
        slider.slides.css({"width": "100%", "float": "left", "marginRight": "-100%", "position": "relative"});
        if (type === "init") {
          if (!touch) {
            //slider.slides.eq(slider.currentSlide).fadeIn(slider.vars.animationSpeed, slider.vars.easing);
            if (slider.vars.fadeFirstSlide == false) {
              slider.slides.css({ "opacity": 0, "display": "block", "zIndex": 1 }).eq(slider.currentSlide).css({"zIndex": 2}).css({"opacity": 1});
            } else {
              slider.slides.css({ "opacity": 0, "display": "block", "zIndex": 1 }).eq(slider.currentSlide).css({"zIndex": 2}).animate({"opacity": 1},slider.vars.animationSpeed,slider.vars.easing);
            }
          } else {
            slider.slides.css({ "opacity": 0, "display": "block", "webkitTransition": "opacity " + slider.vars.animationSpeed / 1000 + "s ease", "zIndex": 1 }).eq(slider.currentSlide).css({ "opacity": 1, "zIndex": 2});
          }
        }
        // SMOOTH HEIGHT:
        if (slider.vars.smoothHeight) { methods.smoothHeight(); }
      }
      // !CAROUSEL:
      // CANDIDATE: active slide
      if (!carousel) { slider.slides.removeClass(namespace + "active-slide").eq(slider.currentSlide).addClass(namespace + "active-slide"); }

      //FlexSlider: init() Callback
      slider.vars.init(slider);
    };

    slider.doMath = function() {
      var slide = slider.slides.first(),
          slideMargin = slider.vars.itemMargin,
          minItems = slider.vars.minItems,
          maxItems = slider.vars.maxItems;

      slider.w = (slider.viewport===undefined) ? slider.width() : slider.viewport.width();
      slider.h = slide.height();
      slider.boxPadding = slide.outerWidth() - slide.width();

      // CAROUSEL:
      if (carousel) {
        slider.itemT = slider.vars.itemWidth + slideMargin;
        slider.itemM = slideMargin;
        slider.minW = (minItems) ? minItems * slider.itemT : slider.w;
        slider.maxW = (maxItems) ? (maxItems * slider.itemT) - slideMargin : slider.w;
        slider.itemW = (slider.minW > slider.w) ? (slider.w - (slideMargin * (minItems - 1)))/minItems :
                       (slider.maxW < slider.w) ? (slider.w - (slideMargin * (maxItems - 1)))/maxItems :
                       (slider.vars.itemWidth > slider.w) ? slider.w : slider.vars.itemWidth;

        slider.visible = Math.floor(slider.w/(slider.itemW));
        slider.move = (slider.vars.move > 0 && slider.vars.move < slider.visible ) ? slider.vars.move : slider.visible;
        slider.pagingCount = Math.ceil(((slider.count - slider.visible)/slider.move) + 1);
        slider.last =  slider.pagingCount - 1;
        slider.limit = (slider.pagingCount === 1) ? 0 :
                       (slider.vars.itemWidth > slider.w) ? (slider.itemW * (slider.count - 1)) + (slideMargin * (slider.count - 1)) : ((slider.itemW + slideMargin) * slider.count) - slider.w - slideMargin;
      } else {
        slider.itemW = slider.w;
        slider.itemM = slideMargin;
        slider.pagingCount = slider.count;
        slider.last = slider.count - 1;
      }
      slider.computedW = slider.itemW - slider.boxPadding;
      slider.computedM = slider.itemM;
    };

    slider.update = function(pos, action) {
      slider.doMath();

      // update currentSlide and slider.animatingTo if necessary
      if (!carousel) {
        if (pos < slider.currentSlide) {
          slider.currentSlide += 1;
        } else if (pos <= slider.currentSlide && pos !== 0) {
          slider.currentSlide -= 1;
        }
        slider.animatingTo = slider.currentSlide;
      }

      // update controlNav
      if (slider.vars.controlNav && !slider.manualControls) {
        if ((action === "add" && !carousel) || slider.pagingCount > slider.controlNav.length) {
          methods.controlNav.update("add");
        } else if ((action === "remove" && !carousel) || slider.pagingCount < slider.controlNav.length) {
          if (carousel && slider.currentSlide > slider.last) {
            slider.currentSlide -= 1;
            slider.animatingTo -= 1;
          }
          methods.controlNav.update("remove", slider.last);
        }
      }
      // update directionNav
      if (slider.vars.directionNav) { methods.directionNav.update(); }

    };

    slider.addSlide = function(obj, pos) {
      var $obj = $(obj);

      slider.count += 1;
      slider.last = slider.count - 1;

      // append new slide
      if (vertical && reverse) {
        (pos !== undefined) ? slider.slides.eq(slider.count - pos).after($obj) : slider.container.prepend($obj);
      } else {
        (pos !== undefined) ? slider.slides.eq(pos).before($obj) : slider.container.append($obj);
      }

      // update currentSlide, animatingTo, controlNav, and directionNav
      slider.update(pos, "add");

      // update slider.slides
      slider.slides = $(slider.vars.selector + ':not(.clone)', slider);
      // re-setup the slider to accomdate new slide
      slider.setup();

      //FlexSlider: added() Callback
      slider.vars.added(slider);
    };
    slider.removeSlide = function(obj) {
      var pos = (isNaN(obj)) ? slider.slides.index($(obj)) : obj;

      // update count
      slider.count -= 1;
      slider.last = slider.count - 1;

      // remove slide
      if (isNaN(obj)) {
        $(obj, slider.slides).remove();
      } else {
        (vertical && reverse) ? slider.slides.eq(slider.last).remove() : slider.slides.eq(obj).remove();
      }

      // update currentSlide, animatingTo, controlNav, and directionNav
      slider.doMath();
      slider.update(pos, "remove");

      // update slider.slides
      slider.slides = $(slider.vars.selector + ':not(.clone)', slider);
      // re-setup the slider to accomdate new slide
      slider.setup();

      // FlexSlider: removed() Callback
      slider.vars.removed(slider);
    };

    //FlexSlider: Initialize
    methods.init();
  };

  // Ensure the slider isn't focussed if the window loses focus.
  $( window ).blur( function ( e ) {
    focused = false;
  }).focus( function ( e ) {
    focused = true;
  });

  //FlexSlider: Default Settings
  $.flexslider.defaults = {
    namespace: "flex-",             //{NEW} String: Prefix string attached to the class of every element generated by the plugin
    selector: ".slides > li",       //{NEW} Selector: Must match a simple pattern. '{container} > {slide}' -- Ignore pattern at your own peril
    animation: "fade",              //String: Select your animation type, "fade" or "slide"
    easing: "swing",                //{NEW} String: Determines the easing method used in jQuery transitions. jQuery easing plugin is supported!
    direction: "horizontal",        //String: Select the sliding direction, "horizontal" or "vertical"
    reverse: false,                 //{NEW} Boolean: Reverse the animation direction
    animationLoop: true,            //Boolean: Should the animation loop? If false, directionNav will received "disable" classes at either end
    smoothHeight: false,            //{NEW} Boolean: Allow height of the slider to animate smoothly in horizontal mode
    startAt: 0,                     //Integer: The slide that the slider should start on. Array notation (0 = first slide)
    slideshow: true,                //Boolean: Animate slider automatically
    slideshowSpeed: 7000,           //Integer: Set the speed of the slideshow cycling, in milliseconds
    animationSpeed: 600,            //Integer: Set the speed of animations, in milliseconds
    initDelay: 0,                   //{NEW} Integer: Set an initialization delay, in milliseconds
    randomize: false,               //Boolean: Randomize slide order
    fadeFirstSlide: true,           //Boolean: Fade in the first slide when animation type is "fade"
    thumbCaptions: false,           //Boolean: Whether or not to put captions on thumbnails when using the "thumbnails" controlNav.

    // Usability features
    pauseOnAction: true,            //Boolean: Pause the slideshow when interacting with control elements, highly recommended.
    pauseOnHover: false,            //Boolean: Pause the slideshow when hovering over slider, then resume when no longer hovering
    pauseInvisible: true,   		//{NEW} Boolean: Pause the slideshow when tab is invisible, resume when visible. Provides better UX, lower CPU usage.
    useCSS: true,                   //{NEW} Boolean: Slider will use CSS3 transitions if available
    touch: true,                    //{NEW} Boolean: Allow touch swipe navigation of the slider on touch-enabled devices
    video: false,                   //{NEW} Boolean: If using video in the slider, will prevent CSS3 3D Transforms to avoid graphical glitches

    // Primary Controls
    controlNav: true,               //Boolean: Create navigation for paging control of each slide? Note: Leave true for manualControls usage
    directionNav: true,             //Boolean: Create navigation for previous/next navigation? (true/false)
    prevText: "Previous",           //String: Set the text for the "previous" directionNav item
    nextText: "Next",               //String: Set the text for the "next" directionNav item

    // Secondary Navigation
    keyboard: true,                 //Boolean: Allow slider navigating via keyboard left/right keys
    multipleKeyboard: false,        //{NEW} Boolean: Allow keyboard navigation to affect multiple sliders. Default behavior cuts out keyboard navigation with more than one slider present.
    mousewheel: false,              //{UPDATED} Boolean: Requires jquery.mousewheel.js (https://github.com/brandonaaron/jquery-mousewheel) - Allows slider navigating via mousewheel
    pausePlay: false,               //Boolean: Create pause/play dynamic element
    pauseText: "Pause",             //String: Set the text for the "pause" pausePlay item
    playText: "Play",               //String: Set the text for the "play" pausePlay item

    // Special properties
    controlsContainer: "",          //{UPDATED} jQuery Object/Selector: Declare which container the navigation elements should be appended too. Default container is the FlexSlider element. Example use would be $(".flexslider-container"). Property is ignored if given element is not found.
    manualControls: "",             //{UPDATED} jQuery Object/Selector: Declare custom control navigation. Examples would be $(".flex-control-nav li") or "#tabs-nav li img", etc. The number of elements in your controlNav should match the number of slides/tabs.
    customDirectionNav: "",         //{NEW} jQuery Object/Selector: Custom prev / next button. Must be two jQuery elements. In order to make the events work they have to have the classes "prev" and "next" (plus namespace)
    sync: "",                       //{NEW} Selector: Mirror the actions performed on this slider with another slider. Use with care.
    asNavFor: "",                   //{NEW} Selector: Internal property exposed for turning the slider into a thumbnail navigation for another slider

    // Carousel Options
    itemWidth: 0,                   //{NEW} Integer: Box-model width of individual carousel items, including horizontal borders and padding.
    itemMargin: 0,                  //{NEW} Integer: Margin between carousel items.
    minItems: 1,                    //{NEW} Integer: Minimum number of carousel items that should be visible. Items will resize fluidly when below this.
    maxItems: 0,                    //{NEW} Integer: Maxmimum number of carousel items that should be visible. Items will resize fluidly when above this limit.
    move: 0,                        //{NEW} Integer: Number of carousel items that should move on animation. If 0, slider will move all visible items.
    allowOneSlide: true,           //{NEW} Boolean: Whether or not to allow a slider comprised of a single slide

    // Callback API
    start: function(){},            //Callback: function(slider) - Fires when the slider loads the first slide
    before: function(){},           //Callback: function(slider) - Fires asynchronously with each slider animation
    after: function(){},            //Callback: function(slider) - Fires after each slider animation completes
    end: function(){},              //Callback: function(slider) - Fires when the slider reaches the last slide (asynchronous)
    added: function(){},            //{NEW} Callback: function(slider) - Fires after a slide is added
    removed: function(){},           //{NEW} Callback: function(slider) - Fires after a slide is removed
    init: function() {}             //{NEW} Callback: function(slider) - Fires after the slider is initially setup
  };

  //FlexSlider: Plugin Function
  $.fn.flexslider = function(options) {
    if (options === undefined) { options = {}; }

    if (typeof options === "object") {
      return this.each(function() {
        var $this = $(this),
            selector = (options.selector) ? options.selector : ".slides > li",
            $slides = $this.find(selector);

      if ( ( $slides.length === 1 && options.allowOneSlide === false ) || $slides.length === 0 ) {
          $slides.fadeIn(400);
          if (options.start) { options.start($this); }
        } else if ($this.data('flexslider') === undefined) {
          new $.flexslider(this, options);
        }
      });
    } else {
      // Helper strings to quickly perform functions on the slider
      var $slider = $(this).data('flexslider');
      switch (options) {
        case "play": $slider.play(); break;
        case "pause": $slider.pause(); break;
        case "stop": $slider.stop(); break;
        case "next": $slider.flexAnimate($slider.getTarget("next"), true); break;
        case "prev":
        case "previous": $slider.flexAnimate($slider.getTarget("prev"), true); break;
        default: if (typeof options === "number") { $slider.flexAnimate(options, true); }
      }
    }
  };
})(jQuery);
/**
* hoverIntent r6 // 2011.02.26 // jQuery 1.5.1+
* <http://cherne.net/brian/resources/jquery.hoverIntent.html>
* 
* @param  f  onMouseOver function || An object with configuration options
* @param  g  onMouseOut function  || Nothing (use configuration options object)
* @author    Brian Cherne brian(at)cherne(dot)net
*/

(function ($) { $.fn.hoverIntent = function (f, g) { var cfg = { sensitivity: 7, interval: 100, timeout: 0 }; cfg = $.extend(cfg, g ? { over: f, out: g} : f); var cX, cY, pX, pY; var track = function (ev) { cX = ev.pageX; cY = ev.pageY }; var compare = function (ev, ob) { ob.hoverIntent_t = clearTimeout(ob.hoverIntent_t); if ((Math.abs(pX - cX) + Math.abs(pY - cY)) < cfg.sensitivity) { $(ob).unbind("mousemove", track); ob.hoverIntent_s = 1; return cfg.over.apply(ob, [ev]) } else { pX = cX; pY = cY; ob.hoverIntent_t = setTimeout(function () { compare(ev, ob) }, cfg.interval) } }; var delay = function (ev, ob) { ob.hoverIntent_t = clearTimeout(ob.hoverIntent_t); ob.hoverIntent_s = 0; return cfg.out.apply(ob, [ev]) }; var handleHover = function (e) { var ev = jQuery.extend({}, e); var ob = this; if (ob.hoverIntent_t) { ob.hoverIntent_t = clearTimeout(ob.hoverIntent_t) } if (e.type == "mouseenter") { pX = ev.pageX; pY = ev.pageY; $(ob).bind("mousemove", track); if (ob.hoverIntent_s != 1) { ob.hoverIntent_t = setTimeout(function () { compare(ev, ob) }, cfg.interval) } } else { $(ob).unbind("mousemove", track); if (ob.hoverIntent_s == 1) { ob.hoverIntent_t = setTimeout(function () { delay(ev, ob) }, cfg.timeout) } } }; return this.bind('mouseenter', handleHover).bind('mouseleave', handleHover) } })(jQuery);
/*!
 * jCarousel - Riding carousels with jQuery
 *   http://sorgalla.com/jcarousel/
 *
 * Copyright (c) 2006 Jan Sorgalla (http://sorgalla.com)
 * Dual licensed under the MIT (http://www.opensource.org/licenses/mit-license.php)
 * and GPL (http://www.opensource.org/licenses/gpl-license.php) licenses.
 *
 * Built on top of the jQuery library
 *   http://jquery.com
 *
 * Inspired by the "Carousel Component" by Bill Scott
 *   http://billwscott.com/carousel/
 */

(function(g){var q={vertical:!1,rtl:!1,start:1,offset:1,size:null,scroll:3,visible:null,animation:"normal",easing:"swing",auto:0,wrap:null,initCallback:null,setupCallback:null,reloadCallback:null,itemLoadCallback:null,itemFirstInCallback:null,itemFirstOutCallback:null,itemLastInCallback:null,itemLastOutCallback:null,itemVisibleInCallback:null,itemVisibleOutCallback:null,animationStepCallback:null,buttonNextHTML:"<div></div>",buttonPrevHTML:"<div></div>",buttonNextEvent:"click",buttonPrevEvent:"click", buttonNextCallback:null,buttonPrevCallback:null,itemFallbackDimension:null},m=!1;g(window).bind("load.jcarousel",function(){m=!0});g.jcarousel=function(a,c){this.options=g.extend({},q,c||{});this.autoStopped=this.locked=!1;this.buttonPrevState=this.buttonNextState=this.buttonPrev=this.buttonNext=this.list=this.clip=this.container=null;if(!c||c.rtl===void 0)this.options.rtl=(g(a).attr("dir")||g("html").attr("dir")||"").toLowerCase()=="rtl";this.wh=!this.options.vertical?"width":"height";this.lt=!this.options.vertical? this.options.rtl?"right":"left":"top";for(var b="",d=a.className.split(" "),f=0;f<d.length;f++)if(d[f].indexOf("jcarousel-skin")!=-1){g(a).removeClass(d[f]);b=d[f];break}a.nodeName.toUpperCase()=="UL"||a.nodeName.toUpperCase()=="OL"?(this.list=g(a),this.clip=this.list.parents(".jcarousel-clip"),this.container=this.list.parents(".jcarousel-container")):(this.container=g(a),this.list=this.container.find("ul,ol").eq(0),this.clip=this.container.find(".jcarousel-clip"));if(this.clip.size()===0)this.clip= this.list.wrap("<div></div>").parent();if(this.container.size()===0)this.container=this.clip.wrap("<div></div>").parent();b!==""&&this.container.parent()[0].className.indexOf("jcarousel-skin")==-1&&this.container.wrap('<div class=" '+b+'"></div>');this.buttonPrev=g(".jcarousel-prev",this.container);if(this.buttonPrev.size()===0&&this.options.buttonPrevHTML!==null)this.buttonPrev=g(this.options.buttonPrevHTML).appendTo(this.container);this.buttonPrev.addClass(this.className("jcarousel-prev"));this.buttonNext= g(".jcarousel-next",this.container);if(this.buttonNext.size()===0&&this.options.buttonNextHTML!==null)this.buttonNext=g(this.options.buttonNextHTML).appendTo(this.container);this.buttonNext.addClass(this.className("jcarousel-next"));this.clip.addClass(this.className("jcarousel-clip")).css({position:"relative"});this.list.addClass(this.className("jcarousel-list")).css({overflow:"hidden",position:"relative",top:0,margin:0,padding:0}).css(this.options.rtl?"right":"left",0);this.container.addClass(this.className("jcarousel-container")).css({position:"relative"}); !this.options.vertical&&this.options.rtl&&this.container.addClass("jcarousel-direction-rtl").attr("dir","rtl");var j=this.options.visible!==null?Math.ceil(this.clipping()/this.options.visible):null,b=this.list.children("li"),e=this;if(b.size()>0){var h=0,i=this.options.offset;b.each(function(){e.format(this,i++);h+=e.dimension(this,j)});this.list.css(this.wh,h+100+"px");if(!c||c.size===void 0)this.options.size=b.size()}this.container.css("display","block");this.buttonNext.css("display","block");this.buttonPrev.css("display", "block");this.funcNext=function(){e.next()};this.funcPrev=function(){e.prev()};this.funcResize=function(){e.resizeTimer&&clearTimeout(e.resizeTimer);e.resizeTimer=setTimeout(function(){e.reload()},100)};this.options.initCallback!==null&&this.options.initCallback(this,"init");!m&&g.browser.safari?(this.buttons(!1,!1),g(window).bind("load.jcarousel",function(){e.setup()})):this.setup()};var f=g.jcarousel;f.fn=f.prototype={jcarousel:"0.2.8"};f.fn.extend=f.extend=g.extend;f.fn.extend({setup:function(){this.prevLast= this.prevFirst=this.last=this.first=null;this.animating=!1;this.tail=this.resizeTimer=this.timer=null;this.inTail=!1;if(!this.locked){this.list.css(this.lt,this.pos(this.options.offset)+"px");var a=this.pos(this.options.start,!0);this.prevFirst=this.prevLast=null;this.animate(a,!1);g(window).unbind("resize.jcarousel",this.funcResize).bind("resize.jcarousel",this.funcResize);this.options.setupCallback!==null&&this.options.setupCallback(this)}},reset:function(){this.list.empty();this.list.css(this.lt, "0px");this.list.css(this.wh,"10px");this.options.initCallback!==null&&this.options.initCallback(this,"reset");this.setup()},reload:function(){this.tail!==null&&this.inTail&&this.list.css(this.lt,f.intval(this.list.css(this.lt))+this.tail);this.tail=null;this.inTail=!1;this.options.reloadCallback!==null&&this.options.reloadCallback(this);if(this.options.visible!==null){var a=this,c=Math.ceil(this.clipping()/this.options.visible),b=0,d=0;this.list.children("li").each(function(f){b+=a.dimension(this, c);f+1<a.first&&(d=b)});this.list.css(this.wh,b+"px");this.list.css(this.lt,-d+"px")}this.scroll(this.first,!1)},lock:function(){this.locked=!0;this.buttons()},unlock:function(){this.locked=!1;this.buttons()},size:function(a){if(a!==void 0)this.options.size=a,this.locked||this.buttons();return this.options.size},has:function(a,c){if(c===void 0||!c)c=a;if(this.options.size!==null&&c>this.options.size)c=this.options.size;for(var b=a;b<=c;b++){var d=this.get(b);if(!d.length||d.hasClass("jcarousel-item-placeholder"))return!1}return!0}, get:function(a){return g(">.jcarousel-item-"+a,this.list)},add:function(a,c){var b=this.get(a),d=0,p=g(c);if(b.length===0)for(var j,e=f.intval(a),b=this.create(a);;){if(j=this.get(--e),e<=0||j.length){e<=0?this.list.prepend(b):j.after(b);break}}else d=this.dimension(b);p.get(0).nodeName.toUpperCase()=="LI"?(b.replaceWith(p),b=p):b.empty().append(c);this.format(b.removeClass(this.className("jcarousel-item-placeholder")),a);p=this.options.visible!==null?Math.ceil(this.clipping()/this.options.visible): null;d=this.dimension(b,p)-d;a>0&&a<this.first&&this.list.css(this.lt,f.intval(this.list.css(this.lt))-d+"px");this.list.css(this.wh,f.intval(this.list.css(this.wh))+d+"px");return b},remove:function(a){var c=this.get(a);if(c.length&&!(a>=this.first&&a<=this.last)){var b=this.dimension(c);a<this.first&&this.list.css(this.lt,f.intval(this.list.css(this.lt))+b+"px");c.remove();this.list.css(this.wh,f.intval(this.list.css(this.wh))-b+"px")}},next:function(){this.tail!==null&&!this.inTail?this.scrollTail(!1): this.scroll((this.options.wrap=="both"||this.options.wrap=="last")&&this.options.size!==null&&this.last==this.options.size?1:this.first+this.options.scroll)},prev:function(){this.tail!==null&&this.inTail?this.scrollTail(!0):this.scroll((this.options.wrap=="both"||this.options.wrap=="first")&&this.options.size!==null&&this.first==1?this.options.size:this.first-this.options.scroll)},scrollTail:function(a){if(!this.locked&&!this.animating&&this.tail){this.pauseAuto();var c=f.intval(this.list.css(this.lt)), c=!a?c-this.tail:c+this.tail;this.inTail=!a;this.prevFirst=this.first;this.prevLast=this.last;this.animate(c)}},scroll:function(a,c){!this.locked&&!this.animating&&(this.pauseAuto(),this.animate(this.pos(a),c))},pos:function(a,c){var b=f.intval(this.list.css(this.lt));if(this.locked||this.animating)return b;this.options.wrap!="circular"&&(a=a<1?1:this.options.size&&a>this.options.size?this.options.size:a);for(var d=this.first>a,g=this.options.wrap!="circular"&&this.first<=1?1:this.first,j=d?this.get(g): this.get(this.last),e=d?g:g-1,h=null,i=0,k=!1,l=0;d?--e>=a:++e<a;){h=this.get(e);k=!h.length;if(h.length===0&&(h=this.create(e).addClass(this.className("jcarousel-item-placeholder")),j[d?"before":"after"](h),this.first!==null&&this.options.wrap=="circular"&&this.options.size!==null&&(e<=0||e>this.options.size)))j=this.get(this.index(e)),j.length&&(h=this.add(e,j.clone(!0)));j=h;l=this.dimension(h);k&&(i+=l);if(this.first!==null&&(this.options.wrap=="circular"||e>=1&&(this.options.size===null||e<= this.options.size)))b=d?b+l:b-l}for(var g=this.clipping(),m=[],o=0,n=0,j=this.get(a-1),e=a;++o;){h=this.get(e);k=!h.length;if(h.length===0){h=this.create(e).addClass(this.className("jcarousel-item-placeholder"));if(j.length===0)this.list.prepend(h);else j[d?"before":"after"](h);if(this.first!==null&&this.options.wrap=="circular"&&this.options.size!==null&&(e<=0||e>this.options.size))j=this.get(this.index(e)),j.length&&(h=this.add(e,j.clone(!0)))}j=h;l=this.dimension(h);if(l===0)throw Error("jCarousel: No width/height set for items. This will cause an infinite loop. Aborting..."); this.options.wrap!="circular"&&this.options.size!==null&&e>this.options.size?m.push(h):k&&(i+=l);n+=l;if(n>=g)break;e++}for(h=0;h<m.length;h++)m[h].remove();i>0&&(this.list.css(this.wh,this.dimension(this.list)+i+"px"),d&&(b-=i,this.list.css(this.lt,f.intval(this.list.css(this.lt))-i+"px")));i=a+o-1;if(this.options.wrap!="circular"&&this.options.size&&i>this.options.size)i=this.options.size;if(e>i){o=0;e=i;for(n=0;++o;){h=this.get(e--);if(!h.length)break;n+=this.dimension(h);if(n>=g)break}}e=i-o+ 1;this.options.wrap!="circular"&&e<1&&(e=1);if(this.inTail&&d)b+=this.tail,this.inTail=!1;this.tail=null;if(this.options.wrap!="circular"&&i==this.options.size&&i-o+1>=1&&(d=f.intval(this.get(i).css(!this.options.vertical?"marginRight":"marginBottom")),n-d>g))this.tail=n-g-d;if(c&&a===this.options.size&&this.tail)b-=this.tail,this.inTail=!0;for(;a-- >e;)b+=this.dimension(this.get(a));this.prevFirst=this.first;this.prevLast=this.last;this.first=e;this.last=i;return b},animate:function(a,c){if(!this.locked&& !this.animating){this.animating=!0;var b=this,d=function(){b.animating=!1;a===0&&b.list.css(b.lt,0);!b.autoStopped&&(b.options.wrap=="circular"||b.options.wrap=="both"||b.options.wrap=="last"||b.options.size===null||b.last<b.options.size||b.last==b.options.size&&b.tail!==null&&!b.inTail)&&b.startAuto();b.buttons();b.notify("onAfterAnimation");if(b.options.wrap=="circular"&&b.options.size!==null)for(var c=b.prevFirst;c<=b.prevLast;c++)c!==null&&!(c>=b.first&&c<=b.last)&&(c<1||c>b.options.size)&&b.remove(c)}; this.notify("onBeforeAnimation");if(!this.options.animation||c===!1)this.list.css(this.lt,a+"px"),d();else{var f=!this.options.vertical?this.options.rtl?{right:a}:{left:a}:{top:a},d={duration:this.options.animation,easing:this.options.easing,complete:d};if(g.isFunction(this.options.animationStepCallback))d.step=this.options.animationStepCallback;this.list.animate(f,d)}}},startAuto:function(a){if(a!==void 0)this.options.auto=a;if(this.options.auto===0)return this.stopAuto();if(this.timer===null){this.autoStopped= !1;var c=this;this.timer=window.setTimeout(function(){c.next()},this.options.auto*1E3)}},stopAuto:function(){this.pauseAuto();this.autoStopped=!0},pauseAuto:function(){if(this.timer!==null)window.clearTimeout(this.timer),this.timer=null},buttons:function(a,c){if(a==null&&(a=!this.locked&&this.options.size!==0&&(this.options.wrap&&this.options.wrap!="first"||this.options.size===null||this.last<this.options.size),!this.locked&&(!this.options.wrap||this.options.wrap=="first")&&this.options.size!==null&& this.last>=this.options.size))a=this.tail!==null&&!this.inTail;if(c==null&&(c=!this.locked&&this.options.size!==0&&(this.options.wrap&&this.options.wrap!="last"||this.first>1),!this.locked&&(!this.options.wrap||this.options.wrap=="last")&&this.options.size!==null&&this.first==1))c=this.tail!==null&&this.inTail;var b=this;this.buttonNext.size()>0?(this.buttonNext.unbind(this.options.buttonNextEvent+".jcarousel",this.funcNext),a&&this.buttonNext.bind(this.options.buttonNextEvent+".jcarousel",this.funcNext), this.buttonNext[a?"removeClass":"addClass"](this.className("jcarousel-next-disabled")).attr("disabled",a?!1:!0),this.options.buttonNextCallback!==null&&this.buttonNext.data("jcarouselstate")!=a&&this.buttonNext.each(function(){b.options.buttonNextCallback(b,this,a)}).data("jcarouselstate",a)):this.options.buttonNextCallback!==null&&this.buttonNextState!=a&&this.options.buttonNextCallback(b,null,a);this.buttonPrev.size()>0?(this.buttonPrev.unbind(this.options.buttonPrevEvent+".jcarousel",this.funcPrev), c&&this.buttonPrev.bind(this.options.buttonPrevEvent+".jcarousel",this.funcPrev),this.buttonPrev[c?"removeClass":"addClass"](this.className("jcarousel-prev-disabled")).attr("disabled",c?!1:!0),this.options.buttonPrevCallback!==null&&this.buttonPrev.data("jcarouselstate")!=c&&this.buttonPrev.each(function(){b.options.buttonPrevCallback(b,this,c)}).data("jcarouselstate",c)):this.options.buttonPrevCallback!==null&&this.buttonPrevState!=c&&this.options.buttonPrevCallback(b,null,c);this.buttonNextState= a;this.buttonPrevState=c},notify:function(a){var c=this.prevFirst===null?"init":this.prevFirst<this.first?"next":"prev";this.callback("itemLoadCallback",a,c);this.prevFirst!==this.first&&(this.callback("itemFirstInCallback",a,c,this.first),this.callback("itemFirstOutCallback",a,c,this.prevFirst));this.prevLast!==this.last&&(this.callback("itemLastInCallback",a,c,this.last),this.callback("itemLastOutCallback",a,c,this.prevLast));this.callback("itemVisibleInCallback",a,c,this.first,this.last,this.prevFirst, this.prevLast);this.callback("itemVisibleOutCallback",a,c,this.prevFirst,this.prevLast,this.first,this.last)},callback:function(a,c,b,d,f,j,e){if(!(this.options[a]==null||typeof this.options[a]!="object"&&c!="onAfterAnimation")){var h=typeof this.options[a]=="object"?this.options[a][c]:this.options[a];if(g.isFunction(h)){var i=this;if(d===void 0)h(i,b,c);else if(f===void 0)this.get(d).each(function(){h(i,this,d,b,c)});else for(var a=function(a){i.get(a).each(function(){h(i,this,a,b,c)})},k=d;k<=f;k++)k!== null&&!(k>=j&&k<=e)&&a(k)}}},create:function(a){return this.format("<li></li>",a)},format:function(a,c){for(var a=g(a),b=a.get(0).className.split(" "),d=0;d<b.length;d++)b[d].indexOf("jcarousel-")!=-1&&a.removeClass(b[d]);a.addClass(this.className("jcarousel-item")).addClass(this.className("jcarousel-item-"+c)).css({"float":this.options.rtl?"right":"left","list-style":"none"}).attr("jcarouselindex",c);return a},className:function(a){return a+" "+a+(!this.options.vertical?"-horizontal":"-vertical")}, dimension:function(a,c){var b=g(a);if(c==null)return!this.options.vertical?b.outerWidth(!0)||f.intval(this.options.itemFallbackDimension):b.outerHeight(!0)||f.intval(this.options.itemFallbackDimension);else{var d=!this.options.vertical?c-f.intval(b.css("marginLeft"))-f.intval(b.css("marginRight")):c-f.intval(b.css("marginTop"))-f.intval(b.css("marginBottom"));g(b).css(this.wh,d+"px");return this.dimension(b)}},clipping:function(){return!this.options.vertical?this.clip[0].offsetWidth-f.intval(this.clip.css("borderLeftWidth"))- f.intval(this.clip.css("borderRightWidth")):this.clip[0].offsetHeight-f.intval(this.clip.css("borderTopWidth"))-f.intval(this.clip.css("borderBottomWidth"))},index:function(a,c){if(c==null)c=this.options.size;return Math.round(((a-1)/c-Math.floor((a-1)/c))*c)+1}});f.extend({defaults:function(a){return g.extend(q,a||{})},intval:function(a){a=parseInt(a,10);return isNaN(a)?0:a},windowLoaded:function(){m=!0}});g.fn.jcarousel=function(a){if(typeof a=="string"){var c=g(this).data("jcarousel"),b=Array.prototype.slice.call(arguments, 1);return c[a].apply(c,b)}else return this.each(function(){var b=g(this).data("jcarousel");b?(a&&g.extend(b.options,a),b.reload()):g(this).data("jcarousel",new f(this,a))})}})(jQuery);
/* Modernizr 2.8.3 (Custom Build) | MIT & BSD
 * Build: http://modernizr.com/download/#-fontface-backgroundsize-borderimage-borderradius-boxshadow-flexbox-hsla-multiplebgs-opacity-rgba-textshadow-cssanimations-csscolumns-generatedcontent-cssgradients-cssreflections-csstransforms-csstransforms3d-csstransitions-applicationcache-canvas-canvastext-draganddrop-hashchange-history-audio-video-indexeddb-input-inputtypes-localstorage-postmessage-sessionstorage-websockets-websqldatabase-webworkers-geolocation-inlinesvg-smil-svg-svgclippaths-touch-webgl-shiv-cssclasses-addtest-prefixed-teststyles-testprop-testallprops-hasevent-prefixes-domprefixes-load
 */

;window.Modernizr=function(a,b,c){function C(a){j.cssText=a}function D(a,b){return C(n.join(a+";")+(b||""))}function E(a,b){return typeof a===b}function F(a,b){return!!~(""+a).indexOf(b)}function G(a,b){for(var d in a){var e=a[d];if(!F(e,"-")&&j[e]!==c)return b=="pfx"?e:!0}return!1}function H(a,b,d){for(var e in a){var f=b[a[e]];if(f!==c)return d===!1?a[e]:E(f,"function")?f.bind(d||b):f}return!1}function I(a,b,c){var d=a.charAt(0).toUpperCase()+a.slice(1),e=(a+" "+p.join(d+" ")+d).split(" ");return E(b,"string")||E(b,"undefined")?G(e,b):(e=(a+" "+q.join(d+" ")+d).split(" "),H(e,b,c))}function J(){e.input=function(c){for(var d=0,e=c.length;d<e;d++)u[c[d]]=c[d]in k;return u.list&&(u.list=!!b.createElement("datalist")&&!!a.HTMLDataListElement),u}("autocomplete autofocus list placeholder max min multiple pattern required step".split(" ")),e.inputtypes=function(a){for(var d=0,e,f,h,i=a.length;d<i;d++)k.setAttribute("type",f=a[d]),e=k.type!=="text",e&&(k.value=l,k.style.cssText="position:absolute;visibility:hidden;",/^range$/.test(f)&&k.style.WebkitAppearance!==c?(g.appendChild(k),h=b.defaultView,e=h.getComputedStyle&&h.getComputedStyle(k,null).WebkitAppearance!=="textfield"&&k.offsetHeight!==0,g.removeChild(k)):/^(search|tel)$/.test(f)||(/^(url|email)$/.test(f)?e=k.checkValidity&&k.checkValidity()===!1:e=k.value!=l)),t[a[d]]=!!e;return t}("search tel url email datetime date month week time datetime-local number range color".split(" "))}var d="2.8.3",e={},f=!0,g=b.documentElement,h="modernizr",i=b.createElement(h),j=i.style,k=b.createElement("input"),l=":)",m={}.toString,n=" -webkit- -moz- -o- -ms- ".split(" "),o="Webkit Moz O ms",p=o.split(" "),q=o.toLowerCase().split(" "),r={svg:"http://www.w3.org/2000/svg"},s={},t={},u={},v=[],w=v.slice,x,y=function(a,c,d,e){var f,i,j,k,l=b.createElement("div"),m=b.body,n=m||b.createElement("body");if(parseInt(d,10))while(d--)j=b.createElement("div"),j.id=e?e[d]:h+(d+1),l.appendChild(j);return f=["&#173;",'<style id="s',h,'">',a,"</style>"].join(""),l.id=h,(m?l:n).innerHTML+=f,n.appendChild(l),m||(n.style.background="",n.style.overflow="hidden",k=g.style.overflow,g.style.overflow="hidden",g.appendChild(n)),i=c(l,a),m?l.parentNode.removeChild(l):(n.parentNode.removeChild(n),g.style.overflow=k),!!i},z=function(){function d(d,e){e=e||b.createElement(a[d]||"div"),d="on"+d;var f=d in e;return f||(e.setAttribute||(e=b.createElement("div")),e.setAttribute&&e.removeAttribute&&(e.setAttribute(d,""),f=E(e[d],"function"),E(e[d],"undefined")||(e[d]=c),e.removeAttribute(d))),e=null,f}var a={select:"input",change:"input",submit:"form",reset:"form",error:"img",load:"img",abort:"img"};return d}(),A={}.hasOwnProperty,B;!E(A,"undefined")&&!E(A.call,"undefined")?B=function(a,b){return A.call(a,b)}:B=function(a,b){return b in a&&E(a.constructor.prototype[b],"undefined")},Function.prototype.bind||(Function.prototype.bind=function(b){var c=this;if(typeof c!="function")throw new TypeError;var d=w.call(arguments,1),e=function(){if(this instanceof e){var a=function(){};a.prototype=c.prototype;var f=new a,g=c.apply(f,d.concat(w.call(arguments)));return Object(g)===g?g:f}return c.apply(b,d.concat(w.call(arguments)))};return e}),s.flexbox=function(){return I("flexWrap")},s.canvas=function(){var a=b.createElement("canvas");return!!a.getContext&&!!a.getContext("2d")},s.canvastext=function(){return!!e.canvas&&!!E(b.createElement("canvas").getContext("2d").fillText,"function")},s.webgl=function(){return!!a.WebGLRenderingContext},s.touch=function(){var c;return"ontouchstart"in a||a.DocumentTouch&&b instanceof DocumentTouch?c=!0:y(["@media (",n.join("touch-enabled),("),h,")","{#modernizr{top:9px;position:absolute}}"].join(""),function(a){c=a.offsetTop===9}),c},s.geolocation=function(){return"geolocation"in navigator},s.postmessage=function(){return!!a.postMessage},s.websqldatabase=function(){return!!a.openDatabase},s.indexedDB=function(){return!!I("indexedDB",a)},s.hashchange=function(){return z("hashchange",a)&&(b.documentMode===c||b.documentMode>7)},s.history=function(){return!!a.history&&!!history.pushState},s.draganddrop=function(){var a=b.createElement("div");return"draggable"in a||"ondragstart"in a&&"ondrop"in a},s.websockets=function(){return"WebSocket"in a||"MozWebSocket"in a},s.rgba=function(){return C("background-color:rgba(150,255,150,.5)"),F(j.backgroundColor,"rgba")},s.hsla=function(){return C("background-color:hsla(120,40%,100%,.5)"),F(j.backgroundColor,"rgba")||F(j.backgroundColor,"hsla")},s.multiplebgs=function(){return C("background:url(https://),url(https://),red url(https://)"),/(url\s*\(.*?){3}/.test(j.background)},s.backgroundsize=function(){return I("backgroundSize")},s.borderimage=function(){return I("borderImage")},s.borderradius=function(){return I("borderRadius")},s.boxshadow=function(){return I("boxShadow")},s.textshadow=function(){return b.createElement("div").style.textShadow===""},s.opacity=function(){return D("opacity:.55"),/^0.55$/.test(j.opacity)},s.cssanimations=function(){return I("animationName")},s.csscolumns=function(){return I("columnCount")},s.cssgradients=function(){var a="background-image:",b="gradient(linear,left top,right bottom,from(#9f9),to(white));",c="linear-gradient(left top,#9f9, white);";return C((a+"-webkit- ".split(" ").join(b+a)+n.join(c+a)).slice(0,-a.length)),F(j.backgroundImage,"gradient")},s.cssreflections=function(){return I("boxReflect")},s.csstransforms=function(){return!!I("transform")},s.csstransforms3d=function(){var a=!!I("perspective");return a&&"webkitPerspective"in g.style&&y("@media (transform-3d),(-webkit-transform-3d){#modernizr{left:9px;position:absolute;height:3px;}}",function(b,c){a=b.offsetLeft===9&&b.offsetHeight===3}),a},s.csstransitions=function(){return I("transition")},s.fontface=function(){var a;return y('@font-face {font-family:"font";src:url("https://")}',function(c,d){var e=b.getElementById("smodernizr"),f=e.sheet||e.styleSheet,g=f?f.cssRules&&f.cssRules[0]?f.cssRules[0].cssText:f.cssText||"":"";a=/src/i.test(g)&&g.indexOf(d.split(" ")[0])===0}),a},s.generatedcontent=function(){var a;return y(["#",h,"{font:0/0 a}#",h,':after{content:"',l,'";visibility:hidden;font:3px/1 a}'].join(""),function(b){a=b.offsetHeight>=3}),a},s.video=function(){var a=b.createElement("video"),c=!1;try{if(c=!!a.canPlayType)c=new Boolean(c),c.ogg=a.canPlayType('video/ogg; codecs="theora"').replace(/^no$/,""),c.h264=a.canPlayType('video/mp4; codecs="avc1.42E01E"').replace(/^no$/,""),c.webm=a.canPlayType('video/webm; codecs="vp8, vorbis"').replace(/^no$/,"")}catch(d){}return c},s.audio=function(){var a=b.createElement("audio"),c=!1;try{if(c=!!a.canPlayType)c=new Boolean(c),c.ogg=a.canPlayType('audio/ogg; codecs="vorbis"').replace(/^no$/,""),c.mp3=a.canPlayType("audio/mpeg;").replace(/^no$/,""),c.wav=a.canPlayType('audio/wav; codecs="1"').replace(/^no$/,""),c.m4a=(a.canPlayType("audio/x-m4a;")||a.canPlayType("audio/aac;")).replace(/^no$/,"")}catch(d){}return c},s.localstorage=function(){try{return localStorage.setItem(h,h),localStorage.removeItem(h),!0}catch(a){return!1}},s.sessionstorage=function(){try{return sessionStorage.setItem(h,h),sessionStorage.removeItem(h),!0}catch(a){return!1}},s.webworkers=function(){return!!a.Worker},s.applicationcache=function(){return!!a.applicationCache},s.svg=function(){return!!b.createElementNS&&!!b.createElementNS(r.svg,"svg").createSVGRect},s.inlinesvg=function(){var a=b.createElement("div");return a.innerHTML="<svg/>",(a.firstChild&&a.firstChild.namespaceURI)==r.svg},s.smil=function(){return!!b.createElementNS&&/SVGAnimate/.test(m.call(b.createElementNS(r.svg,"animate")))},s.svgclippaths=function(){return!!b.createElementNS&&/SVGClipPath/.test(m.call(b.createElementNS(r.svg,"clipPath")))};for(var K in s)B(s,K)&&(x=K.toLowerCase(),e[x]=s[K](),v.push((e[x]?"":"no-")+x));return e.input||J(),e.addTest=function(a,b){if(typeof a=="object")for(var d in a)B(a,d)&&e.addTest(d,a[d]);else{a=a.toLowerCase();if(e[a]!==c)return e;b=typeof b=="function"?b():b,typeof f!="undefined"&&f&&(g.className+=" "+(b?"":"no-")+a),e[a]=b}return e},C(""),i=k=null,function(a,b){function l(a,b){var c=a.createElement("p"),d=a.getElementsByTagName("head")[0]||a.documentElement;return c.innerHTML="x<style>"+b+"</style>",d.insertBefore(c.lastChild,d.firstChild)}function m(){var a=s.elements;return typeof a=="string"?a.split(" "):a}function n(a){var b=j[a[h]];return b||(b={},i++,a[h]=i,j[i]=b),b}function o(a,c,d){c||(c=b);if(k)return c.createElement(a);d||(d=n(c));var g;return d.cache[a]?g=d.cache[a].cloneNode():f.test(a)?g=(d.cache[a]=d.createElem(a)).cloneNode():g=d.createElem(a),g.canHaveChildren&&!e.test(a)&&!g.tagUrn?d.frag.appendChild(g):g}function p(a,c){a||(a=b);if(k)return a.createDocumentFragment();c=c||n(a);var d=c.frag.cloneNode(),e=0,f=m(),g=f.length;for(;e<g;e++)d.createElement(f[e]);return d}function q(a,b){b.cache||(b.cache={},b.createElem=a.createElement,b.createFrag=a.createDocumentFragment,b.frag=b.createFrag()),a.createElement=function(c){return s.shivMethods?o(c,a,b):b.createElem(c)},a.createDocumentFragment=Function("h,f","return function(){var n=f.cloneNode(),c=n.createElement;h.shivMethods&&("+m().join().replace(/[\w\-]+/g,function(a){return b.createElem(a),b.frag.createElement(a),'c("'+a+'")'})+");return n}")(s,b.frag)}function r(a){a||(a=b);var c=n(a);return s.shivCSS&&!g&&!c.hasCSS&&(c.hasCSS=!!l(a,"article,aside,dialog,figcaption,figure,footer,header,hgroup,main,nav,section{display:block}mark{background:#FF0;color:#000}template{display:none}")),k||q(a,c),a}var c="3.7.0",d=a.html5||{},e=/^<|^(?:button|map|select|textarea|object|iframe|option|optgroup)$/i,f=/^(?:a|b|code|div|fieldset|h1|h2|h3|h4|h5|h6|i|label|li|ol|p|q|span|strong|style|table|tbody|td|th|tr|ul)$/i,g,h="_html5shiv",i=0,j={},k;(function(){try{var a=b.createElement("a");a.innerHTML="<xyz></xyz>",g="hidden"in a,k=a.childNodes.length==1||function(){b.createElement("a");var a=b.createDocumentFragment();return typeof a.cloneNode=="undefined"||typeof a.createDocumentFragment=="undefined"||typeof a.createElement=="undefined"}()}catch(c){g=!0,k=!0}})();var s={elements:d.elements||"abbr article aside audio bdi canvas data datalist details dialog figcaption figure footer header hgroup main mark meter nav output progress section summary template time video",version:c,shivCSS:d.shivCSS!==!1,supportsUnknownElements:k,shivMethods:d.shivMethods!==!1,type:"default",shivDocument:r,createElement:o,createDocumentFragment:p};a.html5=s,r(b)}(this,b),e._version=d,e._prefixes=n,e._domPrefixes=q,e._cssomPrefixes=p,e.hasEvent=z,e.testProp=function(a){return G([a])},e.testAllProps=I,e.testStyles=y,e.prefixed=function(a,b,c){return b?I(a,b,c):I(a,"pfx")},g.className=g.className.replace(/(^|\s)no-js(\s|$)/,"$1$2")+(f?" js "+v.join(" "):""),e}(this,this.document),function(a,b,c){function d(a){return"[object Function]"==o.call(a)}function e(a){return"string"==typeof a}function f(){}function g(a){return!a||"loaded"==a||"complete"==a||"uninitialized"==a}function h(){var a=p.shift();q=1,a?a.t?m(function(){("c"==a.t?B.injectCss:B.injectJs)(a.s,0,a.a,a.x,a.e,1)},0):(a(),h()):q=0}function i(a,c,d,e,f,i,j){function k(b){if(!o&&g(l.readyState)&&(u.r=o=1,!q&&h(),l.onload=l.onreadystatechange=null,b)){"img"!=a&&m(function(){t.removeChild(l)},50);for(var d in y[c])y[c].hasOwnProperty(d)&&y[c][d].onload()}}var j=j||B.errorTimeout,l=b.createElement(a),o=0,r=0,u={t:d,s:c,e:f,a:i,x:j};1===y[c]&&(r=1,y[c]=[]),"object"==a?l.data=c:(l.src=c,l.type=a),l.width=l.height="0",l.onerror=l.onload=l.onreadystatechange=function(){k.call(this,r)},p.splice(e,0,u),"img"!=a&&(r||2===y[c]?(t.insertBefore(l,s?null:n),m(k,j)):y[c].push(l))}function j(a,b,c,d,f){return q=0,b=b||"j",e(a)?i("c"==b?v:u,a,b,this.i++,c,d,f):(p.splice(this.i++,0,a),1==p.length&&h()),this}function k(){var a=B;return a.loader={load:j,i:0},a}var l=b.documentElement,m=a.setTimeout,n=b.getElementsByTagName("script")[0],o={}.toString,p=[],q=0,r="MozAppearance"in l.style,s=r&&!!b.createRange().compareNode,t=s?l:n.parentNode,l=a.opera&&"[object Opera]"==o.call(a.opera),l=!!b.attachEvent&&!l,u=r?"object":l?"script":"img",v=l?"script":u,w=Array.isArray||function(a){return"[object Array]"==o.call(a)},x=[],y={},z={timeout:function(a,b){return b.length&&(a.timeout=b[0]),a}},A,B;B=function(a){function b(a){var a=a.split("!"),b=x.length,c=a.pop(),d=a.length,c={url:c,origUrl:c,prefixes:a},e,f,g;for(f=0;f<d;f++)g=a[f].split("="),(e=z[g.shift()])&&(c=e(c,g));for(f=0;f<b;f++)c=x[f](c);return c}function g(a,e,f,g,h){var i=b(a),j=i.autoCallback;i.url.split(".").pop().split("?").shift(),i.bypass||(e&&(e=d(e)?e:e[a]||e[g]||e[a.split("/").pop().split("?")[0]]),i.instead?i.instead(a,e,f,g,h):(y[i.url]?i.noexec=!0:y[i.url]=1,f.load(i.url,i.forceCSS||!i.forceJS&&"css"==i.url.split(".").pop().split("?").shift()?"c":c,i.noexec,i.attrs,i.timeout),(d(e)||d(j))&&f.load(function(){k(),e&&e(i.origUrl,h,g),j&&j(i.origUrl,h,g),y[i.url]=2})))}function h(a,b){function c(a,c){if(a){if(e(a))c||(j=function(){var a=[].slice.call(arguments);k.apply(this,a),l()}),g(a,j,b,0,h);else if(Object(a)===a)for(n in m=function(){var b=0,c;for(c in a)a.hasOwnProperty(c)&&b++;return b}(),a)a.hasOwnProperty(n)&&(!c&&!--m&&(d(j)?j=function(){var a=[].slice.call(arguments);k.apply(this,a),l()}:j[n]=function(a){return function(){var b=[].slice.call(arguments);a&&a.apply(this,b),l()}}(k[n])),g(a[n],j,b,n,h))}else!c&&l()}var h=!!a.test,i=a.load||a.both,j=a.callback||f,k=j,l=a.complete||f,m,n;c(h?a.yep:a.nope,!!i),i&&c(i)}var i,j,l=this.yepnope.loader;if(e(a))g(a,0,l,0);else if(w(a))for(i=0;i<a.length;i++)j=a[i],e(j)?g(j,0,l,0):w(j)?B(j):Object(j)===j&&h(j,l);else Object(a)===a&&h(a,l)},B.addPrefix=function(a,b){z[a]=b},B.addFilter=function(a){x.push(a)},B.errorTimeout=1e4,null==b.readyState&&b.addEventListener&&(b.readyState="loading",b.addEventListener("DOMContentLoaded",A=function(){b.removeEventListener("DOMContentLoaded",A,0),b.readyState="complete"},0)),a.yepnope=k(),a.yepnope.executeStack=h,a.yepnope.injectJs=function(a,c,d,e,i,j){var k=b.createElement("script"),l,o,e=e||B.errorTimeout;k.src=a;for(o in d)k.setAttribute(o,d[o]);c=j?h:c||f,k.onreadystatechange=k.onload=function(){!l&&g(k.readyState)&&(l=1,c(),k.onload=k.onreadystatechange=null)},m(function(){l||(l=1,c(1))},e),i?k.onload():n.parentNode.insertBefore(k,n)},a.yepnope.injectCss=function(a,c,d,e,g,i){var e=b.createElement("link"),j,c=i?h:c||f;e.href=a,e.rel="stylesheet",e.type="text/css";for(j in d)e.setAttribute(j,d[j]);g||(n.parentNode.insertBefore(e,n),m(c,0))}}(this,document),Modernizr.load=function(){yepnope.apply(window,[].slice.call(arguments,0))};
jQuery(document).ready(function($){
	var $slidesWrapper = $('.cd-hero-slider');

	//check if a .cd-hero-slider exists in the DOM 
	if ( $slidesWrapper.length > 0 ) {
		var $primaryNav = $('.cd-primary-nav'),
			$sliderNav = $('.cd-slider-nav'),
			$navigationMarker = $('.cd-marker'),
			$prevSlideButton = $('.cd-arrow-left'),
			$nextSlideButton = $('.cd-arrow-right'),
			slidesNumber = $slidesWrapper.children('li').length,
			visibleSlidePosition = 0,
			autoPlayId,
			autoPlayDelay = 10000;


		if(slidesNumber <= 1){
			$prevSlideButton.css('display', 'none');
			$nextSlideButton.css('display', 'none');
			$sliderNav.css('display', 'none');
		}

		//upload videos (if not on mobile devices)
		uploadVideo($slidesWrapper);

		//autoplay slider
		setAutoplay($slidesWrapper, slidesNumber, autoPlayDelay);

		//on mobile - open/close primary navigation clicking/tapping the menu icon
		$primaryNav.on('click', function(event){
			if($(event.target).is('.cd-primary-nav')) $(this).children('ul').toggleClass('is-visible');
		});
		
		//change visible slide
		$prevSlideButton.on('click', function(event){
			event.preventDefault();
			var activePosition = $slidesWrapper.find('li.selected').index();
			var selectedPosition = (activePosition == 0) ? slidesNumber - 1 : activePosition - 1;

			slideSelection(activePosition, selectedPosition);
			resetAutoplay(selectedPosition);
		});

		$nextSlideButton.on('click', function(event){
			event.preventDefault();
			var activePosition = $slidesWrapper.find('li.selected').index();
			var selectedPosition = (activePosition + 1) == slidesNumber ? 0 : activePosition + 1;

			slideSelection(activePosition, selectedPosition);
			resetAutoplay(selectedPosition);
		});

		$sliderNav.on('click', 'li', function(event){
			event.preventDefault();
			var selectedItem = $(this);
			if(!selectedItem.hasClass('selected')) {
				// if it's not already selected
				var selectedPosition = selectedItem.index(),
					activePosition = $slidesWrapper.find('li.selected').index();			

				slideSelection(activePosition, selectedPosition);
				resetAutoplay(selectedPosition);
			}
		});
	}

	function slideSelection(active, selected){
		if(active < selected) {
			nextSlide($slidesWrapper.find('.selected'), $slidesWrapper, $sliderNav, selected);
		} else {
			prevSlide($slidesWrapper.find('.selected'), $slidesWrapper, $sliderNav, selected);
		}
	}

	function resetAutoplay(selected){
		//this is used for the autoplay
		visibleSlidePosition = selected;

		updateSliderNavigation($sliderNav, selected);
		updateNavigationMarker($navigationMarker, selected+1);

		//reset autoplay
		setAutoplay($slidesWrapper, slidesNumber, autoPlayDelay);
	}

	function nextSlide(visibleSlide, container, pagination, n){
		visibleSlide.removeClass('selected from-left from-right').addClass('is-moving').one('webkitTransitionEnd otransitionend oTransitionEnd msTransitionEnd transitionend', function(){
			visibleSlide.removeClass('is-moving');
		});

		container.children('li').eq(n).addClass('selected from-right').prevAll().addClass('move-left');
		checkVideo(visibleSlide, container, n);
	}

	function prevSlide(visibleSlide, container, pagination, n){
		visibleSlide.removeClass('selected from-left from-right').addClass('is-moving').one('webkitTransitionEnd otransitionend oTransitionEnd msTransitionEnd transitionend', function(){
			visibleSlide.removeClass('is-moving');
		});

		container.children('li').eq(n).addClass('selected from-left').removeClass('move-left').nextAll().removeClass('move-left');
		checkVideo(visibleSlide, container, n);
	}

	function updateSliderNavigation(pagination, n) {
		var navigationDot = pagination.find('.selected');
		navigationDot.removeClass('selected');
		pagination.find('li').eq(n).addClass('selected');
	}

	function setAutoplay(wrapper, length, delay) {
		if(wrapper.hasClass('autoplay')) {
			clearInterval(autoPlayId);
			autoPlayId = window.setInterval(function(){autoplaySlider(length)}, delay);
		}
	}

	function autoplaySlider(length) {
		if( visibleSlidePosition < length - 1) {
			nextSlide($slidesWrapper.find('.selected'), $slidesWrapper, $sliderNav, visibleSlidePosition + 1);
			visibleSlidePosition +=1;
		} else {
			prevSlide($slidesWrapper.find('.selected'), $slidesWrapper, $sliderNav, 0);
			visibleSlidePosition = 0;
		}
		updateNavigationMarker($navigationMarker, visibleSlidePosition+1);
		updateSliderNavigation($sliderNav, visibleSlidePosition);
	}

	function uploadVideo(container) {
		container.find('.cd-bg-video-wrapper').each(function(){
			var videoWrapper = $(this);
			if( videoWrapper.is(':visible') ) {
				// if visible - we are not on a mobile device 
				var	videoUrl = videoWrapper.data('video'),
					video = $('<video loop><source src="'+videoUrl+'.mp4" type="video/mp4" /><source src="'+videoUrl+'.webm" type="video/webm" /></video>');
				video.appendTo(videoWrapper);
				// play video if first slide
				if(videoWrapper.parent('.cd-bg-video.selected').length > 0) video.get(0).play();
			}
		});
	}

	function checkVideo(hiddenSlide, container, n) {
		//check if a video outside the viewport is playing - if yes, pause it
		var hiddenVideo = hiddenSlide.find('video');
		if( hiddenVideo.length > 0 ) hiddenVideo.get(0).pause();

		//check if the select slide contains a video element - if yes, play the video
		var visibleVideo = container.children('li').eq(n).find('video');
		if( visibleVideo.length > 0 ) visibleVideo.get(0).play();
	}

	function updateNavigationMarker(marker, n) {
		marker.removeClassPrefix('item').addClass('item-'+n);
	}

	$.fn.removeClassPrefix = function(prefix) {
		//remove all classes starting with 'prefix'
	    this.each(function(i, el) {
	        var classes = el.className.split(" ").filter(function(c) {
	            return c.lastIndexOf(prefix, 0) !== 0;
	        });
	        el.className = $.trim(classes.join(" "));
	    });
	    return this;
	};
});
// Personalize 
var BREI=BREI||{};BREI.Personalization={config:{recentPagesLength:20,recentSearchesLength:20,favoritesLength:-1,trackCurrentPage:true,pagesKey:"BREI.RECENTP",searchesKey:"BREI.RECENTS",favoritesKey:"BREI.FAV",subjRem:""},init:function(a){var b=this.pushToRecentPages,c=window.location.href,d=document.title;if(typeof a!="undefined"){this.config=$.extend(this.config,a)}if(this.config.subjRem!=""){var e=new RegExp(this.config.subjRem);d=d.replace(e,"")}if(this.config.trackCurrentPage){b.call(this,c,d)}},gp:function(a,b,c,d){var e=b,f=e.length,g=0,h=false;if(e[0]!=null){for(;g<f;g+=1){if(e[g].url===a.url){h=true;break}}}if(!h){e.push(a)}if(c!=-1&&f+1>c){e.shift(1)}d.call(this,e)},gps:function(a,b,c,d){var e=b,f=e.length,g=0,h=false;if(e[0]==""){f=0}for(;g<f;g+=1){if(e[g]===a){h=true;break}}if(!h){e.push(a)}if(c!=-1&&f+1>c){e.shift(1)}d.call(this,e)},has:function(a){var b=this.getFavorites(),c=b.length,d=0,e=false;if(b[0]!=null){for(;d<c;d+=1){if(b[d].url===a){e=true}}}return e},pushToRecentPages:function(a,b){if(this.config.subjRem!=""){var c=new RegExp(this.config.subjRem);b=b.replace(c,"")}pitem={url:a,sub:b};this.gp(pitem,this.getRecentPages(),this.config.recentPagesLength,this.setRecentPages)},getRecentPages:function(){return amplify.store(this.config.pagesKey)||[]},setRecentPages:function(a){amplify.store(this.config.pagesKey,a)},pushToRecentSearches:function(a){this.gps(a,this.getRecentSearches(),this.config.recentSearchesLength,this.setRecentSearches)},getRecentSearches:function(){return amplify.store(this.config.searchesKey)||[]},setRecentSearches:function(a){amplify.store(this.config.searchesKey,a)},pushToFavorites:function(a,b){if(this.config.subjRem!=""){var c=new RegExp(this.config.subjRem);b=b.replace(c,"")}pitem={url:a,sub:b};this.gp(pitem,this.getFavorites(),this.config.favoritesLength,this.setFavorites)},removeFavorite:function(a){var b=this.getFavorites(),c=-1,d=b.length,e=0;for(;e<d;e+=1){if(a===b[e].url){c=e;break}}if(c!=-1){b.splice(e,e+1);this.setFavorites(b)}},getFavorites:function(){return amplify.store(this.config.favoritesKey)||[]},setFavorites:function(a){amplify.store(this.config.favoritesKey,a)}};
/*! Respond.js: min/max-width media query polyfill. (c) Scott Jehl. MIT Lic. j.mp/respondjs  */

(function (win, mqSupported) {
  //exposed namespace
  win.respond = {};

  //define update even in native-mq-supporting browsers, to avoid errors
  respond.update = function () { };

  //expose media query support flag for external use
  respond.mediaQueriesSupported = mqSupported;

  //if media queries are supported, exit here
  if (mqSupported) { return; }

  //define vars
  var doc = win.document,
        docElem = doc.documentElement,
        mediastyles = [],
        rules = [],
        currentIds = "",
        appendedEls = [],
        parsedSheets = {},
        resizeThrottle = 30,
        head = doc.getElementsByTagName("head")[0] || docElem,
        links = head.getElementsByTagName("link"),
        requestQueue = [],

  //loop stylesheets, send text content to translate
        ripCSS = function () {
            var sheets = links,
                sl = sheets.length,
                i = 0,
            //vars for loop:
                sheet, href, media, isCSS;

            for (; i < sl; i++) {
                sheet = sheets[i],
                href = sheet.href,
                media = sheet.media,
                isCSS = sheet.rel && sheet.rel.toLowerCase() === "stylesheet";

                //only links plz and prevent re-parsing
                if (!!href && isCSS && !parsedSheets[href]) {
                    if (!/^([a-zA-Z]+?:(\/\/)?)/.test(href)
                        || href.replace(RegExp.$1, "").split("/")[0] === win.location.host) {
                        requestQueue.push({
                            href: href,
                            media: media
                        });
                    }
                    else {
                        parsedSheets[href] = true;
                    }
                }
            }
            makeRequests();

        },

  //recurse through request queue, get css text
        makeRequests = function () {
            if (requestQueue.length) {
                var thisRequest = requestQueue.shift();

                ajax(thisRequest.href, function (styles) {
                    translate(styles, thisRequest.href, thisRequest.media);
                    parsedSheets[thisRequest.href] = true;
                    makeRequests();
                });
            }
        },

  //find media blocks in css text, convert to style blocks
        translate = function (styles, href, media) {
            var qs = styles.match(/@media[^\{]+\{([^\{\}]+\{[^\}\{]+\})+/gi),
                ql = qs && qs.length || 0,
            //try to get CSS path
                href = href.substring(0, href.lastIndexOf("/")),
                repUrls = function (css) {
                    return css.replace(/(url\()['"]?([^\/\)'"][^:\)'"]+)['"]?(\))/g, "$1" + href + "$2$3");
                },
                useMedia = !ql && media,
            //vars used in loop
                i = 0,
                j, fullq, thisq, eachq, eql;

            //if path exists, tack on trailing slash
            if (href.length) { href += "/"; }

            //if no internal queries exist, but media attr does, use that   
            //note: this currently lacks support for situations where a media attr is specified on a link AND
            //its associated stylesheet has internal CSS media queries.
            //In those cases, the media attribute will currently be ignored.
            if (useMedia) {
                ql = 1;
            }


            for (; i < ql; i++) {
                j = 0;

                //media attr
                if (useMedia) {
                    fullq = media;
                    rules.push(repUrls(styles));
                }
                //parse for styles
                else {
                    fullq = qs[i].match(/@media ([^\{]+)\{([\S\s]+?)$/) && RegExp.$1;
                    rules.push(RegExp.$2 && repUrls(RegExp.$2));
                }

                eachq = fullq.split(",");
                eql = eachq.length;


                for (; j < eql; j++) {
                    thisq = eachq[j];
                    mediastyles.push({
                        media: thisq.match(/(only\s+)?([a-zA-Z]+)(\sand)?/) && RegExp.$2,
                        rules: rules.length - 1,
                        minw: thisq.match(/\(min\-width:[\s]*([\s]*[0-9]+)px[\s]*\)/) && parseFloat(RegExp.$1),
                        maxw: thisq.match(/\(max\-width:[\s]*([\s]*[0-9]+)px[\s]*\)/) && parseFloat(RegExp.$1)
                    });
                }
            }

            applyMedia();
        },

        lastCall,

        resizeDefer,

  //enable/disable styles
        applyMedia = function (fromResize) {
            var name = "clientWidth",
                docElemProp = docElem[name],
                currWidth = doc.compatMode === "CSS1Compat" && docElemProp || doc.body[name] || docElemProp,
                styleBlocks = {},
                lastLink = links[links.length - 1],
                now = (new Date()).getTime(),
                newIds = [];

            //throttle resize calls 
            if (fromResize && lastCall && now - lastCall < resizeThrottle) {
                clearTimeout(resizeDefer);
                resizeDefer = setTimeout(applyMedia, resizeThrottle);
                return;
            }
            else {
                lastCall = now;
            }

            for (var i = 0; i < mediastyles.length; i++) {
                var thisstyle = mediastyles[i];
                if (!thisstyle.minw && !thisstyle.maxw ||
                    (!thisstyle.minw || thisstyle.minw && currWidth >= thisstyle.minw) &&
                    (!thisstyle.maxw || thisstyle.maxw && currWidth <= thisstyle.maxw)) {
                    if (!styleBlocks[thisstyle.media]) {
                        styleBlocks[thisstyle.media] = [];
                    }
                    newIds.push(i);
                    styleBlocks[thisstyle.media].push(rules[thisstyle.rules]);
                }
            }

            //skip if nothing has changed
            newIds = newIds.join("-");
            if (newIds === currentIds) {
                return;
            }
            else {
                currentIds = newIds;
            }

            //remove any existing respond style element(s)
            for (var i in appendedEls) {
                if (appendedEls[i] && appendedEls[i].parentNode === head) {
                    head.removeChild(appendedEls[i]);
                }
            }

            //inject active styles, grouped by media type
            for (var i in styleBlocks) {
                var ss = doc.createElement("style"),
                    css = styleBlocks[i].join("\n");

                ss.type = "text/css";
                ss.media = i;

                //append to DOM first for IE7
                head.insertBefore(ss, lastLink.nextSibling);

                if (ss.styleSheet) {
                    ss.styleSheet.cssText = css;
                }
                else {
                    ss.appendChild(doc.createTextNode(css));
                }
                appendedEls.push(ss);
            }
        },
  //tweaked Ajax functions from Quirksmode
        ajax = function (url, callback) {
            var req = xmlHttp();
            if (!req) {
                return;
            }
            req.open("GET", url, true);
            req.onreadystatechange = function () {
                if (req.readyState != 4 || req.status != 200 && req.status != 304) {
                    return;
                }
                callback(req.responseText);
            }
            if (req.readyState == 4) {
                return;
            }
            req.send(null);
        },
  //define ajax obj 
        xmlHttp = (function () {
            var xmlhttpmethod = false,
                attempts = [
                    function () { return new XMLHttpRequest() },
                    function () { return new ActiveXObject("Microsoft.XMLHTTP") }
                ],
                al = attempts.length;

            while (al--) {
                try {
                    xmlhttpmethod = attempts[al]();
                }
                catch (e) {
                    continue;
                }
                break;
            }
            return function () {
                return xmlhttpmethod;
            };
        })();

  //translate CSS
  ripCSS();

  //expose update for re-running respond later on
  respond.update = ripCSS;

  //adjust on resize
  function callMedia() {
      applyMedia(true);
  }
  if (win.addEventListener) {
      win.addEventListener("resize", callMedia, false);
  }
  else if (win.attachEvent) {
      win.attachEvent("onresize", callMedia);
  }
})(
    this,
    (function (win) {

        //for speed, flag browsers with window.matchMedia support and IE 9 as supported
        if (win.matchMedia) { return true; }

        var bool,
            doc = document,
            docElem = doc.documentElement,
            refNode = docElem.firstElementChild || docElem.firstChild,
        // fakeBody required for <FF4 when executed in <head>
            fakeUsed = !doc.body,
            fakeBody = doc.body || doc.createElement("body"),
            div = doc.createElement("div"),
            q = "only all";

        div.id = "mq-test-1";
        div.style.cssText = "position:absolute;top:-99em";
        fakeBody.appendChild(div);

        div.innerHTML = '_<style media="' + q + '"> #mq-test-1 { width: 9px; }</style>';
        if (fakeUsed) {
            docElem.insertBefore(fakeBody, refNode);
        }
        div.removeChild(div.firstChild);
        bool = div.offsetWidth == 9;
        if (fakeUsed) {
            docElem.removeChild(fakeBody);
        }
        else {
            fakeBody.removeChild(div);
        }
        return bool;
    })(this)
); 
// Super pager
(function(a){a.fn.superPager=function(b){b=a.extend({},a.fn.superPager.defaults,b);pageSize=b.pageSize;topPaging=b.topPaging;bottomPaging=b.bottomPaging;nextText=b.nextText;prevText=b.prevText;pageStatus=b.pageStatus;statusLocation=b.statusLocation;showAll=b.showAll;truncate=b.truncate;if(f<=5){truncate=false}var c=a(this);var d=c.selector;c.data("pager",c);var e=a(this).children("ul").children("li").length;var f=Math.ceil(e/pageSize);var g=1;var h=[];if(e>pageSize){a(this).children("ul").addClass("result-holder");a(this).children("ul").children("li").removeClass("even odd");for(var i=1;i<=e;i++){if(i==1){a(this).children("ul").children("li:first").addClass("result").addClass("page1").attr("id","result1")}else{pageChecker=Math.ceil(i/pageSize);a(this).children("ul").children("li:eq("+(i-1)+")").addClass("result").addClass("page"+pageChecker).attr("id","result"+i)}}for(var i=1;i<=f;i++){a(".page"+i,c).wrapAll('<li id="page'+i+'" class="pagingListItem"><ul id="page'+i+'List" class="pageList"></ul></li>');var j=a("#page"+i+"List li",c).length;for(var k=1;k<=j;k++){if(k==1){a("#page"+i+"List li:first",c).addClass("odd")}else{if(k%2==0){a("#page"+i+"List li:eq("+(k-1)+")",c).addClass("even")}else{a("#page"+i+"List li:eq("+(k-1)+")",c).addClass("odd")}}}}var l='<div class="leftSide"><span id="resultStart">'+1+'</span> - <span id="resultEnd">'+pageSize+"</span> of "+e+".</div>";var m='<div class="rightSide"><a href="#" class="prev">'+prevText+"</a></div>";var n=a('<div id="topPaging" class="paging"></div>');var o=a('<div id="bottomPaging" class="paging"></div>');if(topPaging){var p=m;if(pageStatus&&statusLocation=="top"){p+=l}n.append(p);a(this).prepend(n)}if(bottomPaging){var p=m;if(pageStatus&&statusLocation=="bottom"){p+=l}o.append(p);a(this).append(o)}if(showAll){a("#topPaging .leftSide, #bottomPaging .leftSide",c).append('<span><a href="javascript:;" class="showAllItems">Show All</a></span>')}for(var i=1;i<=f;i++){h[i]=i}a("#tPager1, #bPager1, #top_fEllip, #bot_fEllip",c).css("display","none");a(".prev",c).css("visibility","hidden");a("#tInd1, #bInd1",c).css("display","inline");a('#bottomPaging span[id^="bInd"]',c).each(function(b){if(b!=0){a(this).hide()}});a('#topPaging span[id^="tInd"]',c).each(function(b){if(b!=0){a(this).hide()}});a(".paging .rightSide",c).append('<a href="#" class="next">'+nextText+"</a>");a(".pagingListItem",c).css("display","none");a("#page"+g,c).css("display","block");if(truncate){for(key in h){if(key>2&&key<f-1){a("#tPager"+key+",#tInd"+key+",#bPager"+key+",#bInd",c).css("display","none")}}}}a(".prev, .next",a(c.selector)).bind("click",function(b){b.stopPropagation();if(a(this).attr("class").indexOf("prev")!=-1){g=g-1}else if(a(this).attr("class").indexOf("next")!=-1){g=g+1}else{g=parseInt(a(this).text())}a(".pagingListItem",a(c)).css("display","none");a("#page"+g,a(c)).css("display","block");a("#currentPage",a(c)).text(g);a("#resultStart",a(c)).text(g*pageSize-(pageSize-1));if(g==f){a("#resultEnd",a(c)).text(e)}else{a("#resultEnd",a(c)).text(g*pageSize)}if(g==f){a(".next",a(c)).css("visibility","hidden");a(".prev",a(c)).css("visibility","visible")}else if(g==1){a(".next",a(c)).css("visibility","visible");a(".prev",a(c)).css("visibility","hidden")}else{a(".next",a(c)).css("visibility","visible");a(".prev",a(c)).css("visibility","visible")}if(!truncate){a(".tInd, .bInd",a(c)).hide();a(".pager",a(c)).css("display","inline");a("#tPager"+g+", #bPager"+g,a(c)).css("display","none");a("#tInd"+g+", #bInd"+g,a(c)).css("display","inline")}else{a("#top_fEllip, #bot_fEllip, #top_lEllip, #bot_lEllip, .pager, .tInd, .bInd",a(c)).css("display","none");if(g>3){a("#top_fEllip, #bot_fEllip",a(c)).css("display","inline")}if(g<f-2){a("#top_lEllip, #bot_lEllip",a(c)).css("display","inline")}for(var d=1;d<=f;d+=1){if(d==g||d==g-1||d==g+1||d<=1||d>=f-1){a("#bPager"+d+", #tPager"+d+"",a(c)).css("display","inline")}}a("#tPager"+g+", #bPager"+g,a(c)).css("display","none");a("#tInd"+g+", #bInd"+g,a(c)).css("display","inline")}return false});a(".showAllItems",c).bind("click",function(){a(".result",c).each(function(b){a(this).appendTo(a(".result-holder"))});a("#bottomPaging, #topPaging, .pagingListItem",c).remove()})};a.fn.superPager.defaults={pageSize:25,topPaging:true,bottomPaging:true,nextText:"next",prevText:"previous",pageStatus:true,statusLocation:"bottom",showAll:false,truncate:false}})(jQuery)
;
/**
 * jQuery Plugin to obtain touch gestures from iPhone, iPod Touch and iPad, should also work with Android mobile phones (not tested yet!)
 * Common usage: wipe images (left and right to show the previous or next image)
 * 
 * @author Andreas Waltl, netCU Internetagentur (http://www.netcu.de)
 * @version 1.1.1 (9th December 2010) - fix bug (older IE's had problems)
 * @version 1.1 (1st September 2010) - support wipe up and wipe down
 * @version 1.0 (15th July 2010)
 */

(function($){$.fn.touchwipe=function(settings){var config={min_move_x:20,min_move_y:20,wipeLeft:function(){},wipeRight:function(){},wipeUp:function(){},wipeDown:function(){},preventDefaultEvents:true};if(settings)$.extend(config,settings);this.each(function(){var startX;var startY;var isMoving=false;function cancelTouch(){this.removeEventListener('touchmove',onTouchMove);startX=null;isMoving=false}function onTouchMove(e){if(config.preventDefaultEvents){e.preventDefault()}if(isMoving){var x=e.touches[0].pageX;var y=e.touches[0].pageY;var dx=startX-x;var dy=startY-y;if(Math.abs(dx)>=config.min_move_x){cancelTouch();if(dx>0){config.wipeLeft()}else{config.wipeRight()}}else if(Math.abs(dy)>=config.min_move_y){cancelTouch();if(dy>0){config.wipeDown()}else{config.wipeUp()}}}}function onTouchStart(e){if(e.touches.length==1){startX=e.touches[0].pageX;startY=e.touches[0].pageY;isMoving=true;this.addEventListener('touchmove',onTouchMove,false)}}if('ontouchstart'in document.documentElement){this.addEventListener('touchstart',onTouchStart,false)}});return this}})(jQuery);
/*! lightslider - v1.1.6 - 2016-10-25
 * https://github.com/sachinchoolur/lightslider
 * Copyright (c) 2016 Sachin N; Licensed MIT */

(function ($, undefined) {
    'use strict';
    var defaults = {
        item: 3,
        autoWidth: false,
        slideMove: 1,
        slideMargin: 10,
        addClass: '',
        mode: 'slide',
        useCSS: true,
        cssEasing: 'ease', //'cubic-bezier(0.25, 0, 0.25, 1)',
        easing: 'linear', //'for jquery animation',//
        speed: 400, //ms'
        auto: false,
        pauseOnHover: false,
        loop: false,
        slideEndAnimation: true,
        pause: 2000,
        keyPress: false,
        controls: true,
        prevHtml: '',
        nextHtml: '',
        rtl: false,
        adaptiveHeight: false,
        vertical: false,
        verticalHeight: 500,
        vThumbWidth: 100,
        thumbItem: 10,
        pager: true,
        gallery: false,
        galleryMargin: 5,
        thumbMargin: 5,
        currentPagerPosition: 'middle',
        enableTouch: true,
        enableDrag: true,
        freeMove: true,
        swipeThreshold: 40,
        responsive: [],
        /* jshint ignore:start */
        onBeforeStart: function ($el) {},
        onSliderLoad: function ($el) {},
        onBeforeSlide: function ($el, scene) {},
        onAfterSlide: function ($el, scene) {},
        onBeforeNextSlide: function ($el, scene) {},
        onBeforePrevSlide: function ($el, scene) {}
        /* jshint ignore:end */
    };
    $.fn.lightSlider = function (options) {
        if (this.length === 0) {
            return this;
        }

        if (this.length > 1) {
            this.each(function () {
                $(this).lightSlider(options);
            });
            return this;
        }

        var plugin = {},
            settings = $.extend(true, {}, defaults, options),
            settingsTemp = {},
            $el = this;
        plugin.$el = this;

        if (settings.mode === 'fade') {
            settings.vertical = false;
        }
        var $children = $el.children(),
            windowW = $(window).width(),
            breakpoint = null,
            resposiveObj = null,
            length = 0,
            w = 0,
            on = false,
            elSize = 0,
            $slide = '',
            scene = 0,
            property = (settings.vertical === true) ? 'height' : 'width',
            gutter = (settings.vertical === true) ? 'margin-bottom' : 'margin-right',
            slideValue = 0,
            pagerWidth = 0,
            slideWidth = 0,
            thumbWidth = 0,
            interval = null,
            isTouch = ('ontouchstart' in document.documentElement);
        var refresh = {};

        refresh.chbreakpoint = function () {
            windowW = $(window).width();
            if (settings.responsive.length) {
                var item;
                if (settings.autoWidth === false) {
                    item = settings.item;
                }
                if (windowW < settings.responsive[0].breakpoint) {
                    for (var i = 0; i < settings.responsive.length; i++) {
                        if (windowW < settings.responsive[i].breakpoint) {
                            breakpoint = settings.responsive[i].breakpoint;
                            resposiveObj = settings.responsive[i];
                        }
                    }
                }
                if (typeof resposiveObj !== 'undefined' && resposiveObj !== null) {
                    for (var j in resposiveObj.settings) {
                        if (resposiveObj.settings.hasOwnProperty(j)) {
                            if (typeof settingsTemp[j] === 'undefined' || settingsTemp[j] === null) {
                                settingsTemp[j] = settings[j];
                            }
                            settings[j] = resposiveObj.settings[j];
                        }
                    }
                }
                if (!$.isEmptyObject(settingsTemp) && windowW > settings.responsive[0].breakpoint) {
                    for (var k in settingsTemp) {
                        if (settingsTemp.hasOwnProperty(k)) {
                            settings[k] = settingsTemp[k];
                        }
                    }
                }
                if (settings.autoWidth === false) {
                    if (slideValue > 0 && slideWidth > 0) {
                        if (item !== settings.item) {
                            scene = Math.round(slideValue / ((slideWidth + settings.slideMargin) * settings.slideMove));
                        }
                    }
                }
            }
        };

        refresh.calSW = function () {
            if (settings.autoWidth === false) {
                slideWidth = (elSize - ((settings.item * (settings.slideMargin)) - settings.slideMargin)) / settings.item;
            }
        };

        refresh.calWidth = function (cln) {
            var ln = cln === true ? $slide.find('.lslide').length : $children.length;
            if (settings.autoWidth === false) {
                w = ln * (slideWidth + settings.slideMargin);
            } else {
                w = 0;
                for (var i = 0; i < ln; i++) {
                    w += (parseInt($children.eq(i).width()) + settings.slideMargin);
                }
            }
            return w;
        };
        plugin = {
            doCss: function () {
                var support = function () {
                    var transition = ['transition', 'MozTransition', 'WebkitTransition', 'OTransition', 'msTransition', 'KhtmlTransition'];
                    var root = document.documentElement;
                    for (var i = 0; i < transition.length; i++) {
                        if (transition[i] in root.style) {
                            return true;
                        }
                    }
                };
                if (settings.useCSS && support()) {
                    return true;
                }
                return false;
            },
            keyPress: function () {
                if (settings.keyPress) {
                    $(document).on('keyup.lightslider', function (e) {
                        if (!$(':focus').is('input, textarea')) {
                            if (e.preventDefault) {
                                e.preventDefault();
                            } else {
                                e.returnValue = false;
                            }
                            if (e.keyCode === 37) {
                                $el.goToPrevSlide();
                            } else if (e.keyCode === 39) {
                                $el.goToNextSlide();
                            }
                        }
                    });
                }
            },
            controls: function () {
                if (settings.controls) {
                    $el.after('<div class="lSAction"><a class="lSPrev">' + settings.prevHtml + '</a><a class="lSNext">' + settings.nextHtml + '</a></div>');
                    if (!settings.autoWidth) {
                        if (length <= settings.item) {
                            $slide.find('.lSAction').hide();
                        }
                    } else {
                        if (refresh.calWidth(false) < elSize) {
                            $slide.find('.lSAction').hide();
                        }
                    }
                    $slide.find('.lSAction a').on('click', function (e) {
                        if (e.preventDefault) {
                            e.preventDefault();
                        } else {
                            e.returnValue = false;
                        }
                        if ($(this).attr('class') === 'lSPrev') {
                            $el.goToPrevSlide();
                        } else {
                            $el.goToNextSlide();
                        }
                        return false;
                    });
                }
            },
            initialStyle: function () {
                var $this = this;
                if (settings.mode === 'fade') {
                    settings.autoWidth = false;
                    settings.slideEndAnimation = false;
                }
                if (settings.auto) {
                    settings.slideEndAnimation = false;
                }
                if (settings.autoWidth) {
                    settings.slideMove = 1;
                    settings.item = 1;
                }
                if (settings.loop) {
                    settings.slideMove = 1;
                    settings.freeMove = false;
                }
                settings.onBeforeStart.call(this, $el);
                refresh.chbreakpoint();
                $el.addClass('lightSlider').wrap('<div class="lSSlideOuter ' + settings.addClass + '"><div class="lSSlideWrapper"></div></div>');
                $slide = $el.parent('.lSSlideWrapper');
                if (settings.rtl === true) {
                    $slide.parent().addClass('lSrtl');
                }
                if (settings.vertical) {
                    $slide.parent().addClass('vertical');
                    elSize = settings.verticalHeight;
                    $slide.css('height', elSize + 'px');
                } else {
                    elSize = $el.outerWidth();
                }
                $children.addClass('lslide');
                if (settings.loop === true && settings.mode === 'slide') {
                    refresh.calSW();
                    refresh.clone = function () {
                        if (refresh.calWidth(true) > elSize) {
                            /**/
                            var tWr = 0,
                                tI = 0;
                            for (var k = 0; k < $children.length; k++) {
                                tWr += (parseInt($el.find('.lslide').eq(k).width()) + settings.slideMargin);
                                tI++;
                                if (tWr >= (elSize + settings.slideMargin)) {
                                    break;
                                }
                            }
                            var tItem = settings.autoWidth === true ? tI : settings.item;

                            /**/
                            if (tItem < $el.find('.clone.left').length) {
                                for (var i = 0; i < $el.find('.clone.left').length - tItem; i++) {
                                    $children.eq(i).remove();
                                }
                            }
                            if (tItem < $el.find('.clone.right').length) {
                                for (var j = $children.length - 1; j > ($children.length - 1 - $el.find('.clone.right').length); j--) {
                                    scene--;
                                    $children.eq(j).remove();
                                }
                            }
                            /**/
                            for (var n = $el.find('.clone.right').length; n < tItem; n++) {
                                $el.find('.lslide').eq(n).clone().removeClass('lslide').addClass('clone right').appendTo($el);
                                scene++;
                            }
                            for (var m = $el.find('.lslide').length - $el.find('.clone.left').length; m > ($el.find('.lslide').length - tItem); m--) {
                                $el.find('.lslide').eq(m - 1).clone().removeClass('lslide').addClass('clone left').prependTo($el);
                            }
                            $children = $el.children();
                        } else {
                            if ($children.hasClass('clone')) {
                                $el.find('.clone').remove();
                                $this.move($el, 0);
                            }
                        }
                    };
                    refresh.clone();
                }
                refresh.sSW = function () {
                    length = $children.length;
                    if (settings.rtl === true && settings.vertical === false) {
                        gutter = 'margin-left';
                    }
                    if (settings.autoWidth === false) {
                        $children.css(property, slideWidth + 'px');
                    }
                    $children.css(gutter, settings.slideMargin + 'px');
                    w = refresh.calWidth(false);
                    $el.css(property, w + 'px');
                    if (settings.loop === true && settings.mode === 'slide') {
                        if (on === false) {
                            scene = $el.find('.clone.left').length;
                        }
                    }
                };
                refresh.calL = function () {
                    $children = $el.children();
                    length = $children.length;
                };
                if (this.doCss()) {
                    $slide.addClass('usingCss');
                }
                refresh.calL();
                if (settings.mode === 'slide') {
                    refresh.calSW();
                    refresh.sSW();
                    if (settings.loop === true) {
                        slideValue = $this.slideValue();
                        this.move($el, slideValue);
                    }
                    if (settings.vertical === false) {
                        this.setHeight($el, false);
                    }

                } else {
                    this.setHeight($el, true);
                    $el.addClass('lSFade');
                    if (!this.doCss()) {
                        $children.fadeOut(0);
                        $children.eq(scene).fadeIn(0);
                    }
                }
                if (settings.loop === true && settings.mode === 'slide') {
                    $children.eq(scene).addClass('active');
                } else {
                    $children.first().addClass('active');
                }
            },
            pager: function () {
                var $this = this;
                refresh.createPager = function () {
                    thumbWidth = (elSize - ((settings.thumbItem * (settings.thumbMargin)) - settings.thumbMargin)) / settings.thumbItem;
                    var $children = $slide.find('.lslide');
                    var length = $slide.find('.lslide').length;
                    var i = 0,
                        pagers = '',
                        v = 0;
                    for (i = 0; i < length; i++) {
                        if (settings.mode === 'slide') {
                            // calculate scene * slide value
                            if (!settings.autoWidth) {
                                v = i * ((slideWidth + settings.slideMargin) * settings.slideMove);
                            } else {
                                v += ((parseInt($children.eq(i).width()) + settings.slideMargin) * settings.slideMove);
                            }
                        }
                        var thumb = $children.eq(i * settings.slideMove).attr('data-thumb');
                        if (settings.gallery === true) {
                            pagers += '<li style="width:100%;' + property + ':' + thumbWidth + 'px;' + gutter + ':' + settings.thumbMargin + 'px"><a href="#"><img src="' + thumb + '" /></a></li>';
                        } else {
                            pagers += '<li><a href="#">' + (i + 1) + '</a></li>';
                        }
                        if (settings.mode === 'slide') {
                            if ((v) >= w - elSize - settings.slideMargin) {
                                i = i + 1;
                                var minPgr = 2;
                                if (settings.autoWidth) {
                                    pagers += '<li><a href="#">' + (i + 1) + '</a></li>';
                                    minPgr = 1;
                                }
                                if (i < minPgr) {
                                    pagers = null;
                                    $slide.parent().addClass('noPager');
                                } else {
                                    $slide.parent().removeClass('noPager');
                                }
                                break;
                            }
                        }
                    }
                    var $cSouter = $slide.parent();
                    $cSouter.find('.lSPager').html(pagers);
                    if (settings.gallery === true) {
                        if (settings.vertical === true) {
                            // set Gallery thumbnail width
                            $cSouter.find('.lSPager').css('width', settings.vThumbWidth + 'px');
                        }
                        pagerWidth = (i * (settings.thumbMargin + thumbWidth)) + 0.5;
                        $cSouter.find('.lSPager').css({
                            property: pagerWidth + 'px',
                            'transition-duration': settings.speed + 'ms'
                        });
                        if (settings.vertical === true) {
                            $slide.parent().css('padding-right', (settings.vThumbWidth + settings.galleryMargin) + 'px');
                        }
                        $cSouter.find('.lSPager').css(property, pagerWidth + 'px');
                    }
                    var $pager = $cSouter.find('.lSPager').find('li');
                    $pager.first().addClass('active');
                    $pager.on('click', function () {
                        if (settings.loop === true && settings.mode === 'slide') {
                            scene = scene + ($pager.index(this) - $cSouter.find('.lSPager').find('li.active').index());
                        } else {
                            scene = $pager.index(this);
                        }
                        $el.mode(false);
                        if (settings.gallery === true) {
                            $this.slideThumb();
                        }
                        return false;
                    });
                };
                if (settings.pager) {
                    var cl = 'lSpg';
                    if (settings.gallery) {
                        cl = 'lSGallery';
                    }
                    $slide.after('<ul class="lSPager ' + cl + '"></ul>');
                    var gMargin = (settings.vertical) ? 'margin-left' : 'margin-top';
                    $slide.parent().find('.lSPager').css(gMargin, settings.galleryMargin + 'px');
                    refresh.createPager();
                }

                setTimeout(function () {
                    refresh.init();
                }, 0);
            },
            setHeight: function (ob, fade) {
                var obj = null,
                    $this = this;
                if (settings.loop) {
                    obj = ob.children('.lslide ').first();
                } else {
                    obj = ob.children().first();
                }
                var setCss = function () {
                    var tH = obj.outerHeight(),
                        tP = 0,
                        tHT = tH;
                    if (fade) {
                        tH = 0;
                        tP = ((tHT) * 100) / elSize;
                    }
                    ob.css({
                        'height': tH + 'px',
                        'padding-bottom': tP + '%'
                    });
                };
                setCss();
                if (obj.find('img').length) {
                    if (obj.find('img')[0].complete) {
                        setCss();
                        if (!interval) {
                            $this.auto();
                        }
                    } else {
                        obj.find('img').on('load', function () {
                            setTimeout(function () {
                                setCss();
                                if (!interval) {
                                    $this.auto();
                                }
                            }, 100);
                        });
                    }
                } else {
                    if (!interval) {
                        $this.auto();
                    }
                }
            },
            active: function (ob, t) {
                if (this.doCss() && settings.mode === 'fade') {
                    $slide.addClass('on');
                }
                var sc = 0;
                if (scene * settings.slideMove < length) {
                    ob.removeClass('active');
                    if (!this.doCss() && settings.mode === 'fade' && t === false) {
                        ob.fadeOut(settings.speed);
                    }
                    if (t === true) {
                        sc = scene;
                    } else {
                        sc = scene * settings.slideMove;
                    }
                    //t === true ? sc = scene : sc = scene * settings.slideMove;
                    var l, nl;
                    if (t === true) {
                        l = ob.length;
                        nl = l - 1;
                        if (sc + 1 >= l) {
                            sc = nl;
                        }
                    }
                    if (settings.loop === true && settings.mode === 'slide') {
                        //t === true ? sc = scene - $el.find('.clone.left').length : sc = scene * settings.slideMove;
                        if (t === true) {
                            sc = scene - $el.find('.clone.left').length;
                        } else {
                            sc = scene * settings.slideMove;
                        }
                        if (t === true) {
                            l = ob.length;
                            nl = l - 1;
                            if (sc + 1 === l) {
                                sc = nl;
                            } else if (sc + 1 > l) {
                                sc = 0;
                            }
                        }
                    }

                    if (!this.doCss() && settings.mode === 'fade' && t === false) {
                        ob.eq(sc).fadeIn(settings.speed);
                    }
                    ob.eq(sc).addClass('active');
                } else {
                    ob.removeClass('active');
                    ob.eq(ob.length - 1).addClass('active');
                    if (!this.doCss() && settings.mode === 'fade' && t === false) {
                        ob.fadeOut(settings.speed);
                        ob.eq(sc).fadeIn(settings.speed);
                    }
                }
            },
            move: function (ob, v) {
                if (settings.rtl === true) {
                    v = -v;
                }
                if (this.doCss()) {
                    if (settings.vertical === true) {
                        ob.css({
                            'transform': 'translate3d(0px, ' + (-v) + 'px, 0px)',
                            '-webkit-transform': 'translate3d(0px, ' + (-v) + 'px, 0px)'
                        });
                    } else {
                        ob.css({
                            'transform': 'translate3d(' + (-v) + 'px, 0px, 0px)',
                            '-webkit-transform': 'translate3d(' + (-v) + 'px, 0px, 0px)',
                        });
                    }
                } else {
                    if (settings.vertical === true) {
                        ob.css('position', 'relative').animate({
                            top: -v + 'px'
                        }, settings.speed, settings.easing);
                    } else {
                        ob.css('position', 'relative').animate({
                            left: -v + 'px'
                        }, settings.speed, settings.easing);
                    }
                }
                var $thumb = $slide.parent().find('.lSPager').find('li');
                this.active($thumb, true);
            },
            fade: function () {
                this.active($children, false);
                var $thumb = $slide.parent().find('.lSPager').find('li');
                this.active($thumb, true);
            },
            slide: function () {
                var $this = this;
                refresh.calSlide = function () {
                    if (w > elSize) {
                        slideValue = $this.slideValue();
                        $this.active($children, false);
                        if ((slideValue) > w - elSize - settings.slideMargin) {
                            slideValue = w - elSize - settings.slideMargin;
                        } else if (slideValue < 0) {
                            slideValue = 0;
                        }
                        $this.move($el, slideValue);
                        if (settings.loop === true && settings.mode === 'slide') {
                            if (scene >= (length - ($el.find('.clone.left').length / settings.slideMove))) {
                                $this.resetSlide($el.find('.clone.left').length);
                            }
                            if (scene === 0) {
                                $this.resetSlide($slide.find('.lslide').length);
                            }
                        }
                    }
                };
                refresh.calSlide();
            },
            resetSlide: function (s) {
                var $this = this;
                $slide.find('.lSAction a').addClass('disabled');
                setTimeout(function () {
                    scene = s;
                    $slide.css('transition-duration', '0ms');
                    slideValue = $this.slideValue();
                    $this.active($children, false);
                    plugin.move($el, slideValue);
                    setTimeout(function () {
                        $slide.css('transition-duration', settings.speed + 'ms');
                        $slide.find('.lSAction a').removeClass('disabled');
                    }, 50);
                }, settings.speed + 100);
            },
            slideValue: function () {
                var _sV = 0;
                if (settings.autoWidth === false) {
                    _sV = scene * ((slideWidth + settings.slideMargin) * settings.slideMove);
                } else {
                    _sV = 0;
                    for (var i = 0; i < scene; i++) {
                        _sV += (parseInt($children.eq(i).width()) + settings.slideMargin);
                    }
                }
                return _sV;
            },
            slideThumb: function () {
                var position;
                switch (settings.currentPagerPosition) {
                    case 'left':
                        position = 0;
                        break;
                    case 'middle':
                        position = (elSize / 2) - (thumbWidth / 2);
                        break;
                    case 'right':
                        position = elSize - thumbWidth;
                }
                var sc = scene - $el.find('.clone.left').length;
                var $pager = $slide.parent().find('.lSPager');
                if (settings.mode === 'slide' && settings.loop === true) {
                    if (sc >= $pager.children().length) {
                        sc = 0;
                    } else if (sc < 0) {
                        sc = $pager.children().length;
                    }
                }
                var thumbSlide = sc * ((thumbWidth + settings.thumbMargin)) - (position);
                if ((thumbSlide + elSize) > pagerWidth) {
                    thumbSlide = pagerWidth - elSize - settings.thumbMargin;
                }
                if (thumbSlide < 0) {
                    thumbSlide = 0;
                }
                this.move($pager, thumbSlide);
            },
            auto: function () {
                if (settings.auto) {
                    clearInterval(interval);
                    interval = setInterval(function () {
                        $el.goToNextSlide();
                    }, settings.pause);
                }
            },
            pauseOnHover: function () {
                var $this = this;
                if (settings.auto && settings.pauseOnHover) {
                    $slide.on('mouseenter', function () {
                        $(this).addClass('ls-hover');
                        $el.pause();
                        settings.auto = true;
                    });
                    $slide.on('mouseleave', function () {
                        $(this).removeClass('ls-hover');
                        if (!$slide.find('.lightSlider').hasClass('lsGrabbing')) {
                            $this.auto();
                        }
                    });
                }
            },
            touchMove: function (endCoords, startCoords) {
                $slide.css('transition-duration', '0ms');
                if (settings.mode === 'slide') {
                    var distance = endCoords - startCoords;
                    var swipeVal = slideValue - distance;
                    if ((swipeVal) >= w - elSize - settings.slideMargin) {
                        if (settings.freeMove === false) {
                            swipeVal = w - elSize - settings.slideMargin;
                        } else {
                            var swipeValT = w - elSize - settings.slideMargin;
                            swipeVal = swipeValT + ((swipeVal - swipeValT) / 5);

                        }
                    } else if (swipeVal < 0) {
                        if (settings.freeMove === false) {
                            swipeVal = 0;
                        } else {
                            swipeVal = swipeVal / 5;
                        }
                    }
                    this.move($el, swipeVal);
                }
            },

            touchEnd: function (distance) {
                $slide.css('transition-duration', settings.speed + 'ms');
                if (settings.mode === 'slide') {
                    var mxVal = false;
                    var _next = true;
                    slideValue = slideValue - distance;
                    if ((slideValue) > w - elSize - settings.slideMargin) {
                        slideValue = w - elSize - settings.slideMargin;
                        if (settings.autoWidth === false) {
                            mxVal = true;
                        }
                    } else if (slideValue < 0) {
                        slideValue = 0;
                    }
                    var gC = function (next) {
                        var ad = 0;
                        if (!mxVal) {
                            if (next) {
                                ad = 1;
                            }
                        }
                        if (!settings.autoWidth) {
                            var num = slideValue / ((slideWidth + settings.slideMargin) * settings.slideMove);
                            scene = parseInt(num) + ad;
                            if (slideValue >= (w - elSize - settings.slideMargin)) {
                                if (num % 1 !== 0) {
                                    scene++;
                                }
                            }
                        } else {
                            var tW = 0;
                            for (var i = 0; i < $children.length; i++) {
                                tW += (parseInt($children.eq(i).width()) + settings.slideMargin);
                                scene = i + ad;
                                if (tW >= slideValue) {
                                    break;
                                }
                            }
                        }
                    };
                    if (distance >= settings.swipeThreshold) {
                        gC(false);
                        _next = false;
                    } else if (distance <= -settings.swipeThreshold) {
                        gC(true);
                        _next = false;
                    }
                    $el.mode(_next);
                    this.slideThumb();
                } else {
                    if (distance >= settings.swipeThreshold) {
                        $el.goToPrevSlide();
                    } else if (distance <= -settings.swipeThreshold) {
                        $el.goToNextSlide();
                    }
                }
            },



            enableDrag: function () {
                var $this = this;
                if (!isTouch) {
                    var startCoords = 0,
                        endCoords = 0,
                        isDraging = false;
                    $slide.find('.lightSlider').addClass('lsGrab');
                    $slide.on('mousedown', function (e) {
                        if (w < elSize) {
                            if (w !== 0) {
                                return false;
                            }
                        }
                        if ($(e.target).attr('class') !== ('lSPrev') && $(e.target).attr('class') !== ('lSNext')) {
                            startCoords = (settings.vertical === true) ? e.pageY : e.pageX;
                            isDraging = true;
                            if (e.preventDefault) {
                                e.preventDefault();
                            } else {
                                e.returnValue = false;
                            }
                            // ** Fix for webkit cursor issue https://code.google.com/p/chromium/issues/detail?id=26723
                            $slide.scrollLeft += 1;
                            $slide.scrollLeft -= 1;
                            // *
                            $slide.find('.lightSlider').removeClass('lsGrab').addClass('lsGrabbing');
                            clearInterval(interval);
                        }
                    });
                    $(window).on('mousemove', function (e) {
                        if (isDraging) {
                            endCoords = (settings.vertical === true) ? e.pageY : e.pageX;
                            $this.touchMove(endCoords, startCoords);
                        }
                    });
                    $(window).on('mouseup', function (e) {
                        if (isDraging) {
                            $slide.find('.lightSlider').removeClass('lsGrabbing').addClass('lsGrab');
                            isDraging = false;
                            endCoords = (settings.vertical === true) ? e.pageY : e.pageX;
                            var distance = endCoords - startCoords;
                            if (Math.abs(distance) >= settings.swipeThreshold) {
                                $(window).on('click.ls', function (e) {
                                    if (e.preventDefault) {
                                        e.preventDefault();
                                    } else {
                                        e.returnValue = false;
                                    }
                                    e.stopImmediatePropagation();
                                    e.stopPropagation();
                                    $(window).off('click.ls');
                                });
                            }

                            $this.touchEnd(distance);

                        }
                    });
                }
            },




            enableTouch: function () {
                var $this = this;
                if (isTouch) {
                    var startCoords = {},
                        endCoords = {};
                    $slide.on('touchstart', function (e) {
                        endCoords = e.originalEvent.targetTouches[0];
                        startCoords.pageX = e.originalEvent.targetTouches[0].pageX;
                        startCoords.pageY = e.originalEvent.targetTouches[0].pageY;
                        clearInterval(interval);
                    });
                    $slide.on('touchmove', function (e) {
                        if (w < elSize) {
                            if (w !== 0) {
                                return false;
                            }
                        }
                        var orig = e.originalEvent;
                        endCoords = orig.targetTouches[0];
                        var xMovement = Math.abs(endCoords.pageX - startCoords.pageX);
                        var yMovement = Math.abs(endCoords.pageY - startCoords.pageY);
                        if (settings.vertical === true) {
                            if ((yMovement * 3) > xMovement) {
                                e.preventDefault();
                            }
                            $this.touchMove(endCoords.pageY, startCoords.pageY);
                        } else {
                            if ((xMovement * 3) > yMovement) {
                                e.preventDefault();
                            }
                            $this.touchMove(endCoords.pageX, startCoords.pageX);
                        }

                    });
                    $slide.on('touchend', function () {
                        if (w < elSize) {
                            if (w !== 0) {
                                return false;
                            }
                        }
                        var distance;
                        if (settings.vertical === true) {
                            distance = endCoords.pageY - startCoords.pageY;
                        } else {
                            distance = endCoords.pageX - startCoords.pageX;
                        }
                        $this.touchEnd(distance);
                    });
                }
            },
            build: function () {
                var $this = this;
                $this.initialStyle();
                if (this.doCss()) {

                    if (settings.enableTouch === true) {
                        $this.enableTouch();
                    }
                    if (settings.enableDrag === true) {
                        $this.enableDrag();
                    }
                }

                $(window).on('focus', function () {
                    $this.auto();
                });

                $(window).on('blur', function () {
                    clearInterval(interval);
                });

                $this.pager();
                $this.pauseOnHover();
                $this.controls();
                $this.keyPress();
            }
        };
        plugin.build();
        refresh.init = function () {
            refresh.chbreakpoint();
            if (settings.vertical === true) {
                if (settings.item > 1) {
                    elSize = settings.verticalHeight;
                } else {
                    elSize = $children.outerHeight();
                }
                $slide.css('height', elSize + 'px');
            } else {
                elSize = $slide.outerWidth();
            }
            if (settings.loop === true && settings.mode === 'slide') {
                refresh.clone();
            }
            refresh.calL();
            if (settings.mode === 'slide') {
                $el.removeClass('lSSlide');
            }
            if (settings.mode === 'slide') {
                refresh.calSW();
                refresh.sSW();
            }
            setTimeout(function () {
                if (settings.mode === 'slide') {
                    $el.addClass('lSSlide');
                }
            }, 1000);
            if (settings.pager) {
                refresh.createPager();
            }
            if (settings.adaptiveHeight === true && settings.vertical === false) {
                $el.css('height', $children.eq(scene).outerHeight(true));
            }
            if (settings.adaptiveHeight === false) {
                if (settings.mode === 'slide') {
                    if (settings.vertical === false) {
                        plugin.setHeight($el, false);
                    } else {
                        plugin.auto();
                    }
                } else {
                    plugin.setHeight($el, true);
                }
            }
            if (settings.gallery === true) {
                plugin.slideThumb();
            }
            if (settings.mode === 'slide') {
                plugin.slide();
            }
            if (settings.autoWidth === false) {
                if ($children.length <= settings.item) {
                    $slide.find('.lSAction').hide();
                } else {
                    $slide.find('.lSAction').show();
                }
            } else {
                if ((refresh.calWidth(false) < elSize) && (w !== 0)) {
                    $slide.find('.lSAction').hide();
                } else {
                    $slide.find('.lSAction').show();
                }
            }
        };
        $el.goToPrevSlide = function () {
            if (scene > 0) {
                settings.onBeforePrevSlide.call(this, $el, scene);
                scene--;
                $el.mode(false);
                if (settings.gallery === true) {
                    plugin.slideThumb();
                }
            } else {
                if (settings.loop === true) {
                    settings.onBeforePrevSlide.call(this, $el, scene);
                    if (settings.mode === 'fade') {
                        var l = (length - 1);
                        scene = parseInt(l / settings.slideMove);
                    }
                    $el.mode(false);
                    if (settings.gallery === true) {
                        plugin.slideThumb();
                    }
                } else if (settings.slideEndAnimation === true) {
                    $el.addClass('leftEnd');
                    setTimeout(function () {
                        $el.removeClass('leftEnd');
                    }, 400);
                }
            }
        };
        $el.goToNextSlide = function () {
            var nextI = true;
            if (settings.mode === 'slide') {
                var _slideValue = plugin.slideValue();
                nextI = _slideValue < w - elSize - settings.slideMargin;
            }
            if (((scene * settings.slideMove) < length - settings.slideMove) && nextI) {
                settings.onBeforeNextSlide.call(this, $el, scene);
                scene++;
                $el.mode(false);
                if (settings.gallery === true) {
                    plugin.slideThumb();
                }
            } else {
                if (settings.loop === true) {
                    settings.onBeforeNextSlide.call(this, $el, scene);
                    scene = 0;
                    $el.mode(false);
                    if (settings.gallery === true) {
                        plugin.slideThumb();
                    }
                } else if (settings.slideEndAnimation === true) {
                    $el.addClass('rightEnd');
                    setTimeout(function () {
                        $el.removeClass('rightEnd');
                    }, 400);
                }
            }
        };
        $el.mode = function (_touch) {
            if (settings.adaptiveHeight === true && settings.vertical === false) {
                $el.css('height', $children.eq(scene).outerHeight(true));
            }
            if (on === false) {
                if (settings.mode === 'slide') {
                    if (plugin.doCss()) {
                        $el.addClass('lSSlide');
                        if (settings.speed !== '') {
                            $slide.css('transition-duration', settings.speed + 'ms');
                        }
                        if (settings.cssEasing !== '') {
                            $slide.css('transition-timing-function', settings.cssEasing);
                        }
                    }
                } else {
                    if (plugin.doCss()) {
                        if (settings.speed !== '') {
                            $el.css('transition-duration', settings.speed + 'ms');
                        }
                        if (settings.cssEasing !== '') {
                            $el.css('transition-timing-function', settings.cssEasing);
                        }
                    }
                }
            }
            if (!_touch) {
                settings.onBeforeSlide.call(this, $el, scene);
            }
            if (settings.mode === 'slide') {
                plugin.slide();
            } else {
                plugin.fade();
            }
            if (!$slide.hasClass('ls-hover')) {
                plugin.auto();
            }
            setTimeout(function () {
                if (!_touch) {
                    settings.onAfterSlide.call(this, $el, scene);
                }
            }, settings.speed);
            on = true;
        };
        $el.play = function () {
            $el.goToNextSlide();
            settings.auto = true;
            plugin.auto();
        };
        $el.pause = function () {
            settings.auto = false;
            clearInterval(interval);
        };
        $el.refresh = function () {
            refresh.init();
        };
        $el.getCurrentSlideCount = function () {
            var sc = scene;
            if (settings.loop) {
                var ln = $slide.find('.lslide').length,
                    cl = $el.find('.clone.left').length;
                if (scene <= cl - 1) {
                    sc = ln + (scene - cl);
                } else if (scene >= (ln + cl)) {
                    sc = scene - ln - cl;
                } else {
                    sc = scene - cl;
                }
            }
            return sc + 1;
        };
        $el.getTotalSlideCount = function () {
            return $slide.find('.lslide').length;
        };
        $el.goToSlide = function (s) {
            if (settings.loop) {
                scene = (s + $el.find('.clone.left').length - 1);
            } else {
                scene = s;
            }
            $el.mode(false);
            if (settings.gallery === true) {
                plugin.slideThumb();
            }
        };
        $el.destroy = function () {
            if ($el.lightSlider) {
                $el.goToPrevSlide = function () {};
                $el.goToNextSlide = function () {};
                $el.mode = function () {};
                $el.play = function () {};
                $el.pause = function () {};
                $el.refresh = function () {};
                $el.getCurrentSlideCount = function () {};
                $el.getTotalSlideCount = function () {};
                $el.goToSlide = function () {};
                $el.lightSlider = null;
                refresh = {
                    init: function () {}
                };
                $el.parent().parent().find('.lSAction, .lSPager').remove();
                $el.removeClass('lightSlider lSFade lSSlide lsGrab lsGrabbing leftEnd right').removeAttr('style').unwrap().unwrap();
                $el.children().removeAttr('style');
                $children.removeClass('lslide active');
                $el.find('.clone').remove();
                $children = null;
                interval = null;
                on = false;
                scene = 0;
            }

        };
        setTimeout(function () {
            settings.onSliderLoad.call(this, $el);
        }, 10);
        $(window).on('resize orientationchange', function (e) {
            setTimeout(function () {
                if (e.preventDefault) {
                    e.preventDefault();
                } else {
                    e.returnValue = false;
                }
                refresh.init();
            }, 200);
        });
        return this;
    };
}(jQuery));
/*
     _ _      _       _
 ___| (_) ___| | __  (_)___
/ __| | |/ __| |/ /  | / __|
\__ \ | | (__|   < _ | \__ \
|___/_|_|\___|_|\_(_)/ |___/
                   |__/

 Version: 1.8.1
  Author: Ken Wheeler
 Website: http://kenwheeler.github.io
    Docs: http://kenwheeler.github.io/slick
    Repo: http://github.com/kenwheeler/slick
  Issues: http://github.com/kenwheeler/slick/issues

 */
/* global window, document, define, jQuery, setInterval, clearInterval */

;(function(factory) {
    'use strict';
    if (typeof define === 'function' && define.amd) {
        define(['jquery'], factory);
    } else if (typeof exports !== 'undefined') {
        module.exports = factory(require('jquery'));
    } else {
        factory(jQuery);
    }

}(function($) {
    'use strict';
    var Slick = window.Slick || {};

    Slick = (function() {

        var instanceUid = 0;

        function Slick(element, settings) {

            var _ = this, dataSettings;

            _.defaults = {
                accessibility: true,
                adaptiveHeight: false,
                appendArrows: $(element),
                appendDots: $(element),
                arrows: true,
                asNavFor: null,
                prevArrow: '<button class="slick-prev" aria-label="Previous" type="button">Previous</button>',
                nextArrow: '<button class="slick-next" aria-label="Next" type="button">Next</button>',
                autoplay: false,
                autoplaySpeed: 3000,
                centerMode: false,
                centerPadding: '50px',
                cssEase: 'ease',
                customPaging: function(slider, i) {
                    return $('<button type="button" />').text(i + 1);
                },
                dots: false,
                dotsClass: 'slick-dots',
                draggable: true,
                easing: 'linear',
                edgeFriction: 0.35,
                fade: false,
                focusOnSelect: false,
                focusOnChange: false,
                infinite: true,
                initialSlide: 0,
                lazyLoad: 'ondemand',
                mobileFirst: false,
                pauseOnHover: true,
                pauseOnFocus: true,
                pauseOnDotsHover: false,
                respondTo: 'window',
                responsive: null,
                rows: 1,
                rtl: false,
                slide: '',
                slidesPerRow: 1,
                slidesToShow: 1,
                slidesToScroll: 1,
                speed: 500,
                swipe: true,
                swipeToSlide: false,
                touchMove: true,
                touchThreshold: 5,
                useCSS: true,
                useTransform: true,
                variableWidth: false,
                vertical: false,
                verticalSwiping: false,
                waitForAnimate: true,
                zIndex: 1000
            };

            _.initials = {
                animating: false,
                dragging: false,
                autoPlayTimer: null,
                currentDirection: 0,
                currentLeft: null,
                currentSlide: 0,
                direction: 1,
                $dots: null,
                listWidth: null,
                listHeight: null,
                loadIndex: 0,
                $nextArrow: null,
                $prevArrow: null,
                scrolling: false,
                slideCount: null,
                slideWidth: null,
                $slideTrack: null,
                $slides: null,
                sliding: false,
                slideOffset: 0,
                swipeLeft: null,
                swiping: false,
                $list: null,
                touchObject: {},
                transformsEnabled: false,
                unslicked: false
            };

            $.extend(_, _.initials);

            _.activeBreakpoint = null;
            _.animType = null;
            _.animProp = null;
            _.breakpoints = [];
            _.breakpointSettings = [];
            _.cssTransitions = false;
            _.focussed = false;
            _.interrupted = false;
            _.hidden = 'hidden';
            _.paused = true;
            _.positionProp = null;
            _.respondTo = null;
            _.rowCount = 1;
            _.shouldClick = true;
            _.$slider = $(element);
            _.$slidesCache = null;
            _.transformType = null;
            _.transitionType = null;
            _.visibilityChange = 'visibilitychange';
            _.windowWidth = 0;
            _.windowTimer = null;

            dataSettings = $(element).data('slick') || {};

            _.options = $.extend({}, _.defaults, settings, dataSettings);

            _.currentSlide = _.options.initialSlide;

            _.originalSettings = _.options;

            if (typeof document.mozHidden !== 'undefined') {
                _.hidden = 'mozHidden';
                _.visibilityChange = 'mozvisibilitychange';
            } else if (typeof document.webkitHidden !== 'undefined') {
                _.hidden = 'webkitHidden';
                _.visibilityChange = 'webkitvisibilitychange';
            }

            _.autoPlay = $.proxy(_.autoPlay, _);
            _.autoPlayClear = $.proxy(_.autoPlayClear, _);
            _.autoPlayIterator = $.proxy(_.autoPlayIterator, _);
            _.changeSlide = $.proxy(_.changeSlide, _);
            _.clickHandler = $.proxy(_.clickHandler, _);
            _.selectHandler = $.proxy(_.selectHandler, _);
            _.setPosition = $.proxy(_.setPosition, _);
            _.swipeHandler = $.proxy(_.swipeHandler, _);
            _.dragHandler = $.proxy(_.dragHandler, _);
            _.keyHandler = $.proxy(_.keyHandler, _);

            _.instanceUid = instanceUid++;

            // A simple way to check for HTML strings
            // Strict HTML recognition (must start with <)
            // Extracted from jQuery v1.11 source
            _.htmlExpr = /^(?:\s*(<[\w\W]+>)[^>]*)$/;


            _.registerBreakpoints();
            _.init(true);

        }

        return Slick;

    }());

    Slick.prototype.activateADA = function() {
        var _ = this;

        _.$slideTrack.find('.slick-active').attr({
            'aria-hidden': 'false'
        }).find('a, input, button, select').attr({
            'tabindex': '0'
        });

    };

    Slick.prototype.addSlide = Slick.prototype.slickAdd = function(markup, index, addBefore) {

        var _ = this;

        if (typeof(index) === 'boolean') {
            addBefore = index;
            index = null;
        } else if (index < 0 || (index >= _.slideCount)) {
            return false;
        }

        _.unload();

        if (typeof(index) === 'number') {
            if (index === 0 && _.$slides.length === 0) {
                $(markup).appendTo(_.$slideTrack);
            } else if (addBefore) {
                $(markup).insertBefore(_.$slides.eq(index));
            } else {
                $(markup).insertAfter(_.$slides.eq(index));
            }
        } else {
            if (addBefore === true) {
                $(markup).prependTo(_.$slideTrack);
            } else {
                $(markup).appendTo(_.$slideTrack);
            }
        }

        _.$slides = _.$slideTrack.children(this.options.slide);

        _.$slideTrack.children(this.options.slide).detach();

        _.$slideTrack.append(_.$slides);

        _.$slides.each(function(index, element) {
            $(element).attr('data-slick-index', index);
        });

        _.$slidesCache = _.$slides;

        _.reinit();

    };

    Slick.prototype.animateHeight = function() {
        var _ = this;
        if (_.options.slidesToShow === 1 && _.options.adaptiveHeight === true && _.options.vertical === false) {
            var targetHeight = _.$slides.eq(_.currentSlide).outerHeight(true);
            _.$list.animate({
                height: targetHeight
            }, _.options.speed);
        }
    };

    Slick.prototype.animateSlide = function(targetLeft, callback) {

        var animProps = {},
            _ = this;

        _.animateHeight();

        if (_.options.rtl === true && _.options.vertical === false) {
            targetLeft = -targetLeft;
        }
        if (_.transformsEnabled === false) {
            if (_.options.vertical === false) {
                _.$slideTrack.animate({
                    left: targetLeft
                }, _.options.speed, _.options.easing, callback);
            } else {
                _.$slideTrack.animate({
                    top: targetLeft
                }, _.options.speed, _.options.easing, callback);
            }

        } else {

            if (_.cssTransitions === false) {
                if (_.options.rtl === true) {
                    _.currentLeft = -(_.currentLeft);
                }
                $({
                    animStart: _.currentLeft
                }).animate({
                    animStart: targetLeft
                }, {
                    duration: _.options.speed,
                    easing: _.options.easing,
                    step: function(now) {
                        now = Math.ceil(now);
                        if (_.options.vertical === false) {
                            animProps[_.animType] = 'translate(' +
                                now + 'px, 0px)';
                            _.$slideTrack.css(animProps);
                        } else {
                            animProps[_.animType] = 'translate(0px,' +
                                now + 'px)';
                            _.$slideTrack.css(animProps);
                        }
                    },
                    complete: function() {
                        if (callback) {
                            callback.call();
                        }
                    }
                });

            } else {

                _.applyTransition();
                targetLeft = Math.ceil(targetLeft);

                if (_.options.vertical === false) {
                    animProps[_.animType] = 'translate3d(' + targetLeft + 'px, 0px, 0px)';
                } else {
                    animProps[_.animType] = 'translate3d(0px,' + targetLeft + 'px, 0px)';
                }
                _.$slideTrack.css(animProps);

                if (callback) {
                    setTimeout(function() {

                        _.disableTransition();

                        callback.call();
                    }, _.options.speed);
                }

            }

        }

    };

    Slick.prototype.getNavTarget = function() {

        var _ = this,
            asNavFor = _.options.asNavFor;

        if ( asNavFor && asNavFor !== null ) {
            asNavFor = $(asNavFor).not(_.$slider);
        }

        return asNavFor;

    };

    Slick.prototype.asNavFor = function(index) {

        var _ = this,
            asNavFor = _.getNavTarget();

        if ( asNavFor !== null && typeof asNavFor === 'object' ) {
            asNavFor.each(function() {
                var target = $(this).slick('getSlick');
                if(!target.unslicked) {
                    target.slideHandler(index, true);
                }
            });
        }

    };

    Slick.prototype.applyTransition = function(slide) {

        var _ = this,
            transition = {};

        if (_.options.fade === false) {
            transition[_.transitionType] = _.transformType + ' ' + _.options.speed + 'ms ' + _.options.cssEase;
        } else {
            transition[_.transitionType] = 'opacity ' + _.options.speed + 'ms ' + _.options.cssEase;
        }

        if (_.options.fade === false) {
            _.$slideTrack.css(transition);
        } else {
            _.$slides.eq(slide).css(transition);
        }

    };

    Slick.prototype.autoPlay = function() {

        var _ = this;

        _.autoPlayClear();

        if ( _.slideCount > _.options.slidesToShow ) {
            _.autoPlayTimer = setInterval( _.autoPlayIterator, _.options.autoplaySpeed );
        }

    };

    Slick.prototype.autoPlayClear = function() {

        var _ = this;

        if (_.autoPlayTimer) {
            clearInterval(_.autoPlayTimer);
        }

    };

    Slick.prototype.autoPlayIterator = function() {

        var _ = this,
            slideTo = _.currentSlide + _.options.slidesToScroll;

        if ( !_.paused && !_.interrupted && !_.focussed ) {

            if ( _.options.infinite === false ) {

                if ( _.direction === 1 && ( _.currentSlide + 1 ) === ( _.slideCount - 1 )) {
                    _.direction = 0;
                }

                else if ( _.direction === 0 ) {

                    slideTo = _.currentSlide - _.options.slidesToScroll;

                    if ( _.currentSlide - 1 === 0 ) {
                        _.direction = 1;
                    }

                }

            }

            _.slideHandler( slideTo );

        }

    };

    Slick.prototype.buildArrows = function() {

        var _ = this;

        if (_.options.arrows === true ) {

            _.$prevArrow = $(_.options.prevArrow).addClass('slick-arrow');
            _.$nextArrow = $(_.options.nextArrow).addClass('slick-arrow');

            if( _.slideCount > _.options.slidesToShow ) {

                _.$prevArrow.removeClass('slick-hidden').removeAttr('aria-hidden tabindex');
                _.$nextArrow.removeClass('slick-hidden').removeAttr('aria-hidden tabindex');

                if (_.htmlExpr.test(_.options.prevArrow)) {
                    _.$prevArrow.prependTo(_.options.appendArrows);
                }

                if (_.htmlExpr.test(_.options.nextArrow)) {
                    _.$nextArrow.appendTo(_.options.appendArrows);
                }

                if (_.options.infinite !== true) {
                    _.$prevArrow
                        .addClass('slick-disabled')
                        .attr('aria-disabled', 'true');
                }

            } else {

                _.$prevArrow.add( _.$nextArrow )

                    .addClass('slick-hidden')
                    .attr({
                        'aria-disabled': 'true',
                        'tabindex': '-1'
                    });

            }

        }

    };

    Slick.prototype.buildDots = function() {

        var _ = this,
            i, dot;

        if (_.options.dots === true && _.slideCount > _.options.slidesToShow) {

            _.$slider.addClass('slick-dotted');

            dot = $('<ul />').addClass(_.options.dotsClass);

            for (i = 0; i <= _.getDotCount(); i += 1) {
                dot.append($('<li />').append(_.options.customPaging.call(this, _, i)));
            }

            _.$dots = dot.appendTo(_.options.appendDots);

            _.$dots.find('li').first().addClass('slick-active');

        }

    };

    Slick.prototype.buildOut = function() {

        var _ = this;

        _.$slides =
            _.$slider
                .children( _.options.slide + ':not(.slick-cloned)')
                .addClass('slick-slide');

        _.slideCount = _.$slides.length;

        _.$slides.each(function(index, element) {
            $(element)
                .attr('data-slick-index', index)
                .data('originalStyling', $(element).attr('style') || '');
        });

        _.$slider.addClass('slick-slider');

        _.$slideTrack = (_.slideCount === 0) ?
            $('<div class="slick-track"/>').appendTo(_.$slider) :
            _.$slides.wrapAll('<div class="slick-track"/>').parent();

        _.$list = _.$slideTrack.wrap(
            '<div class="slick-list"/>').parent();
        _.$slideTrack.css('opacity', 0);

        if (_.options.centerMode === true || _.options.swipeToSlide === true) {
            _.options.slidesToScroll = 1;
        }

        $('img[data-lazy]', _.$slider).not('[src]').addClass('slick-loading');

        _.setupInfinite();

        _.buildArrows();

        _.buildDots();

        _.updateDots();


        _.setSlideClasses(typeof _.currentSlide === 'number' ? _.currentSlide : 0);

        if (_.options.draggable === true) {
            _.$list.addClass('draggable');
        }

    };

    Slick.prototype.buildRows = function() {

        var _ = this, a, b, c, newSlides, numOfSlides, originalSlides,slidesPerSection;

        newSlides = document.createDocumentFragment();
        originalSlides = _.$slider.children();

        if(_.options.rows > 0) {

            slidesPerSection = _.options.slidesPerRow * _.options.rows;
            numOfSlides = Math.ceil(
                originalSlides.length / slidesPerSection
            );

            for(a = 0; a < numOfSlides; a++){
                var slide = document.createElement('div');
                for(b = 0; b < _.options.rows; b++) {
                    var row = document.createElement('div');
                    for(c = 0; c < _.options.slidesPerRow; c++) {
                        var target = (a * slidesPerSection + ((b * _.options.slidesPerRow) + c));
                        if (originalSlides.get(target)) {
                            row.appendChild(originalSlides.get(target));
                        }
                    }
                    slide.appendChild(row);
                }
                newSlides.appendChild(slide);
            }

            _.$slider.empty().append(newSlides);
            _.$slider.children().children().children()
            .addClass('slick__display-prop').css({
                    'width':(100 / _.options.slidesPerRow) + '%',                    
                });
        }

    };

    Slick.prototype.checkResponsive = function(initial, forceUpdate) {

        var _ = this,
            breakpoint, targetBreakpoint, respondToWidth, triggerBreakpoint = false;
        var sliderWidth = _.$slider.width();
        var windowWidth = window.innerWidth || $(window).width();

        if (_.respondTo === 'window') {
            respondToWidth = windowWidth;
        } else if (_.respondTo === 'slider') {
            respondToWidth = sliderWidth;
        } else if (_.respondTo === 'min') {
            respondToWidth = Math.min(windowWidth, sliderWidth);
        }

        if ( _.options.responsive &&
            _.options.responsive.length &&
            _.options.responsive !== null) {

            targetBreakpoint = null;

            for (breakpoint in _.breakpoints) {
                if (_.breakpoints.hasOwnProperty(breakpoint)) {
                    if (_.originalSettings.mobileFirst === false) {
                        if (respondToWidth < _.breakpoints[breakpoint]) {
                            targetBreakpoint = _.breakpoints[breakpoint];
                        }
                    } else {
                        if (respondToWidth > _.breakpoints[breakpoint]) {
                            targetBreakpoint = _.breakpoints[breakpoint];
                        }
                    }
                }
            }

            if (targetBreakpoint !== null) {
                if (_.activeBreakpoint !== null) {
                    if (targetBreakpoint !== _.activeBreakpoint || forceUpdate) {
                        _.activeBreakpoint =
                            targetBreakpoint;
                        if (_.breakpointSettings[targetBreakpoint] === 'unslick') {
                            _.unslick(targetBreakpoint);
                        } else {
                            _.options = $.extend({}, _.originalSettings,
                                _.breakpointSettings[
                                    targetBreakpoint]);
                            if (initial === true) {
                                _.currentSlide = _.options.initialSlide;
                            }
                            _.refresh(initial);
                        }
                        triggerBreakpoint = targetBreakpoint;
                    }
                } else {
                    _.activeBreakpoint = targetBreakpoint;
                    if (_.breakpointSettings[targetBreakpoint] === 'unslick') {
                        _.unslick(targetBreakpoint);
                    } else {
                        _.options = $.extend({}, _.originalSettings,
                            _.breakpointSettings[
                                targetBreakpoint]);
                        if (initial === true) {
                            _.currentSlide = _.options.initialSlide;
                        }
                        _.refresh(initial);
                    }
                    triggerBreakpoint = targetBreakpoint;
                }
            } else {
                if (_.activeBreakpoint !== null) {
                    _.activeBreakpoint = null;
                    _.options = _.originalSettings;
                    if (initial === true) {
                        _.currentSlide = _.options.initialSlide;
                    }
                    _.refresh(initial);
                    triggerBreakpoint = targetBreakpoint;
                }
            }

            // only trigger breakpoints during an actual break. not on initialize.
            if( !initial && triggerBreakpoint !== false ) {
                _.$slider.trigger('breakpoint', [_, triggerBreakpoint]);
            }
        }

    };

    Slick.prototype.changeSlide = function(event, dontAnimate) {

        var _ = this,
            $target = $(event.currentTarget),
            indexOffset, slideOffset, unevenOffset;

        // If target is a link, prevent default action.
        if($target.is('a')) {
            event.preventDefault();
        }

        // If target is not the <li> element (ie: a child), find the <li>.
        if(!$target.is('li')) {
            $target = $target.closest('li');
        }

        unevenOffset = (_.slideCount % _.options.slidesToScroll !== 0);
        indexOffset = unevenOffset ? 0 : (_.slideCount - _.currentSlide) % _.options.slidesToScroll;

        switch (event.data.message) {

            case 'previous':
                slideOffset = indexOffset === 0 ? _.options.slidesToScroll : _.options.slidesToShow - indexOffset;
                if (_.slideCount > _.options.slidesToShow) {
                    _.slideHandler(_.currentSlide - slideOffset, false, dontAnimate);
                }
                break;

            case 'next':
                slideOffset = indexOffset === 0 ? _.options.slidesToScroll : indexOffset;
                if (_.slideCount > _.options.slidesToShow) {
                    _.slideHandler(_.currentSlide + slideOffset, false, dontAnimate);
                }
                break;

            case 'index':
                var index = event.data.index === 0 ? 0 :
                    event.data.index || $target.index() * _.options.slidesToScroll;

                _.slideHandler(_.checkNavigable(index), false, dontAnimate);
                $target.children().trigger('focus');
                break;

            default:
                return;
        }

    };

    Slick.prototype.checkNavigable = function(index) {

        var _ = this,
            navigables, prevNavigable;

        navigables = _.getNavigableIndexes();
        prevNavigable = 0;
        if (index > navigables[navigables.length - 1]) {
            index = navigables[navigables.length - 1];
        } else {
            for (var n in navigables) {
                if (index < navigables[n]) {
                    index = prevNavigable;
                    break;
                }
                prevNavigable = navigables[n];
            }
        }

        return index;
    };

    Slick.prototype.cleanUpEvents = function() {

        var _ = this;

        if (_.options.dots && _.$dots !== null) {

            $('li', _.$dots)
                .off('click.slick', _.changeSlide)
                .off('mouseenter.slick', $.proxy(_.interrupt, _, true))
                .off('mouseleave.slick', $.proxy(_.interrupt, _, false));

            if (_.options.accessibility === true) {
                _.$dots.off('keydown.slick', _.keyHandler);
            }
        }

        _.$slider.off('focus.slick blur.slick');

        if (_.options.arrows === true && _.slideCount > _.options.slidesToShow) {
            _.$prevArrow && _.$prevArrow.off('click.slick', _.changeSlide);
            _.$nextArrow && _.$nextArrow.off('click.slick', _.changeSlide);

            if (_.options.accessibility === true) {
                _.$prevArrow && _.$prevArrow.off('keydown.slick', _.keyHandler);
                _.$nextArrow && _.$nextArrow.off('keydown.slick', _.keyHandler);
            }
        }

        _.$list.off('touchstart.slick mousedown.slick', _.swipeHandler);
        _.$list.off('touchmove.slick mousemove.slick', _.swipeHandler);
        _.$list.off('touchend.slick mouseup.slick', _.swipeHandler);
        _.$list.off('touchcancel.slick mouseleave.slick', _.swipeHandler);

        _.$list.off('click.slick', _.clickHandler);

        $(document).off(_.visibilityChange, _.visibility);

        _.cleanUpSlideEvents();

        if (_.options.accessibility === true) {
            _.$list.off('keydown.slick', _.keyHandler);
        }

        if (_.options.focusOnSelect === true) {
            $(_.$slideTrack).children().off('click.slick', _.selectHandler);
        }

        $(window).off('orientationchange.slick.slick-' + _.instanceUid, _.orientationChange);

        $(window).off('resize.slick.slick-' + _.instanceUid, _.resize);

        $('[draggable!=true]', _.$slideTrack).off('dragstart', _.preventDefault);

        $(window).off('load.slick.slick-' + _.instanceUid, _.setPosition);

    };

    Slick.prototype.cleanUpSlideEvents = function() {

        var _ = this;

        _.$list.off('mouseenter.slick', $.proxy(_.interrupt, _, true));
        _.$list.off('mouseleave.slick', $.proxy(_.interrupt, _, false));

    };

    Slick.prototype.cleanUpRows = function() {

        var _ = this, originalSlides;

        if(_.options.rows > 0) {
            originalSlides = _.$slides.children().children();
            originalSlides.removeAttr('style');
            _.$slider.empty().append(originalSlides);
        }

    };

    Slick.prototype.clickHandler = function(event) {

        var _ = this;

        if (_.shouldClick === false) {
            event.stopImmediatePropagation();
            event.stopPropagation();
            event.preventDefault();
        }

    };

    Slick.prototype.destroy = function(refresh) {

        var _ = this;

        _.autoPlayClear();

        _.touchObject = {};

        _.cleanUpEvents();

        $('.slick-cloned', _.$slider).detach();

        if (_.$dots) {
            _.$dots.remove();
        }

        if ( _.$prevArrow && _.$prevArrow.length ) {

            _.$prevArrow
                .removeClass('slick-disabled slick-arrow slick-hidden')
                .removeAttr('aria-hidden aria-disabled tabindex')
                .css('display','');

            if ( _.htmlExpr.test( _.options.prevArrow )) {
                _.$prevArrow.remove();
            }
        }

        if ( _.$nextArrow && _.$nextArrow.length ) {

            _.$nextArrow
                .removeClass('slick-disabled slick-arrow slick-hidden')
                .removeAttr('aria-hidden aria-disabled tabindex')
                .css('display','');

            if ( _.htmlExpr.test( _.options.nextArrow )) {
                _.$nextArrow.remove();
            }
        }


        if (_.$slides) {

            _.$slides
                .removeClass('slick-slide slick-active slick-center slick-visible slick-current')
                .removeAttr('aria-hidden')
                .removeAttr('data-slick-index')
                .each(function(){
                    $(this).attr('style', $(this).data('originalStyling'));
                });

            _.$slideTrack.children(this.options.slide).detach();

            _.$slideTrack.detach();

            _.$list.detach();

            _.$slider.append(_.$slides);
        }

        _.cleanUpRows();

        _.$slider.removeClass('slick-slider');
        _.$slider.removeClass('slick-initialized');
        _.$slider.removeClass('slick-dotted');

        _.unslicked = true;

        if(!refresh) {
            _.$slider.trigger('destroy', [_]);
        }

    };

    Slick.prototype.disableTransition = function(slide) {

        var _ = this,
            transition = {};

        transition[_.transitionType] = '';

        if (_.options.fade === false) {
            _.$slideTrack.css(transition);
        } else {
            _.$slides.eq(slide).css(transition);
        }

    };

    Slick.prototype.fadeSlide = function(slideIndex, callback) {

        var _ = this;

        if (_.cssTransitions === false) {

            _.$slides.eq(slideIndex).css({
                zIndex: _.options.zIndex
            });

            _.$slides.eq(slideIndex).animate({
                opacity: 1
            }, _.options.speed, _.options.easing, callback);

        } else {

            _.applyTransition(slideIndex);

            _.$slides.eq(slideIndex).css({
                opacity: 1,
                zIndex: _.options.zIndex
            });

            if (callback) {
                setTimeout(function() {

                    _.disableTransition(slideIndex);

                    callback.call();
                }, _.options.speed);
            }

        }

    };

    Slick.prototype.fadeSlideOut = function(slideIndex) {

        var _ = this;

        if (_.cssTransitions === false) {

            _.$slides.eq(slideIndex).animate({
                opacity: 0,
                zIndex: _.options.zIndex - 2
            }, _.options.speed, _.options.easing);

        } else {

            _.applyTransition(slideIndex);

            _.$slides.eq(slideIndex).css({
                opacity: 0,
                zIndex: _.options.zIndex - 2
            });

        }

    };

    Slick.prototype.filterSlides = Slick.prototype.slickFilter = function(filter) {

        var _ = this;

        if (filter !== null) {

            _.$slidesCache = _.$slides;

            _.unload();

            _.$slideTrack.children(this.options.slide).detach();

            _.$slidesCache.filter(filter).appendTo(_.$slideTrack);

            _.reinit();

        }

    };

    Slick.prototype.focusHandler = function() {

        var _ = this;

        // If any child element receives focus within the slider we need to pause the autoplay
        _.$slider
            .off('focus.slick blur.slick')
            .on(
                'focus.slick',
                '*', 
                function(event) {
                    var $sf = $(this);

                    setTimeout(function() {
                        if( _.options.pauseOnFocus ) {
                            if ($sf.is(':focus')) {
                                _.focussed = true;
                                _.autoPlay();
                            }
                        }
                    }, 0);
                }
            ).on(
                'blur.slick',
                '*', 
                function(event) {
                    var $sf = $(this);

                    // When a blur occurs on any elements within the slider we become unfocused
                    if( _.options.pauseOnFocus ) {
                        _.focussed = false;
                        _.autoPlay();
                    }
                }
            );
    };

    Slick.prototype.getCurrent = Slick.prototype.slickCurrentSlide = function() {

        var _ = this;
        return _.currentSlide;

    };

    Slick.prototype.getDotCount = function() {

        var _ = this;

        var breakPoint = 0;
        var counter = 0;
        var pagerQty = 0;

        if (_.options.infinite === true) {
            if (_.slideCount <= _.options.slidesToShow) {
                 ++pagerQty;
            } else {
                while (breakPoint < _.slideCount) {
                    ++pagerQty;
                    breakPoint = counter + _.options.slidesToScroll;
                    counter += _.options.slidesToScroll <= _.options.slidesToShow ? _.options.slidesToScroll : _.options.slidesToShow;
                }
            }
        } else if (_.options.centerMode === true) {
            pagerQty = _.slideCount;
        } else if(!_.options.asNavFor) {
            pagerQty = 1 + Math.ceil((_.slideCount - _.options.slidesToShow) / _.options.slidesToScroll);
        }else {
            while (breakPoint < _.slideCount) {
                ++pagerQty;
                breakPoint = counter + _.options.slidesToScroll;
                counter += _.options.slidesToScroll <= _.options.slidesToShow ? _.options.slidesToScroll : _.options.slidesToShow;
            }
        }

        return pagerQty - 1;

    };

    Slick.prototype.getLeft = function(slideIndex) {

        var _ = this,
            targetLeft,
            verticalHeight,
            verticalOffset = 0,
            targetSlide,
            coef;

        _.slideOffset = 0;
        verticalHeight = _.$slides.first().outerHeight(true);

        if (_.options.infinite === true) {
            if (_.slideCount > _.options.slidesToShow) {
                _.slideOffset = (_.slideWidth * _.options.slidesToShow) * -1;
                coef = -1

                if (_.options.vertical === true && _.options.centerMode === true) {
                    if (_.options.slidesToShow === 2) {
                        coef = -1.5;
                    } else if (_.options.slidesToShow === 1) {
                        coef = -2
                    }
                }
                verticalOffset = (verticalHeight * _.options.slidesToShow) * coef;
            }
            if (_.slideCount % _.options.slidesToScroll !== 0) {
                if (slideIndex + _.options.slidesToScroll > _.slideCount && _.slideCount > _.options.slidesToShow) {
                    if (slideIndex > _.slideCount) {
                        _.slideOffset = ((_.options.slidesToShow - (slideIndex - _.slideCount)) * _.slideWidth) * -1;
                        verticalOffset = ((_.options.slidesToShow - (slideIndex - _.slideCount)) * verticalHeight) * -1;
                    } else {
                        _.slideOffset = ((_.slideCount % _.options.slidesToScroll) * _.slideWidth) * -1;
                        verticalOffset = ((_.slideCount % _.options.slidesToScroll) * verticalHeight) * -1;
                    }
                }
            }
        } else {
            if (slideIndex + _.options.slidesToShow > _.slideCount) {
                _.slideOffset = ((slideIndex + _.options.slidesToShow) - _.slideCount) * _.slideWidth;
                verticalOffset = ((slideIndex + _.options.slidesToShow) - _.slideCount) * verticalHeight;
            }
        }

        if (_.slideCount <= _.options.slidesToShow) {
            _.slideOffset = 0;
            verticalOffset = 0;
        }

        if (_.options.centerMode === true && _.slideCount <= _.options.slidesToShow) {
            _.slideOffset = ((_.slideWidth * Math.floor(_.options.slidesToShow)) / 2) - ((_.slideWidth * _.slideCount) / 2);
        } else if (_.options.centerMode === true && _.options.infinite === true) {
            _.slideOffset += _.slideWidth * Math.floor(_.options.slidesToShow / 2) - _.slideWidth;
        } else if (_.options.centerMode === true) {
            _.slideOffset = 0;
            _.slideOffset += _.slideWidth * Math.floor(_.options.slidesToShow / 2);
        }

        if (_.options.vertical === false) {
            targetLeft = ((slideIndex * _.slideWidth) * -1) + _.slideOffset;
        } else {
            targetLeft = ((slideIndex * verticalHeight) * -1) + verticalOffset;
        }

        if (_.options.variableWidth === true) {

            if (_.slideCount <= _.options.slidesToShow || _.options.infinite === false) {
                targetSlide = _.$slideTrack.children('.slick-slide').eq(slideIndex);
            } else {
                targetSlide = _.$slideTrack.children('.slick-slide').eq(slideIndex + _.options.slidesToShow);
            }

            if (_.options.rtl === true) {
                if (targetSlide[0]) {
                    targetLeft = (_.$slideTrack.width() - targetSlide[0].offsetLeft - targetSlide.width()) * -1;
                } else {
                    targetLeft =  0;
                }
            } else {
                targetLeft = targetSlide[0] ? targetSlide[0].offsetLeft * -1 : 0;
            }

            if (_.options.centerMode === true) {
                if (_.slideCount <= _.options.slidesToShow || _.options.infinite === false) {
                    targetSlide = _.$slideTrack.children('.slick-slide').eq(slideIndex);
                } else {
                    targetSlide = _.$slideTrack.children('.slick-slide').eq(slideIndex + _.options.slidesToShow + 1);
                }

                if (_.options.rtl === true) {
                    if (targetSlide[0]) {
                        targetLeft = (_.$slideTrack.width() - targetSlide[0].offsetLeft - targetSlide.width()) * -1;
                    } else {
                        targetLeft =  0;
                    }
                } else {
                    targetLeft = targetSlide[0] ? targetSlide[0].offsetLeft * -1 : 0;
                }

                targetLeft += (_.$list.width() - targetSlide.outerWidth()) / 2;
            }
        }

        return targetLeft;

    };

    Slick.prototype.getOption = Slick.prototype.slickGetOption = function(option) {

        var _ = this;

        return _.options[option];

    };

    Slick.prototype.getNavigableIndexes = function() {

        var _ = this,
            breakPoint = 0,
            counter = 0,
            indexes = [],
            max;

        if (_.options.infinite === false) {
            max = _.slideCount;
        } else {
            breakPoint = _.options.slidesToScroll * -1;
            counter = _.options.slidesToScroll * -1;
            max = _.slideCount * 2;
        }

        while (breakPoint < max) {
            indexes.push(breakPoint);
            breakPoint = counter + _.options.slidesToScroll;
            counter += _.options.slidesToScroll <= _.options.slidesToShow ? _.options.slidesToScroll : _.options.slidesToShow;
        }

        return indexes;

    };

    Slick.prototype.getSlick = function() {

        return this;

    };

    Slick.prototype.getSlideCount = function() {

        var _ = this,
            slidesTraversed, swipedSlide, swipeTarget, centerOffset;

        centerOffset = _.options.centerMode === true ? Math.floor(_.$list.width() / 2) : 0;
        swipeTarget = (_.swipeLeft * -1) + centerOffset;

        if (_.options.swipeToSlide === true) {

            _.$slideTrack.find('.slick-slide').each(function(index, slide) {

                var slideOuterWidth, slideOffset, slideRightBoundary;
                slideOuterWidth = $(slide).outerWidth();
                slideOffset = slide.offsetLeft;
                if (_.options.centerMode !== true) {
                    slideOffset += (slideOuterWidth / 2);
                }

                slideRightBoundary = slideOffset + (slideOuterWidth);

                if (swipeTarget < slideRightBoundary) {
                    swipedSlide = slide;
                    return false;
                }
            });

            slidesTraversed = Math.abs($(swipedSlide).attr('data-slick-index') - _.currentSlide) || 1;

            return slidesTraversed;

        } else {
            return _.options.slidesToScroll;
        }

    };

    Slick.prototype.goTo = Slick.prototype.slickGoTo = function(slide, dontAnimate) {

        var _ = this;

        _.changeSlide({
            data: {
                message: 'index',
                index: parseInt(slide)
            }
        }, dontAnimate);

    };

    Slick.prototype.init = function(creation) {

        var _ = this;

        if (!$(_.$slider).hasClass('slick-initialized')) {

            $(_.$slider).addClass('slick-initialized');

            _.buildRows();
            _.buildOut();
            _.setProps();
            _.startLoad();
            _.loadSlider();
            _.initializeEvents();
            _.updateArrows();
            _.updateDots();
            _.checkResponsive(true);
            _.focusHandler();

        }

        if (creation) {
            _.$slider.trigger('init', [_]);
        }

        if (_.options.accessibility === true) {
            _.initADA();
        }

        if ( _.options.autoplay ) {

            _.paused = false;
            _.autoPlay();

        }

    };

    Slick.prototype.initADA = function() {
        var _ = this,
                numDotGroups = Math.ceil(_.slideCount / _.options.slidesToShow),
                tabControlIndexes = _.getNavigableIndexes().filter(function(val) {
                    return (val >= 0) && (val < _.slideCount);
                });

        _.$slides.add(_.$slideTrack.find('.slick-cloned')).attr({
            'aria-hidden': 'true',
            'tabindex': '-1'
        }).find('a, input, button, select').attr({
            'tabindex': '-1'
        });

        if (_.$dots !== null) {
            _.$slides.not(_.$slideTrack.find('.slick-cloned')).each(function(i) {
                var slideControlIndex = tabControlIndexes.indexOf(i);

                $(this).attr({
                    'role': 'tabpanel',
                    'id': 'slick-slide' + _.instanceUid + i,
                    'tabindex': -1
                });

                if (slideControlIndex !== -1) {
                   var ariaButtonControl = 'slick-slide-control' + _.instanceUid + slideControlIndex
                   if ($('#' + ariaButtonControl).length) {
                     $(this).attr({
                         'aria-describedby': ariaButtonControl
                     });
                   }
                }
            });

            _.$dots.attr('role', 'tablist').find('li').each(function(i) {
                var mappedSlideIndex = tabControlIndexes[i];

                $(this).attr({
                    'role': 'presentation'
                });

                $(this).find('button').first().attr({
                    'role': 'tab',
                    'id': 'slick-slide-control' + _.instanceUid + i,
                    'aria-controls': 'slick-slide' + _.instanceUid + mappedSlideIndex,
                    'aria-label': (i + 1) + ' of ' + numDotGroups,
                    'aria-selected': null,
                    'tabindex': '-1'
                });

            }).eq(_.currentSlide).find('button').attr({
                'aria-selected': 'true',
                'tabindex': '0'
            }).end();
        }

        for (var i=_.currentSlide, max=i+_.options.slidesToShow; i < max; i++) {
          if (_.options.focusOnChange) {
            _.$slides.eq(i).attr({'tabindex': '0'});
          } else {
            _.$slides.eq(i).removeAttr('tabindex');
          }
        }

        _.activateADA();

    };

    Slick.prototype.initArrowEvents = function() {

        var _ = this;

        if (_.options.arrows === true && _.slideCount > _.options.slidesToShow) {
            _.$prevArrow
               .off('click.slick')
               .on('click.slick', {
                    message: 'previous'
               }, _.changeSlide);
            _.$nextArrow
               .off('click.slick')
               .on('click.slick', {
                    message: 'next'
               }, _.changeSlide);

            if (_.options.accessibility === true) {
                _.$prevArrow.on('keydown.slick', _.keyHandler);
                _.$nextArrow.on('keydown.slick', _.keyHandler);
            }
        }

    };

    Slick.prototype.initDotEvents = function() {

        var _ = this;

        if (_.options.dots === true && _.slideCount > _.options.slidesToShow) {
            $('li', _.$dots).on('click.slick', {
                message: 'index'
            }, _.changeSlide);

            if (_.options.accessibility === true) {
                _.$dots.on('keydown.slick', _.keyHandler);
            }
        }

        if (_.options.dots === true && _.options.pauseOnDotsHover === true && _.slideCount > _.options.slidesToShow) {

            $('li', _.$dots)
                .on('mouseenter.slick', $.proxy(_.interrupt, _, true))
                .on('mouseleave.slick', $.proxy(_.interrupt, _, false));

        }

    };

    Slick.prototype.initSlideEvents = function() {

        var _ = this;

        if ( _.options.pauseOnHover ) {

            _.$list.on('mouseenter.slick', $.proxy(_.interrupt, _, true));
            _.$list.on('mouseleave.slick', $.proxy(_.interrupt, _, false));

        }

    };

    Slick.prototype.initializeEvents = function() {

        var _ = this;

        _.initArrowEvents();

        _.initDotEvents();
        _.initSlideEvents();

        _.$list.on('touchstart.slick mousedown.slick', {
            action: 'start'
        }, _.swipeHandler);
        _.$list.on('touchmove.slick mousemove.slick', {
            action: 'move'
        }, _.swipeHandler);
        _.$list.on('touchend.slick mouseup.slick', {
            action: 'end'
        }, _.swipeHandler);
        _.$list.on('touchcancel.slick mouseleave.slick', {
            action: 'end'
        }, _.swipeHandler);

        _.$list.on('click.slick', _.clickHandler);

        $(document).on(_.visibilityChange, $.proxy(_.visibility, _));

        if (_.options.accessibility === true) {
            _.$list.on('keydown.slick', _.keyHandler);
        }

        if (_.options.focusOnSelect === true) {
            $(_.$slideTrack).children().on('click.slick', _.selectHandler);
        }

        $(window).on('orientationchange.slick.slick-' + _.instanceUid, $.proxy(_.orientationChange, _));

        $(window).on('resize.slick.slick-' + _.instanceUid, $.proxy(_.resize, _));

        $('[draggable!=true]', _.$slideTrack).on('dragstart', _.preventDefault);

        $(window).on('load.slick.slick-' + _.instanceUid, _.setPosition);
        $(_.setPosition);

    };

    Slick.prototype.initUI = function() {

        var _ = this;

        if (_.options.arrows === true && _.slideCount > _.options.slidesToShow) {

            _.$prevArrow.show();
            _.$nextArrow.show();

        }

        if (_.options.dots === true && _.slideCount > _.options.slidesToShow) {

            _.$dots.show();

        }

    };

    Slick.prototype.keyHandler = function(event) {

        var _ = this;
         //Dont slide if the cursor is inside the form fields and arrow keys are pressed
        if(!event.target.tagName.match('TEXTAREA|INPUT|SELECT')) {
            if (event.keyCode === 37 && _.options.accessibility === true) {
                _.changeSlide({
                    data: {
                        message: _.options.rtl === true ? 'next' :  'previous'
                    }
                });
            } else if (event.keyCode === 39 && _.options.accessibility === true) {
                _.changeSlide({
                    data: {
                        message: _.options.rtl === true ? 'previous' : 'next'
                    }
                });
            }
        }

    };

    Slick.prototype.lazyLoad = function() {

        var _ = this,
            loadRange, cloneRange, rangeStart, rangeEnd;

        function loadImages(imagesScope) {

            $('img[data-lazy]', imagesScope).each(function() {

                var image = $(this),
                    imageSource = $(this).attr('data-lazy'),
                    imageSrcSet = $(this).attr('data-srcset'),
                    imageSizes  = $(this).attr('data-sizes') || _.$slider.attr('data-sizes'),
                    imageToLoad = document.createElement('img');

                imageToLoad.onload = function() {

                    image
                        .animate({ opacity: 0 }, 100, function() {

                            if (imageSrcSet) {
                                image
                                    .attr('srcset', imageSrcSet );

                                if (imageSizes) {
                                    image
                                        .attr('sizes', imageSizes );
                                }
                            }

                            image
                                .attr('src', imageSource)
                                .animate({ opacity: 1 }, 200, function() {
                                    image
                                        .removeAttr('data-lazy data-srcset data-sizes')
                                        .removeClass('slick-loading');
                                });
                            _.$slider.trigger('lazyLoaded', [_, image, imageSource]);
                        });

                };

                imageToLoad.onerror = function() {

                    image
                        .removeAttr( 'data-lazy' )
                        .removeClass( 'slick-loading' )
                        .addClass( 'slick-lazyload-error' );

                    _.$slider.trigger('lazyLoadError', [ _, image, imageSource ]);

                };

                imageToLoad.src = imageSource;

            });

        }

        if (_.options.centerMode === true) {
            if (_.options.infinite === true) {
                rangeStart = _.currentSlide + (_.options.slidesToShow / 2 + 1);
                rangeEnd = rangeStart + _.options.slidesToShow + 2;
            } else {
                rangeStart = Math.max(0, _.currentSlide - (_.options.slidesToShow / 2 + 1));
                rangeEnd = 2 + (_.options.slidesToShow / 2 + 1) + _.currentSlide;
            }
        } else {
            rangeStart = _.options.infinite ? _.options.slidesToShow + _.currentSlide : _.currentSlide;
            rangeEnd = Math.ceil(rangeStart + _.options.slidesToShow);
            if (_.options.fade === true) {
                if (rangeStart > 0) rangeStart--;
                if (rangeEnd <= _.slideCount) rangeEnd++;
            }
        }

        loadRange = _.$slider.find('.slick-slide').slice(rangeStart, rangeEnd);

        if (_.options.lazyLoad === 'anticipated') {
            var prevSlide = rangeStart - 1,
                nextSlide = rangeEnd,
                $slides = _.$slider.find('.slick-slide');

            for (var i = 0; i < _.options.slidesToScroll; i++) {
                if (prevSlide < 0) prevSlide = _.slideCount - 1;
                loadRange = loadRange.add($slides.eq(prevSlide));
                loadRange = loadRange.add($slides.eq(nextSlide));
                prevSlide--;
                nextSlide++;
            }
        }

        loadImages(loadRange);

        if (_.slideCount <= _.options.slidesToShow) {
            cloneRange = _.$slider.find('.slick-slide');
            loadImages(cloneRange);
        } else
        if (_.currentSlide >= _.slideCount - _.options.slidesToShow) {
            cloneRange = _.$slider.find('.slick-cloned').slice(0, _.options.slidesToShow);
            loadImages(cloneRange);
        } else if (_.currentSlide === 0) {
            cloneRange = _.$slider.find('.slick-cloned').slice(_.options.slidesToShow * -1);
            loadImages(cloneRange);
        }

    };

    Slick.prototype.loadSlider = function() {

        var _ = this;

        _.setPosition();

        _.$slideTrack.css({
            opacity: 1
        });

        _.$slider.removeClass('slick-loading');

        _.initUI();

        if (_.options.lazyLoad === 'progressive') {
            _.progressiveLazyLoad();
        }

    };

    Slick.prototype.next = Slick.prototype.slickNext = function() {

        var _ = this;

        _.changeSlide({
            data: {
                message: 'next'
            }
        });

    };

    Slick.prototype.orientationChange = function() {

        var _ = this;

        _.checkResponsive();
        _.setPosition();

    };

    Slick.prototype.pause = Slick.prototype.slickPause = function() {

        var _ = this;

        _.autoPlayClear();
        _.paused = true;

    };

    Slick.prototype.play = Slick.prototype.slickPlay = function() {

        var _ = this;

        _.autoPlay();
        _.options.autoplay = true;
        _.paused = false;
        _.focussed = false;
        _.interrupted = false;

    };

    Slick.prototype.postSlide = function(index) {

        var _ = this;

        if( !_.unslicked ) {

            _.$slider.trigger('afterChange', [_, index]);

            _.animating = false;

            if (_.slideCount > _.options.slidesToShow) {
                _.setPosition();
            }

            _.swipeLeft = null;

            if ( _.options.autoplay ) {
                _.autoPlay();
            }

            if (_.options.accessibility === true) {
                _.initADA();

                if (_.options.focusOnChange) {
                    var $currentSlide = $(_.$slides.get(_.currentSlide));
                    $currentSlide.attr('tabindex', 0).focus();
                }
            }

        }

    };

    Slick.prototype.prev = Slick.prototype.slickPrev = function() {

        var _ = this;

        _.changeSlide({
            data: {
                message: 'previous'
            }
        });

    };

    Slick.prototype.preventDefault = function(event) {

        event.preventDefault();

    };

    Slick.prototype.progressiveLazyLoad = function( tryCount ) {

        tryCount = tryCount || 1;

        var _ = this,
            $imgsToLoad = $( 'img[data-lazy]', _.$slider ),
            image,
            imageSource,
            imageSrcSet,
            imageSizes,
            imageToLoad;

        if ( $imgsToLoad.length ) {

            image = $imgsToLoad.first();
            imageSource = image.attr('data-lazy');
            imageSrcSet = image.attr('data-srcset');
            imageSizes  = image.attr('data-sizes') || _.$slider.attr('data-sizes');
            imageToLoad = document.createElement('img');

            imageToLoad.onload = function() {

                if (imageSrcSet) {
                    image
                        .attr('srcset', imageSrcSet );

                    if (imageSizes) {
                        image
                            .attr('sizes', imageSizes );
                    }
                }

                image
                    .attr( 'src', imageSource )
                    .removeAttr('data-lazy data-srcset data-sizes')
                    .removeClass('slick-loading');

                if ( _.options.adaptiveHeight === true ) {
                    _.setPosition();
                }

                _.$slider.trigger('lazyLoaded', [ _, image, imageSource ]);
                _.progressiveLazyLoad();

            };

            imageToLoad.onerror = function() {

                if ( tryCount < 3 ) {

                    /**
                     * try to load the image 3 times,
                     * leave a slight delay so we don't get
                     * servers blocking the request.
                     */
                    setTimeout( function() {
                        _.progressiveLazyLoad( tryCount + 1 );
                    }, 500 );

                } else {

                    image
                        .removeAttr( 'data-lazy' )
                        .removeClass( 'slick-loading' )
                        .addClass( 'slick-lazyload-error' );

                    _.$slider.trigger('lazyLoadError', [ _, image, imageSource ]);

                    _.progressiveLazyLoad();

                }

            };

            imageToLoad.src = imageSource;

        } else {

            _.$slider.trigger('allImagesLoaded', [ _ ]);

        }

    };

    Slick.prototype.refresh = function( initializing ) {

        var _ = this, currentSlide, lastVisibleIndex;

        lastVisibleIndex = _.slideCount - _.options.slidesToShow;

        // in non-infinite sliders, we don't want to go past the
        // last visible index.
        if( !_.options.infinite && ( _.currentSlide > lastVisibleIndex )) {
            _.currentSlide = lastVisibleIndex;
        }

        // if less slides than to show, go to start.
        if ( _.slideCount <= _.options.slidesToShow ) {
            _.currentSlide = 0;

        }

        currentSlide = _.currentSlide;

        _.destroy(true);

        $.extend(_, _.initials, { currentSlide: currentSlide });

        _.init();

        if( !initializing ) {

            _.changeSlide({
                data: {
                    message: 'index',
                    index: currentSlide
                }
            }, false);

        }

    };

    Slick.prototype.registerBreakpoints = function() {

        var _ = this, breakpoint, currentBreakpoint, l,
            responsiveSettings = _.options.responsive || null;

        if ( $.type(responsiveSettings) === 'array' && responsiveSettings.length ) {

            _.respondTo = _.options.respondTo || 'window';

            for ( breakpoint in responsiveSettings ) {

                l = _.breakpoints.length-1;

                if (responsiveSettings.hasOwnProperty(breakpoint)) {
                    currentBreakpoint = responsiveSettings[breakpoint].breakpoint;

                    // loop through the breakpoints and cut out any existing
                    // ones with the same breakpoint number, we don't want dupes.
                    while( l >= 0 ) {
                        if( _.breakpoints[l] && _.breakpoints[l] === currentBreakpoint ) {
                            _.breakpoints.splice(l,1);
                        }
                        l--;
                    }

                    _.breakpoints.push(currentBreakpoint);
                    _.breakpointSettings[currentBreakpoint] = responsiveSettings[breakpoint].settings;

                }

            }

            _.breakpoints.sort(function(a, b) {
                return ( _.options.mobileFirst ) ? a-b : b-a;
            });

        }

    };

    Slick.prototype.reinit = function() {

        var _ = this;

        _.$slides =
            _.$slideTrack
                .children(_.options.slide)
                .addClass('slick-slide');

        _.slideCount = _.$slides.length;

        if (_.currentSlide >= _.slideCount && _.currentSlide !== 0) {
            _.currentSlide = _.currentSlide - _.options.slidesToScroll;
        }

        if (_.slideCount <= _.options.slidesToShow) {
            _.currentSlide = 0;
        }

        _.registerBreakpoints();

        _.setProps();
        _.setupInfinite();
        _.buildArrows();
        _.updateArrows();
        _.initArrowEvents();
        _.buildDots();
        _.updateDots();
        _.initDotEvents();
        _.cleanUpSlideEvents();
        _.initSlideEvents();

        _.checkResponsive(false, true);

        if (_.options.focusOnSelect === true) {
            $(_.$slideTrack).children().on('click.slick', _.selectHandler);
        }

        _.setSlideClasses(typeof _.currentSlide === 'number' ? _.currentSlide : 0);

        _.setPosition();
        _.focusHandler();

        _.paused = !_.options.autoplay;
        _.autoPlay();

        _.$slider.trigger('reInit', [_]);

    };

    Slick.prototype.resize = function() {

        var _ = this;

        if ($(window).width() !== _.windowWidth) {
            clearTimeout(_.windowDelay);
            _.windowDelay = window.setTimeout(function() {
                _.windowWidth = $(window).width();
                _.checkResponsive();
                if( !_.unslicked ) { _.setPosition(); }
            }, 50);
        }
    };

    Slick.prototype.removeSlide = Slick.prototype.slickRemove = function(index, removeBefore, removeAll) {

        var _ = this;

        if (typeof(index) === 'boolean') {
            removeBefore = index;
            index = removeBefore === true ? 0 : _.slideCount - 1;
        } else {
            index = removeBefore === true ? --index : index;
        }

        if (_.slideCount < 1 || index < 0 || index > _.slideCount - 1) {
            return false;
        }

        _.unload();

        if (removeAll === true) {
            _.$slideTrack.children().remove();
        } else {
            _.$slideTrack.children(this.options.slide).eq(index).remove();
        }

        _.$slides = _.$slideTrack.children(this.options.slide);

        _.$slideTrack.children(this.options.slide).detach();

        _.$slideTrack.append(_.$slides);

        _.$slidesCache = _.$slides;

        _.reinit();

    };

    Slick.prototype.setCSS = function(position) {

        var _ = this,
            positionProps = {},
            x, y;

        if (_.options.rtl === true) {
            position = -position;
        }
        x = _.positionProp == 'left' ? Math.ceil(position) + 'px' : '0px';
        y = _.positionProp == 'top' ? Math.ceil(position) + 'px' : '0px';

        positionProps[_.positionProp] = position;

        if (_.transformsEnabled === false) {
            _.$slideTrack.css(positionProps);
        } else {
            positionProps = {};
            if (_.cssTransitions === false) {
                positionProps[_.animType] = 'translate(' + x + ', ' + y + ')';
                _.$slideTrack.css(positionProps);
            } else {
                positionProps[_.animType] = 'translate3d(' + x + ', ' + y + ', 0px)';
                _.$slideTrack.css(positionProps);
            }
        }

    };

    Slick.prototype.setDimensions = function() {

        var _ = this;

        if (_.options.vertical === false) {
            if (_.options.centerMode === true) {
                _.$list.css({
                    padding: ('0px ' + _.options.centerPadding)
                });
            }
        } else {
            _.$list.height(_.$slides.first().outerHeight(true) * _.options.slidesToShow);
            if (_.options.centerMode === true) {
                _.$list.css({
                    padding: (_.options.centerPadding + ' 0px')
                });
            }
        }

        _.listWidth = _.$list.width();
        _.listHeight = _.$list.height();


        if (_.options.vertical === false && _.options.variableWidth === false) {
            _.slideWidth = Math.ceil(_.listWidth / _.options.slidesToShow);
            _.$slideTrack.width(Math.ceil((_.slideWidth * _.$slideTrack.children('.slick-slide').length)));

        } else if (_.options.variableWidth === true) {
            _.$slideTrack.width(5000 * _.slideCount);
        } else {
            _.slideWidth = Math.ceil(_.listWidth);
            _.$slideTrack.height(Math.ceil((_.$slides.first().outerHeight(true) * _.$slideTrack.children('.slick-slide').length)));
        }

        var offset = _.$slides.first().outerWidth(true) - _.$slides.first().width();
        if (_.options.variableWidth === false) _.$slideTrack.children('.slick-slide').width(_.slideWidth - offset);

    };

    Slick.prototype.setFade = function() {

        var _ = this,
            targetLeft;

        _.$slides.each(function(index, element) {
            targetLeft = (_.slideWidth * index) * -1;
            if (_.options.rtl === true) {
                $(element).css({
                    position: 'relative',
                    right: targetLeft,
                    top: 0,
                    zIndex: _.options.zIndex - 2,
                    opacity: 0
                });
            } else {
                $(element).css({
                    position: 'relative',
                    left: targetLeft,
                    top: 0,
                    zIndex: _.options.zIndex - 2,
                    opacity: 0
                });
            }
        });

        _.$slides.eq(_.currentSlide).css({
            zIndex: _.options.zIndex - 1,
            opacity: 1
        });

    };

    Slick.prototype.setHeight = function() {

        var _ = this;

        if (_.options.slidesToShow === 1 && _.options.adaptiveHeight === true && _.options.vertical === false) {
            var targetHeight = _.$slides.eq(_.currentSlide).outerHeight(true);
            _.$list.css('height', targetHeight);
        }

    };

    Slick.prototype.setOption =
    Slick.prototype.slickSetOption = function() {

        /**
         * accepts arguments in format of:
         *
         *  - for changing a single option's value:
         *     .slick("setOption", option, value, refresh )
         *
         *  - for changing a set of responsive options:
         *     .slick("setOption", 'responsive', [{}, ...], refresh )
         *
         *  - for updating multiple values at once (not responsive)
         *     .slick("setOption", { 'option': value, ... }, refresh )
         */

        var _ = this, l, item, option, value, refresh = false, type;

        if( $.type( arguments[0] ) === 'object' ) {

            option =  arguments[0];
            refresh = arguments[1];
            type = 'multiple';

        } else if ( $.type( arguments[0] ) === 'string' ) {

            option =  arguments[0];
            value = arguments[1];
            refresh = arguments[2];

            if ( arguments[0] === 'responsive' && $.type( arguments[1] ) === 'array' ) {

                type = 'responsive';

            } else if ( typeof arguments[1] !== 'undefined' ) {

                type = 'single';

            }

        }

        if ( type === 'single' ) {

            _.options[option] = value;


        } else if ( type === 'multiple' ) {

            $.each( option , function( opt, val ) {

                _.options[opt] = val;

            });


        } else if ( type === 'responsive' ) {

            for ( item in value ) {

                if( $.type( _.options.responsive ) !== 'array' ) {

                    _.options.responsive = [ value[item] ];

                } else {

                    l = _.options.responsive.length-1;

                    // loop through the responsive object and splice out duplicates.
                    while( l >= 0 ) {

                        if( _.options.responsive[l].breakpoint === value[item].breakpoint ) {

                            _.options.responsive.splice(l,1);

                        }

                        l--;

                    }

                    _.options.responsive.push( value[item] );

                }

            }

        }

        if ( refresh ) {

            _.unload();
            _.reinit();

        }

    };

    Slick.prototype.setPosition = function() {

        var _ = this;

        _.setDimensions();

        _.setHeight();

        if (_.options.fade === false) {
            _.setCSS(_.getLeft(_.currentSlide));
        } else {
            _.setFade();
        }

        _.$slider.trigger('setPosition', [_]);

    };

    Slick.prototype.setProps = function() {

        var _ = this,
            bodyStyle = document.body.style;

        _.positionProp = _.options.vertical === true ? 'top' : 'left';

        if (_.positionProp === 'top') {
            _.$slider.addClass('slick-vertical');
        } else {
            _.$slider.removeClass('slick-vertical');
        }

        if (bodyStyle.WebkitTransition !== undefined ||
            bodyStyle.MozTransition !== undefined ||
            bodyStyle.msTransition !== undefined) {
            if (_.options.useCSS === true) {
                _.cssTransitions = true;
            }
        }

        if ( _.options.fade ) {
            if ( typeof _.options.zIndex === 'number' ) {
                if( _.options.zIndex < 3 ) {
                    _.options.zIndex = 3;
                }
            } else {
                _.options.zIndex = _.defaults.zIndex;
            }
        }

        if (bodyStyle.OTransform !== undefined) {
            _.animType = 'OTransform';
            _.transformType = '-o-transform';
            _.transitionType = 'OTransition';
            if (bodyStyle.perspectiveProperty === undefined && bodyStyle.webkitPerspective === undefined) _.animType = false;
        }
        if (bodyStyle.MozTransform !== undefined) {
            _.animType = 'MozTransform';
            _.transformType = '-moz-transform';
            _.transitionType = 'MozTransition';
            if (bodyStyle.perspectiveProperty === undefined && bodyStyle.MozPerspective === undefined) _.animType = false;
        }
        if (bodyStyle.webkitTransform !== undefined) {
            _.animType = 'webkitTransform';
            _.transformType = '-webkit-transform';
            _.transitionType = 'webkitTransition';
            if (bodyStyle.perspectiveProperty === undefined && bodyStyle.webkitPerspective === undefined) _.animType = false;
        }
        if (bodyStyle.msTransform !== undefined) {
            _.animType = 'msTransform';
            _.transformType = '-ms-transform';
            _.transitionType = 'msTransition';
            if (bodyStyle.msTransform === undefined) _.animType = false;
        }
        if (bodyStyle.transform !== undefined && _.animType !== false) {
            _.animType = 'transform';
            _.transformType = 'transform';
            _.transitionType = 'transition';
        }
        _.transformsEnabled = _.options.useTransform && (_.animType !== null && _.animType !== false);
    };


    Slick.prototype.setSlideClasses = function(index) {

        var _ = this,
            centerOffset, allSlides, indexOffset, remainder;

        allSlides = _.$slider
            .find('.slick-slide')
            .removeClass('slick-active slick-center slick-current')
            .attr('aria-hidden', 'true');

        _.$slides
            .eq(index)
            .addClass('slick-current');

        if (_.options.centerMode === true) {

            var evenCoef = _.options.slidesToShow % 2 === 0 ? 1 : 0;

            centerOffset = Math.floor(_.options.slidesToShow / 2);

            if (_.options.infinite === true) {

                if (index >= centerOffset && index <= (_.slideCount - 1) - centerOffset) {
                    _.$slides
                        .slice(index - centerOffset + evenCoef, index + centerOffset + 1)
                        .addClass('slick-active')
                        .attr('aria-hidden', 'false');

                } else {

                    indexOffset = _.options.slidesToShow + index;
                    allSlides
                        .slice(indexOffset - centerOffset + 1 + evenCoef, indexOffset + centerOffset + 2)
                        .addClass('slick-active')
                        .attr('aria-hidden', 'false');

                }

                if (index === 0) {

                    allSlides
                        .eq( _.options.slidesToShow + _.slideCount + 1 )
                        .addClass('slick-center');

                } else if (index === _.slideCount - 1) {

                    allSlides
                        .eq(_.options.slidesToShow)
                        .addClass('slick-center');

                }

            }

            _.$slides
                .eq(index)
                .addClass('slick-center');

        } else {

            if (index >= 0 && index <= (_.slideCount - _.options.slidesToShow)) {

                _.$slides
                    .slice(index, index + _.options.slidesToShow)
                    .addClass('slick-active')
                    .attr('aria-hidden', 'false');

            } else if (allSlides.length <= _.options.slidesToShow) {

                allSlides
                    .addClass('slick-active')
                    .attr('aria-hidden', 'false');

            } else {

                remainder = _.slideCount % _.options.slidesToShow;
                indexOffset = _.options.infinite === true ? _.options.slidesToShow + index : index;

                if (_.options.slidesToShow == _.options.slidesToScroll && (_.slideCount - index) < _.options.slidesToShow) {

                    allSlides
                        .slice(indexOffset - (_.options.slidesToShow - remainder), indexOffset + remainder)
                        .addClass('slick-active')
                        .attr('aria-hidden', 'false');

                } else {

                    allSlides
                        .slice(indexOffset, indexOffset + _.options.slidesToShow)
                        .addClass('slick-active')
                        .attr('aria-hidden', 'false');

                }

            }

        }

        if (_.options.lazyLoad === 'ondemand' || _.options.lazyLoad === 'anticipated') {
            _.lazyLoad();
        }
    };

    Slick.prototype.setupInfinite = function() {

        var _ = this,
            i, slideIndex, infiniteCount;

        if (_.options.fade === true) {
            _.options.centerMode = false;
        }

        if (_.options.infinite === true && _.options.fade === false) {

            slideIndex = null;

            if (_.slideCount > _.options.slidesToShow) {

                if (_.options.centerMode === true) {
                    infiniteCount = _.options.slidesToShow + 1;
                } else {
                    infiniteCount = _.options.slidesToShow;
                }

                for (i = _.slideCount; i > (_.slideCount -
                        infiniteCount); i -= 1) {
                    slideIndex = i - 1;
                    $(_.$slides[slideIndex]).clone(true).attr('id', '')
                        .attr('data-slick-index', slideIndex - _.slideCount)
                        .prependTo(_.$slideTrack).addClass('slick-cloned');
                }
                for (i = 0; i < infiniteCount  + _.slideCount; i += 1) {
                    slideIndex = i;
                    $(_.$slides[slideIndex]).clone(true).attr('id', '')
                        .attr('data-slick-index', slideIndex + _.slideCount)
                        .appendTo(_.$slideTrack).addClass('slick-cloned');
                }
                _.$slideTrack.find('.slick-cloned').find('[id]').each(function() {
                    $(this).attr('id', '');
                });

            }

        }

    };

    Slick.prototype.interrupt = function( toggle ) {

        var _ = this;

        if( !toggle ) {
            _.autoPlay();
        }
        _.interrupted = toggle;

    };

    Slick.prototype.selectHandler = function(event) {

        var _ = this;

        var targetElement =
            $(event.target).is('.slick-slide') ?
                $(event.target) :
                $(event.target).parents('.slick-slide');

        var index = parseInt(targetElement.attr('data-slick-index'));

        if (!index) index = 0;

        if (_.slideCount <= _.options.slidesToShow) {

            _.slideHandler(index, false, true);
            return;

        }

        _.slideHandler(index);

    };

    Slick.prototype.slideHandler = function(index, sync, dontAnimate) {

        var targetSlide, animSlide, oldSlide, slideLeft, targetLeft = null,
            _ = this, navTarget;

        sync = sync || false;

        if (_.animating === true && _.options.waitForAnimate === true) {
            return;
        }

        if (_.options.fade === true && _.currentSlide === index) {
            return;
        }

        if (sync === false) {
            _.asNavFor(index);
        }

        targetSlide = index;
        targetLeft = _.getLeft(targetSlide);
        slideLeft = _.getLeft(_.currentSlide);

        _.currentLeft = _.swipeLeft === null ? slideLeft : _.swipeLeft;

        if (_.options.infinite === false && _.options.centerMode === false && (index < 0 || index > _.getDotCount() * _.options.slidesToScroll)) {
            if (_.options.fade === false) {
                targetSlide = _.currentSlide;
                if (dontAnimate !== true && _.slideCount > _.options.slidesToShow) {
                    _.animateSlide(slideLeft, function() {
                        _.postSlide(targetSlide);
                    });
                } else {
                    _.postSlide(targetSlide);
                }
            }
            return;
        } else if (_.options.infinite === false && _.options.centerMode === true && (index < 0 || index > (_.slideCount - _.options.slidesToScroll))) {
            if (_.options.fade === false) {
                targetSlide = _.currentSlide;
                if (dontAnimate !== true && _.slideCount > _.options.slidesToShow) {
                    _.animateSlide(slideLeft, function() {
                        _.postSlide(targetSlide);
                    });
                } else {
                    _.postSlide(targetSlide);
                }
            }
            return;
        }

        if ( _.options.autoplay ) {
            clearInterval(_.autoPlayTimer);
        }

        if (targetSlide < 0) {
            if (_.slideCount % _.options.slidesToScroll !== 0) {
                animSlide = _.slideCount - (_.slideCount % _.options.slidesToScroll);
            } else {
                animSlide = _.slideCount + targetSlide;
            }
        } else if (targetSlide >= _.slideCount) {
            if (_.slideCount % _.options.slidesToScroll !== 0) {
                animSlide = 0;
            } else {
                animSlide = targetSlide - _.slideCount;
            }
        } else {
            animSlide = targetSlide;
        }

        _.animating = true;

        _.$slider.trigger('beforeChange', [_, _.currentSlide, animSlide]);

        oldSlide = _.currentSlide;
        _.currentSlide = animSlide;

        _.setSlideClasses(_.currentSlide);

        if ( _.options.asNavFor ) {

            navTarget = _.getNavTarget();
            navTarget = navTarget.slick('getSlick');

            if ( navTarget.slideCount <= navTarget.options.slidesToShow ) {
                navTarget.setSlideClasses(_.currentSlide);
            }

        }

        _.updateDots();
        _.updateArrows();

        if (_.options.fade === true) {
            if (dontAnimate !== true) {

                _.fadeSlideOut(oldSlide);

                _.fadeSlide(animSlide, function() {
                    _.postSlide(animSlide);
                });

            } else {
                _.postSlide(animSlide);
            }
            _.animateHeight();
            return;
        }

        if (dontAnimate !== true && _.slideCount > _.options.slidesToShow) {
            _.animateSlide(targetLeft, function() {
                _.postSlide(animSlide);
            });
        } else {
            _.postSlide(animSlide);
        }

    };

    Slick.prototype.startLoad = function() {

        var _ = this;

        if (_.options.arrows === true && _.slideCount > _.options.slidesToShow) {

            _.$prevArrow.hide();
            _.$nextArrow.hide();

        }

        if (_.options.dots === true && _.slideCount > _.options.slidesToShow) {

            _.$dots.hide();

        }

        _.$slider.addClass('slick-loading');

    };

    Slick.prototype.swipeDirection = function() {

        var xDist, yDist, r, swipeAngle, _ = this;

        xDist = _.touchObject.startX - _.touchObject.curX;
        yDist = _.touchObject.startY - _.touchObject.curY;
        r = Math.atan2(yDist, xDist);

        swipeAngle = Math.round(r * 180 / Math.PI);
        if (swipeAngle < 0) {
            swipeAngle = 360 - Math.abs(swipeAngle);
        }

        if ((swipeAngle <= 45) && (swipeAngle >= 0)) {
            return (_.options.rtl === false ? 'left' : 'right');
        }
        if ((swipeAngle <= 360) && (swipeAngle >= 315)) {
            return (_.options.rtl === false ? 'left' : 'right');
        }
        if ((swipeAngle >= 135) && (swipeAngle <= 225)) {
            return (_.options.rtl === false ? 'right' : 'left');
        }
        if (_.options.verticalSwiping === true) {
            if ((swipeAngle >= 35) && (swipeAngle <= 135)) {
                return 'down';
            } else {
                return 'up';
            }
        }

        return 'vertical';

    };

    Slick.prototype.swipeEnd = function(event) {

        var _ = this,
            slideCount,
            direction;

        _.dragging = false;
        _.swiping = false;

        if (_.scrolling) {
            _.scrolling = false;
            return false;
        }

        _.interrupted = false;
        _.shouldClick = ( _.touchObject.swipeLength > 10 ) ? false : true;

        if ( _.touchObject.curX === undefined ) {
            return false;
        }

        if ( _.touchObject.edgeHit === true ) {
            _.$slider.trigger('edge', [_, _.swipeDirection() ]);
        }

        if ( _.touchObject.swipeLength >= _.touchObject.minSwipe ) {

            direction = _.swipeDirection();

            switch ( direction ) {

                case 'left':
                case 'down':

                    slideCount =
                        _.options.swipeToSlide ?
                            _.checkNavigable( _.currentSlide + _.getSlideCount() ) :
                            _.currentSlide + _.getSlideCount();

                    _.currentDirection = 0;

                    break;

                case 'right':
                case 'up':

                    slideCount =
                        _.options.swipeToSlide ?
                            _.checkNavigable( _.currentSlide - _.getSlideCount() ) :
                            _.currentSlide - _.getSlideCount();

                    _.currentDirection = 1;

                    break;

                default:


            }

            if( direction != 'vertical' ) {

                _.slideHandler( slideCount );
                _.touchObject = {};
                _.$slider.trigger('swipe', [_, direction ]);

            }

        } else {

            if ( _.touchObject.startX !== _.touchObject.curX ) {

                _.slideHandler( _.currentSlide );
                _.touchObject = {};

            }

        }

    };

    Slick.prototype.swipeHandler = function(event) {

        var _ = this;

        if ((_.options.swipe === false) || ('ontouchend' in document && _.options.swipe === false)) {
            return;
        } else if (_.options.draggable === false && event.type.indexOf('mouse') !== -1) {
            return;
        }

        _.touchObject.fingerCount = event.originalEvent && event.originalEvent.touches !== undefined ?
            event.originalEvent.touches.length : 1;

        _.touchObject.minSwipe = _.listWidth / _.options
            .touchThreshold;

        if (_.options.verticalSwiping === true) {
            _.touchObject.minSwipe = _.listHeight / _.options
                .touchThreshold;
        }

        switch (event.data.action) {

            case 'start':
                _.swipeStart(event);
                break;

            case 'move':
                _.swipeMove(event);
                break;

            case 'end':
                _.swipeEnd(event);
                break;

        }

    };

    Slick.prototype.swipeMove = function(event) {

        var _ = this,
            edgeWasHit = false,
            curLeft, swipeDirection, swipeLength, positionOffset, touches, verticalSwipeLength;

        touches = event.originalEvent !== undefined ? event.originalEvent.touches : null;

        if (!_.dragging || _.scrolling || touches && touches.length !== 1) {
            return false;
        }

        curLeft = _.getLeft(_.currentSlide);

        _.touchObject.curX = touches !== undefined ? touches[0].pageX : event.clientX;
        _.touchObject.curY = touches !== undefined ? touches[0].pageY : event.clientY;

        _.touchObject.swipeLength = Math.round(Math.sqrt(
            Math.pow(_.touchObject.curX - _.touchObject.startX, 2)));

        verticalSwipeLength = Math.round(Math.sqrt(
            Math.pow(_.touchObject.curY - _.touchObject.startY, 2)));

        if (!_.options.verticalSwiping && !_.swiping && verticalSwipeLength > 4) {
            _.scrolling = true;
            return false;
        }

        if (_.options.verticalSwiping === true) {
            _.touchObject.swipeLength = verticalSwipeLength;
        }

        swipeDirection = _.swipeDirection();

        if (event.originalEvent !== undefined && _.touchObject.swipeLength > 4) {
            _.swiping = true;
            event.preventDefault();
        }

        positionOffset = (_.options.rtl === false ? 1 : -1) * (_.touchObject.curX > _.touchObject.startX ? 1 : -1);
        if (_.options.verticalSwiping === true) {
            positionOffset = _.touchObject.curY > _.touchObject.startY ? 1 : -1;
        }


        swipeLength = _.touchObject.swipeLength;

        _.touchObject.edgeHit = false;

        if (_.options.infinite === false) {
            if ((_.currentSlide === 0 && swipeDirection === 'right') || (_.currentSlide >= _.getDotCount() && swipeDirection === 'left')) {
                swipeLength = _.touchObject.swipeLength * _.options.edgeFriction;
                _.touchObject.edgeHit = true;
            }
        }

        if (_.options.vertical === false) {
            _.swipeLeft = curLeft + swipeLength * positionOffset;
        } else {
            _.swipeLeft = curLeft + (swipeLength * (_.$list.height() / _.listWidth)) * positionOffset;
        }
        if (_.options.verticalSwiping === true) {
            _.swipeLeft = curLeft + swipeLength * positionOffset;
        }

        if (_.options.fade === true || _.options.touchMove === false) {
            return false;
        }

        if (_.animating === true) {
            _.swipeLeft = null;
            return false;
        }

        _.setCSS(_.swipeLeft);

    };

    Slick.prototype.swipeStart = function(event) {

        var _ = this,
            touches;

        _.interrupted = true;

        if (_.touchObject.fingerCount !== 1 || _.slideCount <= _.options.slidesToShow) {
            _.touchObject = {};
            return false;
        }

        if (event.originalEvent !== undefined && event.originalEvent.touches !== undefined) {
            touches = event.originalEvent.touches[0];
        }

        _.touchObject.startX = _.touchObject.curX = touches !== undefined ? touches.pageX : event.clientX;
        _.touchObject.startY = _.touchObject.curY = touches !== undefined ? touches.pageY : event.clientY;

        _.dragging = true;

    };

    Slick.prototype.unfilterSlides = Slick.prototype.slickUnfilter = function() {

        var _ = this;

        if (_.$slidesCache !== null) {

            _.unload();

            _.$slideTrack.children(this.options.slide).detach();

            _.$slidesCache.appendTo(_.$slideTrack);

            _.reinit();

        }

    };

    Slick.prototype.unload = function() {

        var _ = this;

        $('.slick-cloned', _.$slider).remove();

        if (_.$dots) {
            _.$dots.remove();
        }

        if (_.$prevArrow && _.htmlExpr.test(_.options.prevArrow)) {
            _.$prevArrow.remove();
        }

        if (_.$nextArrow && _.htmlExpr.test(_.options.nextArrow)) {
            _.$nextArrow.remove();
        }

        _.$slides
            .removeClass('slick-slide slick-active slick-visible slick-current')
            .attr('aria-hidden', 'true')
            .css('width', '');

    };

    Slick.prototype.unslick = function(fromBreakpoint) {

        var _ = this;
        _.$slider.trigger('unslick', [_, fromBreakpoint]);
        _.destroy();

    };

    Slick.prototype.updateArrows = function() {

        var _ = this,
            centerOffset;

        centerOffset = Math.floor(_.options.slidesToShow / 2);

        if ( _.options.arrows === true &&
            _.slideCount > _.options.slidesToShow &&
            !_.options.infinite ) {

            _.$prevArrow.removeClass('slick-disabled').attr('aria-disabled', 'false');
            _.$nextArrow.removeClass('slick-disabled').attr('aria-disabled', 'false');

            if (_.currentSlide === 0) {

                _.$prevArrow.addClass('slick-disabled').attr('aria-disabled', 'true');
                _.$nextArrow.removeClass('slick-disabled').attr('aria-disabled', 'false');

            } else if (_.currentSlide >= _.slideCount - _.options.slidesToShow && _.options.centerMode === false) {

                _.$nextArrow.addClass('slick-disabled').attr('aria-disabled', 'true');
                _.$prevArrow.removeClass('slick-disabled').attr('aria-disabled', 'false');

            } else if (_.currentSlide >= _.slideCount - 1 && _.options.centerMode === true) {

                _.$nextArrow.addClass('slick-disabled').attr('aria-disabled', 'true');
                _.$prevArrow.removeClass('slick-disabled').attr('aria-disabled', 'false');

            }

        }

    };

    Slick.prototype.updateDots = function() {

        var _ = this;

        if (_.$dots !== null) {

            _.$dots
                .find('li')
                    .removeClass('slick-active')
                    .end();

            _.$dots
                .find('li')
                .eq(Math.floor(_.currentSlide / _.options.slidesToScroll))
                .addClass('slick-active');

        }

    };

    Slick.prototype.visibility = function() {

        var _ = this;

        if ( _.options.autoplay ) {

            if ( document[_.hidden] ) {

                _.interrupted = true;

            } else {

                _.interrupted = false;

            }

        }

    };

    $.fn.slick = function() {
        var _ = this,
            opt = arguments[0],
            args = Array.prototype.slice.call(arguments, 1),
            l = _.length,
            i,
            ret;
        for (i = 0; i < l; i++) {
            if (typeof opt == 'object' || typeof opt == 'undefined')
                _[i].slick = new Slick(_[i], opt);
            else
                ret = _[i].slick[opt].apply(_[i].slick, args);
            if (typeof ret != 'undefined') return ret;
        }
        return _;
    };

}));
!function(a){a.fn.isOnScreen=function(b){var c=this.outerHeight(),d=this.outerWidth();if(!d||!c)return!1;var e=a(window),f={top:e.scrollTop(),left:e.scrollLeft()};f.right=f.left+e.width(),f.bottom=f.top+e.height();var g=this.offset();g.right=g.left+d,g.bottom=g.top+c;var h={top:f.bottom-g.top,left:f.right-g.left,bottom:g.bottom-f.top,right:g.right-f.left};return"function"==typeof b?b.call(this,h):h.top>0&&h.left>0&&h.right>0&&h.bottom>0}}(jQuery);
/* mousetrap v1.6.3 craig.is/killing/mice */

(function(q,u,c){function v(a,b,g){a.addEventListener?a.addEventListener(b,g,!1):a.attachEvent("on"+b,g)}function z(a){if("keypress"==a.type){var b=String.fromCharCode(a.which);a.shiftKey||(b=b.toLowerCase());return b}return n[a.which]?n[a.which]:r[a.which]?r[a.which]:String.fromCharCode(a.which).toLowerCase()}function F(a){var b=[];a.shiftKey&&b.push("shift");a.altKey&&b.push("alt");a.ctrlKey&&b.push("ctrl");a.metaKey&&b.push("meta");return b}function w(a){return"shift"==a||"ctrl"==a||"alt"==a||
"meta"==a}function A(a,b){var g,d=[];var e=a;"+"===e?e=["+"]:(e=e.replace(/\+{2}/g,"+plus"),e=e.split("+"));for(g=0;g<e.length;++g){var m=e[g];B[m]&&(m=B[m]);b&&"keypress"!=b&&C[m]&&(m=C[m],d.push("shift"));w(m)&&d.push(m)}e=m;g=b;if(!g){if(!p){p={};for(var c in n)95<c&&112>c||n.hasOwnProperty(c)&&(p[n[c]]=c)}g=p[e]?"keydown":"keypress"}"keypress"==g&&d.length&&(g="keydown");return{key:m,modifiers:d,action:g}}function D(a,b){return null===a||a===u?!1:a===b?!0:D(a.parentNode,b)}function d(a){function b(a){a=
a||{};var b=!1,l;for(l in p)a[l]?b=!0:p[l]=0;b||(x=!1)}function g(a,b,t,f,g,d){var l,E=[],h=t.type;if(!k._callbacks[a])return[];"keyup"==h&&w(a)&&(b=[a]);for(l=0;l<k._callbacks[a].length;++l){var c=k._callbacks[a][l];if((f||!c.seq||p[c.seq]==c.level)&&h==c.action){var e;(e="keypress"==h&&!t.metaKey&&!t.ctrlKey)||(e=c.modifiers,e=b.sort().join(",")===e.sort().join(","));e&&(e=f&&c.seq==f&&c.level==d,(!f&&c.combo==g||e)&&k._callbacks[a].splice(l,1),E.push(c))}}return E}function c(a,b,c,f){k.stopCallback(b,
b.target||b.srcElement,c,f)||!1!==a(b,c)||(b.preventDefault?b.preventDefault():b.returnValue=!1,b.stopPropagation?b.stopPropagation():b.cancelBubble=!0)}function e(a){"number"!==typeof a.which&&(a.which=a.keyCode);var b=z(a);b&&("keyup"==a.type&&y===b?y=!1:k.handleKey(b,F(a),a))}function m(a,g,t,f){function h(c){return function(){x=c;++p[a];clearTimeout(q);q=setTimeout(b,1E3)}}function l(g){c(t,g,a);"keyup"!==f&&(y=z(g));setTimeout(b,10)}for(var d=p[a]=0;d<g.length;++d){var e=d+1===g.length?l:h(f||
A(g[d+1]).action);n(g[d],e,f,a,d)}}function n(a,b,c,f,d){k._directMap[a+":"+c]=b;a=a.replace(/\s+/g," ");var e=a.split(" ");1<e.length?m(a,e,b,c):(c=A(a,c),k._callbacks[c.key]=k._callbacks[c.key]||[],g(c.key,c.modifiers,{type:c.action},f,a,d),k._callbacks[c.key][f?"unshift":"push"]({callback:b,modifiers:c.modifiers,action:c.action,seq:f,level:d,combo:a}))}var k=this;a=a||u;if(!(k instanceof d))return new d(a);k.target=a;k._callbacks={};k._directMap={};var p={},q,y=!1,r=!1,x=!1;k._handleKey=function(a,
d,e){var f=g(a,d,e),h;d={};var k=0,l=!1;for(h=0;h<f.length;++h)f[h].seq&&(k=Math.max(k,f[h].level));for(h=0;h<f.length;++h)f[h].seq?f[h].level==k&&(l=!0,d[f[h].seq]=1,c(f[h].callback,e,f[h].combo,f[h].seq)):l||c(f[h].callback,e,f[h].combo);f="keypress"==e.type&&r;e.type!=x||w(a)||f||b(d);r=l&&"keydown"==e.type};k._bindMultiple=function(a,b,c){for(var d=0;d<a.length;++d)n(a[d],b,c)};v(a,"keypress",e);v(a,"keydown",e);v(a,"keyup",e)}if(q){var n={8:"backspace",9:"tab",13:"enter",16:"shift",17:"ctrl",
18:"alt",20:"capslock",27:"esc",32:"space",33:"pageup",34:"pagedown",35:"end",36:"home",37:"left",38:"up",39:"right",40:"down",45:"ins",46:"del",91:"meta",93:"meta",224:"meta"},r={106:"*",107:"+",109:"-",110:".",111:"/",186:";",187:"=",188:",",189:"-",190:".",191:"/",192:"`",219:"[",220:"\\",221:"]",222:"'"},C={"~":"`","!":"1","@":"2","#":"3",$:"4","%":"5","^":"6","&":"7","*":"8","(":"9",")":"0",_:"-","+":"=",":":";",'"':"'","<":",",">":".","?":"/","|":"\\"},B={option:"alt",command:"meta","return":"enter",
escape:"esc",plus:"+",mod:/Mac|iPod|iPhone|iPad/.test(navigator.platform)?"meta":"ctrl"},p;for(c=1;20>c;++c)n[111+c]="f"+c;for(c=0;9>=c;++c)n[c+96]=c.toString();d.prototype.bind=function(a,b,c){a=a instanceof Array?a:[a];this._bindMultiple.call(this,a,b,c);return this};d.prototype.unbind=function(a,b){return this.bind.call(this,a,function(){},b)};d.prototype.trigger=function(a,b){if(this._directMap[a+":"+b])this._directMap[a+":"+b]({},a);return this};d.prototype.reset=function(){this._callbacks={};
this._directMap={};return this};d.prototype.stopCallback=function(a,b){if(-1<(" "+b.className+" ").indexOf(" mousetrap ")||D(b,this.target))return!1;if("composedPath"in a&&"function"===typeof a.composedPath){var c=a.composedPath()[0];c!==a.target&&(b=c)}return"INPUT"==b.tagName||"SELECT"==b.tagName||"TEXTAREA"==b.tagName||b.isContentEditable};d.prototype.handleKey=function(){return this._handleKey.apply(this,arguments)};d.addKeycodes=function(a){for(var b in a)a.hasOwnProperty(b)&&(n[b]=a[b]);p=null};
d.init=function(){var a=d(u),b;for(b in a)"_"!==b.charAt(0)&&(d[b]=function(b){return function(){return a[b].apply(a,arguments)}}(b))};d.init();q.Mousetrap=d;"undefined"!==typeof module&&module.exports&&(module.exports=d);"function"===typeof define&&define.amd&&define(function(){return d})}})("undefined"!==typeof window?window:null,"undefined"!==typeof window?document:null);
// tipsy, facebook style tooltips for jquery
// version 1.0.0a
// (c) 2008-2010 jason frame [jason@onehackoranother.com]
// released under the MIT license
(function(e){function t(e,t){return typeof e=="function"?e.call(t):e}function n(t,n){this.$element=e(t);this.options=n;this.enabled=true;this.fixTitle()}n.prototype={show:function(){var n=this.getTitle();if(n&&this.enabled){var r=this.tip();r.find(".tipsy-inner")[this.options.html?"html":"text"](n);r[0].className="tipsy";r.remove().css({top:0,left:0,visibility:"hidden",display:"block"}).prependTo(document.body);var i=e.extend({},this.$element.offset(),{width:this.$element[0].offsetWidth,height:this.$element[0].offsetHeight});var s=r[0].offsetWidth,o=r[0].offsetHeight,u=t(this.options.gravity,this.$element[0]);var a;switch(u.charAt(0)){case"n":a={top:i.top+i.height+this.options.offset,left:i.left+i.width/2-s/2};break;case"s":a={top:i.top-o-this.options.offset,left:i.left+i.width/2-s/2};break;case"e":a={top:i.top+i.height/2-o/2,left:i.left-s-this.options.offset};break;case"w":a={top:i.top+i.height/2-o/2,left:i.left+i.width+this.options.offset};break}if(u.length==2){if(u.charAt(1)=="w"){a.left=i.left+i.width/2-15}else{a.left=i.left+i.width/2-s+15}}r.css(a).addClass("tipsy-"+u);r.find(".tipsy-arrow")[0].className="tipsy-arrow tipsy-arrow-"+u.charAt(0);if(this.options.className){r.addClass(t(this.options.className,this.$element[0]))}if(this.options.fade){r.stop().css({opacity:0,display:"block",visibility:"visible"}).animate({opacity:this.options.opacity})}else{r.css({visibility:"visible",opacity:this.options.opacity})}}},hide:function(){if(this.options.fade){this.tip().stop().fadeOut(function(){e(this).remove()})}else{this.tip().remove()}},fixTitle:function(){var e=this.$element;if(e.attr("title")||typeof e.attr("original-title")!="string"){e.attr("original-title",e.attr("title")||"").removeAttr("title")}},getTitle:function(){var e,t=this.$element,n=this.options;this.fixTitle();var e,n=this.options;if(typeof n.title=="string"){e=t.attr(n.title=="title"?"original-title":n.title)}else if(typeof n.title=="function"){e=n.title.call(t[0])}e=(""+e).replace(/(^\s*|\s*$)/,"");return e||n.fallback},tip:function(){if(!this.$tip){this.$tip=e('<div class="tipsy"></div>').html('<div class="tipsy-arrow"></div><div class="tipsy-inner"></div>')}return this.$tip},validate:function(){if(!this.$element[0].parentNode){this.hide();this.$element=null;this.options=null}},enable:function(){this.enabled=true},disable:function(){this.enabled=false},toggleEnabled:function(){this.enabled=!this.enabled}};e.fn.tipsy=function(t){function i(r){var i=e.data(r,"tipsy");if(!i){i=new n(r,e.fn.tipsy.elementOptions(r,t));e.data(r,"tipsy",i)}return i}function s(){var e=i(this);e.hoverState="in";if(t.delayIn==0){e.show()}else{e.fixTitle();setTimeout(function(){if(e.hoverState=="in")e.show()},t.delayIn)}}function o(){var e=i(this);e.hoverState="out";if(t.delayOut==0){e.hide()}else{setTimeout(function(){if(e.hoverState=="out")e.hide()},t.delayOut)}}if(t===true){return this.data("tipsy")}else if(typeof t=="string"){var r=this.data("tipsy");if(r)r[t]();return this}t=e.extend({},e.fn.tipsy.defaults,t);if(!t.on)this.each(function(){i(this)});if(t.trigger!="manual"){var u=t.on?"live":"bind",a=t.trigger=="hover"?"mouseenter":"focus",f=t.trigger=="hover"?"mouseleave":"blur";this[u](a,s)[u](f,o)}return this};e.fn.tipsy.defaults={className:null,delayIn:0,delayOut:0,fade:false,fallback:"",gravity:"n",html:false,live:false,offset:0,opacity:.8,title:"title",trigger:"hover"};e.fn.tipsy.elementOptions=function(t,n){return e.metadata?e.extend({},n,e(t).metadata()):n};e.fn.tipsy.autoNS=function(){return e(this).offset().top>e(document).scrollTop()+e(window).height()/2?"s":"n"};e.fn.tipsy.autoWE=function(){return e(this).offset().left>e(document).scrollLeft()+e(window).width()/2?"e":"w"};e.fn.tipsy.autoBounds=function(t,n){return function(){var r={ns:n[0],ew:n.length>1?n[1]:false},i=e(document).scrollTop()+t,s=e(document).scrollLeft()+t,o=e(this);if(o.offset().top<i)r.ns="n";if(o.offset().left<s)r.ew="w";if(e(window).width()+e(document).scrollLeft()-o.offset().left<t)r.ew="e";if(e(window).height()+e(document).scrollTop()-o.offset().top<t)r.ns="s";return r.ns+(r.ew?r.ew:"")}}})(jQuery);
$(function () {
  $(".accordion .content").not(".accordion.active .content").css("display", "none");
  $(".accordion.active .content").css("display", "block");
  // ADD UNIQUE ID TO EACH ACCORDION ON PAGE
  $.each($('.collapsibles-widget'), function (ind) {
    var currentCollapsibleWidget = $(this).closest('.collapsibles-widget').attr('id'),
      accordionClass = ' .accordion',
      accordionChildren = ' > .accordion',
      currentAccordion = currentCollapsibleWidget + accordionClass,
      currentAccordionChildren = currentCollapsibleWidget + currentAccordionChildren,
      toggleAttr = ' [data-toggle="collapsibles-widget__toggle"]',
      currentToggle = currentCollapsibleWidget + toggleAttr

    $(this).attr('id', 'accordion-' + parseInt(ind + 1));
    // IF MULTIPLE ACCORDIONS, CHANGE TEXT
    if ($(this).find('.accordion').length == 1) {
      $(this).find(toggleAttr).hide();
    } else if ($(this).find('.accordion').length > 1) {
      $(this).find(toggleAttr).text('Expand');
    }
  });
  // HANDLE CLICKS ON HEADERS
  $(".accordion .header").click(function () {
    $(this).parent(".accordion").toggleClass("active").children(".content").slideToggle('fast');
    $(".accordion.active .content").css("display", "block");
  });
  $(".accordion").children(".header").keydown(function (e) {
    if (e.keyCode === 32 || e.keyCode === 13) {
      $(this).parent(".accordion").toggleClass("active").children(".content").slideToggle('fast');
      return false
    }
  })
  // HANDLE EXPAND TOGGLES
  $(".collapsibles-widget .toggle-expand-collapse").on('click keypress', function (event) {
    var currentCollapsibleWidget = $(this).closest('.collapsibles-widget').attr('id'),
      currentCollapsibleWidget = '#' + currentCollapsibleWidget,
      contentClass = ' .content',
      content = currentCollapsibleWidget + contentClass,
      accordionClass = ' .accordion',
      currentAccordion = currentCollapsibleWidget + accordionClass,
      toggleClass = ' .toggle-expand-collapse',
      currentToggle = currentCollapsibleWidget + toggleClass,
      expandClass = ' .toggle-expand-collapse.expand',
      toggleAttr = ' [data-toggle="collapsibles-widget__toggle"]',
      currentToggle = currentCollapsibleWidget + toggleAttr,
      expandId = ' #collapsibles-widget__expand',
      currentExpand = currentCollapsibleWidget + expandId,
      collapseId = ' #collapsibles-widget__collapse',
      currentCollapse = currentCollapsibleWidget + collapseId,
      collapseClass = ' .toggle-expand-collapse.collapse',
      introText = ' .editableContent.summaryText',
      currentIntroText = currentCollapsibleWidget + introText,
      currentIntroTextHeight = $(currentIntroText).height(),
      omniHeight = $('#uninav').height();
    // EXPAND
    if ($(currentToggle).hasClass('expand')) {
      $(content).fadeIn('fast');
      $(currentAccordion).addClass('active');
      $(currentToggle).removeClass('expand');
      $(currentToggle).addClass('collapse');
      $(currentCollapse).fadeIn('fast');
      // FOCUS ON COLLAPSE TOGGLE
      $(currentCollapse).focus();
      // SCROLL TO TOP OF ID
      if ((currentAccordion).length > 1) {
        $(currentToggle).text('Collapse');
        $(currentToggle).attr('aria-label', 'collapse accordion');
      }
    }
    // HANDLE COLLAPSE TOGGLES
    else if ($(currentToggle).hasClass('collapse')) {
      $(currentAccordion).removeClass('active');
      $(content).css('display', 'none');
      $(currentExpand).fadeIn('fast');
      $(currentCollapse).fadeOut('fast');
      $(currentToggle).removeClass('collapse');
      $(currentToggle).addClass('expand');
      $(currentExpand).focus();
      if ((currentAccordion).length > 1) {
        $(currentToggle).text('Expand');
        $(currentToggle).attr('aria-label', 'expand accordion');
      }
    }
  });
});
// KEYS 🎹
function a11yClick(event) {
  if (event.type === 'click') {
    return true;
  } else if (event.type === 'keypress') {
    var code = event.charCode || event.keyCode;
    if ((code === 32) || (code === 13)) {
      return true;
    }
  } else {
    return false;
  }
}
;
$(document).ready(function () {
    $.each($('.photo-callout-widget__container'), function (ind) {
        $(this).attr('id', 'three-photo-callout-widget__container__' + parseInt(ind + 1));
        var currentWidgetContainer = $(this).closest('.photo-callout-widget__container').attr('id');
        console.log(currentWidgetContainer)
        var currentTotalNumberOfPhotos = $('#' + currentWidgetContainer + " img").size()
        console.log(currentWidgetContainer + currentTotalNumberOfPhotos);
        var loadMoreButtonButton = ' + .photo-callout-widget__button';
        var currentButton = '#' + currentWidgetContainer + loadMoreButtonButton;
        console.log("'" + currentButton + "'");
        var numberOfPhotoDivsToReveal = 3;


        if ($('#' + currentWidgetContainer).hasClass('photo-callout-widget__container--2-col')) {
            var photoIncrement = 6;
            var numberOfPhotoLinksToReveal = 2;

        }
        else {
            var photoIncrement = 3;

            var numberOfPhotoLinksToReveal = 3;

        }

        $('#' + currentWidgetContainer + ' > a:lt(' + photoIncrement + ')').show();
        $('#' + currentWidgetContainer + ' > div:lt(' + photoIncrement + ')').show();

        var buttonClickCounter = 0;
        console.log('number photos: ' + currentTotalNumberOfPhotos)
        if (currentTotalNumberOfPhotos > 6) {
            $(currentButton).show();
        }
        $('button.photo-callout-widget__button--no-paginate').hide();

        $(currentButton).click(function () {
            buttonClickCounter += 1;

            numberOfPhotoLinksToReveal = (numberOfPhotoLinksToReveal + 6);
            $('#' + currentWidgetContainer + ' > a:lt(' + numberOfPhotoLinksToReveal + ')').show();
            if (buttonClickCounter < 2) {
                $('#' + currentWidgetContainer + ' > a:lt(' + numberOfPhotoLinksToReveal + ')').show();
                $('#' + currentWidgetContainer + ' > div:lt(' + numberOfPhotoLinksToReveal + ')').show();
            } else if (buttonClickCounter == 2 && currentTotalNumberOfPhotos > 6) {
                $(currentButton).text('Load All')
                $('#' + currentWidgetContainer + ' > a:lt(' + numberOfPhotoLinksToReveal + ')').show();
                $('#' + currentWidgetContainer + ' > div:lt(' + numberOfPhotoLinksToReveal + ')').show();

            } else if (buttonClickCounter > 2) {
                $('#' + currentWidgetContainer + ' > a').show(0);
                $('#' + currentWidgetContainer + ' > div').show(0);
                $(currentButton).text('All Photos Loaded')
                $(currentButton).fadeOut(0);
            }
            var currentVisible = $('#' + currentWidgetContainer + ' .photo-callout-widget:visible').size()

            console.log('currentVisible: ' + currentWidgetContainer + ' ' + currentVisible + 'number of photos: ' + currentTotalNumberOfPhotos)


            if (currentVisible == currentTotalNumberOfPhotos) {
                console.log('currentVisible: ' + currentWidgetContainer + ' ' + currentVisible)
                console.log('number of photo links to reveal: ' + currentWidgetContainer + ' ' + numberOfPhotoLinksToReveal)
                $(currentButton).text('All Photos Loaded')
                $(currentButton).fadeOut(0);
            }
            console.log('number of photos: ' + currentWidgetContainer + ' ' + currentTotalNumberOfPhotos)
        });
    });
    objectFitFallBackForIe();
});
function resetbuttonClickCounterer() {
    var buttonClickCounter = 0;
    console.log('buttonClickCounter ' + buttonClickCounter);
}



// object-fit fallback for ie internet explorer
function objectFitFallBackForIe() {
    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE ");
    if (
        msie > 0 ||
        (!!navigator.userAgent.match(/Trident.*rv\:11\./) &&
            $(".photo-callout-widget__img").length)
    ) {
        $("img.photo-callout-widget__img").each(function () {
            var t = $(this),
                s = "url(" + t.attr("src") + ")",
                p = t.parent(),
                d = $("<div class='ie__fallback--object-fit'></div>");
            t.hide();
            p.append(d);
            d.css({
                height: 150,
                "background-size": "cover",
                "background-repeat": "no-repeat",
                "background-position": "center",
                "background-image": s
            });
        });
    }
}
;
$(function () {
  if ($(".career-block-widget__container").children().length > 1) {
    $(".career-block-widget__container").addClass(
      "career-block-widget__container--3-or-more-items"
    );
  }
  $.each($(".career-block-widget"), function (ind) {
    $(this).attr("id", "career-block-widget__" + parseInt(ind + 1));
    var id = $(this).attr("id");
    var careerCode = $(this)
      .find(".career-block-widget__career-code")
      .text()
      .replace(/\s/g, "");
    var URL =
      "https://services.onetcenter.org/ws/online/occupations/" +
      careerCode +
      "?client=chapman";
    var bindedOnSuccess = onSuccess.bind(this);
    $.ajax({
      type: "GET",
      url: URL,
      data: {
        get_param: "value"
      },
      async: true,
      dataType: "json",
      timeout: 10000,
      success: bindedOnSuccess
    });

    function onSuccess(data) {
      var $this = $(this);
      $this
        .find(".career-block-widget__text")
        .addClass("fadeInUp");
      $this.removeClass("career-block-widget--hidden");
      $this.addClass("career-block-widget--reveal");
      $this
        .find(".career-block-widget__title")
        .text(data.title)
        .addClass("fadeInUp");
      $this
        .find(".career-block-widget__body")
        .text(data.description)
        .addClass("fadeInUp");
      $this
        .find(".career-block-widget__scroll-indicator")
        .addClass("fadeInUp");
      addEllipsis();
      removeEllipsis();
    }
    // salary
    var bindSalary = setSalary.bind(this);
    var URLSalary =
      "https://services.onetcenter.org/ws/mnm/careers/" +
      careerCode +
      "/job_outlook?client=chapman";
    $.ajax({
      type: "GET",
      url: URLSalary,
      data: {
        get_param: "value"
      },
      async: true,
      dataType: "json",
      timeout: 10000,
      success: bindSalary
    });

    function setSalary(data) {
      var salary = data.salary.annual_median;
      var salaryMedianOver = data.salary.annual_median_over;
      var $this = $(this);
      if (typeof salary != "undefined") {
        $this
          .find(".career-block-widget__salary")
          .html(
            '<span class="career-block-widget__bold">' +
            cashmoney.format(salary) +
            "</span>" +
            " Median Salary"
          );
      } else {
        try {
          $this
            .find(".career-block-widget__salary")
            .html(
              '<span class="career-block-widget__bold">' +
              cashmoney.format(salaryMedianOver) +
              "</span>" +
              " Median Salary"
            );
        } finally { }
      }
    }
    var cashmoney = new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD"
    });
  });
});
$(function () {
  scrollHintTutorial();
});

function scrollHintTutorial() {
  var alreadyRanAnimation = true;
  $(".career-block-widget__scroll-indicator").mouseenter(function () {
    if (alreadyRanAnimation) {
      $(".career-block-widget__body").animate({
        scrollTop: 50
      }, 500);
      $(".career-block-widget__body").animate({
        scrollTop: 0
      }, 500);
      // $(".career-block-widget__scroll-indicator").addClass("fadeOut");
      alreadyRanAnimation = false;
    }
  });
}

function addEllipsis() {
  $(".career-block-widget").each(function () {
    $this = $(this).find(".career-block-widget__body");
    if ($this.text().length > 260) {
      $this.addClass("career-block-widget__body--scrollable");
      $this.addClass("career-block-widget__body--line-clamp");
    } else {
      $this.addClass("career-block-widget__body--no-scroll");
    }
  });
}

function removeEllipsis() {
  var overflowText = $(".career-block-widget__body");
  // TODO: improve scroll listener performance if this hack is even needed after widget redesign... a modal/expanding text/something else is probably a more elegant design solution for this recurring overflowing text problem on widgets
  $(overflowText).on("scroll", function () {
    if ($(this).scrollTop() >= 1) {
      $(this).addClass("career-block-widget__body--remove-line-clamp");
    } else {
      $(this).removeClass("career-block-widget__body--remove-line-clamp");
      $(this).addClass("career-block-widget__body--line-clamp");
    }
  });
}
;
$(function () {

	/* Degrees Program Nav Conditional Styling
	------------------------------------------------------------------------------------------------*/
	$(".anchorLinks a").each(function (index) {
	  if ($('.letter[name=' + $(this).text() + ']').length) {
	    $(this).css("text-decoration", "underline");
	  }
	});

});
$(function () {
    // NOTE: this script is used only for the main listing page /our-faculty/index.aspx, 
    // not for the school/dept specific listing pages. 
    if ( document.getElementById("mainFacultyDirectorySearch") != null ) {
        var devUrl = "//chapmanfaculty.dev.breilabs.com",
            prodUrl = "//" + window.location.hostname,
            page = 0,
            resultsPerPage = 20,
            totalPages = 0,
            scope = "_faculty/all",
            schoolFilter = "",
            departmentFilter = "",
            keywords = "",
            facultyFeedUrl = function () {
                return prodUrl + "/" +
                       scope + "/" +
                       (keywords ? keywords + "/" : "") +
                       page + "/" +
                       resultsPerPage + "?" +
                       (schoolFilter ? ("school=" + schoolFilter + "&") : '') +
                       (departmentFilter ? ("dept=" + departmentFilter + "&") : '') +
                       "callback=?";
            },
            applyUserInput = function () {
                // A little bit of session storage to rememeber form state
                if (window.sessionStorage) {
                    var directorySearchBox = document.getElementById("directorySearchBox"),
                        collegeFilterSelect = document.getElementById("collegeFilter"),
                        departmentFilterSelect = document.getElementById("departmentFilter");
                    // Search Box
                    if (sessionStorage.keywords) {
                        directorySearchBox.value = sessionStorage.keywords;
                    }
                    directorySearchBox.onkeyup = function (e) {
                        sessionStorage.keywords = this.value;
                    }
                    // All faculty checkbox session storage handled in onclick function
                    // College Filter
                    if (sessionStorage.collegeFilter) {    
                        collegeFilterSelect.value = sessionStorage.collegeFilter;
                    }
                    $(collegeFilterSelect).bind("change", function () {
                        sessionStorage.collegeFilter = collegeFilterSelect.value;
                    });
                    // Department Filter
                    if (sessionStorage.departmentFilter) {
                        departmentFilterSelect.value = sessionStorage.departmentFilter;
                    }
                    $(departmentFilterSelect).bind("change", function () {
                        sessionStorage.departmentFilter = departmentFilterSelect.value;
                    });
                }
                var  searchString = $("#directorySearchBox").val();
                schoolFilter = $("#collegeFilter option:selected").val();
                departmentFilter = $("#departmentFilter option:selected").val();
                if ($.trim(searchString) != "") {
                    scope = "_search";
                    keywords = $.trim(searchString);                    
                }
                else {
                    scope = "_faculty/all";
                    keywords = '';
                }
            },
            populateResults = function () {
                $.getJSON(facultyFeedUrl(), function (data) {
                    // remove old results
                    $(".searchResults .result").remove();
                    globalData = data;
                    for (var i = 0; i < data.length; i++) {
                        var v_photo;
                        var v_alt_text = 'no photo available';
                        if (!data[i].ThumbnailPhoto) {
                            v_photo = '/_files/level/img/unisex-silhouette110x130.gif';
                        }
                        else if (data[i].ThumbnailPhoto == '/') {
                            v_photo = '/_files/level/img/unisex-silhouette110x130.gif';
                        }
                        else if (data[i].ThumbnailPhoto == '') {
                            v_photo = '/_files/level/img/unisex-silhouette110x130.gif';
                        }
                        else {
                            v_photo = data[i].ThumbnailPhoto;
                            v_alt_text = 'Headshot photo of ' + data[i].FacFullName;
                        }
                        //put each title on own line
                        var splitTitles = data[i].AdditionalTitles;
                        if (splitTitles != '' && splitTitles != null) {
                            splitTitles = splitTitles.replace(/;/gi, "<br/>");					
                        }
                        var result = {
                            link: data[i].CascadePath ? '/our-faculty/' + data[i].CascadePath : '',
                            image: v_photo,
                            imageAltText: v_alt_text,
                            name: $.trim(data[i].FacFullName),
                            title: data[i].Rank,
                            additionalTitles: splitTitles,
                            affiliation: (function () {
                                var affiliation = [];
                                var cntr = 0;
                                var dept = '';
                                var school = '';
                                var prev_school = '';
                                var prev_dept = '';
                                var final_school_dept = '';
                                for (var j = 0; j < (data[i].Depts.length); j++) {
                                    cntr = cntr + 1;
                                    school = data[i].Depts[j].SchoolName ? data[i].Depts[j].SchoolName : '';
                                    if (data[i].Depts[j].DisplayDeptName != '' && data[i].Depts[j].DisplayDeptName != 'Conservatory of Music') {
                                        dept = data[i].Depts[j].FacGroupName ? data[i].Depts[j].DisplayDeptName + ', ' + data[i].Depts[j].FacGroupName: data[i].Depts[j].DisplayDeptName;
                                    }
                                    else {
                                         dept = data[i].Depts[j].FacGroupName ? data[i].Depts[j].FacGroupName : '';
                                    }
                                    if (cntr == 1) {
                                        prev_school = data[i].Depts[j].SchoolName ? data[i].Depts[j].SchoolName : '';
                                        prev_dept = dept;	 
                                    }
                                    else if (school == prev_school){
                                        if (prev_dept != '' && dept != '') {
                                            prev_dept = prev_dept + ", " + dept;
                                        }
                                        else if (prev_dept != '') {
                                            prev_dept = prev_dept;
                                        }
                                        else   {
                                            prev_dept = dept;
                                        }
                                    }
                                    else {
                                        if (prev_dept == '') {
                                            final_school_dept = prev_school;	
                                        }
                                        else {
                                            if (prev_school != '') {
                                                final_school_dept = prev_school + "; " + prev_dept; 
                                            }
                                            else {
                                                final_school_dept = prev_dept;
                                            }
                                        }
                                        affiliation.push(final_school_dept);
                                        prev_school = data[i].Depts[j].SchoolName ? data[i].Depts[j].SchoolName : '';
                                        prev_dept = dept;
                                    }
                                }
                                //one final output after last loop to get last "previous" variable:
                                if (prev_dept == '') {
                                    final_school_dept = prev_school;
                                }
                                else {
                                    if (prev_school != '') {
                                        final_school_dept = prev_school + "; " + prev_dept;
                                    }
                                    else {
                                        final_school_dept = prev_dept;
                                    }
                                }
                                affiliation.push(final_school_dept);
                                return affiliation.join("<br>");
                            })(),
                            phone: data[i].OfficePhone,
                            email: data[i].ChapEmail
                        }
                        $(".searchResults .pagingInfo").before(formatResult(result));
                    }
                    var rangeLower = data[data.length - 1] ? ((data[data.length - 1].CurrentPage * resultsPerPage) + 1) : 0,
                        rangeUpper = data[data.length - 1] ? ((data[data.length - 1].CurrentPage + 1) * data[data.length - 1].ResultsPerPage) : 0,
                        totalResults = data[data.length - 1] ? (data[data.length - 1].TotalResults) : 0;
                    if (rangeUpper > totalResults) {
                        rangeUpper = totalResults;
                    }
                    $(".rangeLower").html(rangeLower);
                    $(".rangeUpper").html(rangeUpper);
                    $(".totalResults").html(totalResults);
                    totalPages = data[data.length - 1] ? (data[data.length - 1].TotalPages) : 0;
                });
            };
        applyUserInput();
        populateResults();
        // Bind some functions to run automatically
        $('#directorySearchBox').on('keyup', debounce(fetchNewResults, 400));
        $('#collegeFilter').on('change', fetchNewResults);
        $('#departmentFilter').on('change', fetchNewResults);
        $('#allFaculty').on('click', clearFilters);
        $('.directorySearchButton').on('click', scrollToResultTop);
        //
        function fetchNewResults() {
            applyUserInput();
            page = 0;
            populateResults();
        }
        $(".directorySearchButton").click(fetchNewResults);
        $('#directorySearchBox').keypress(function (event) {
            if (event.which == 13) {
                jQuery(this).blur();
                jQuery('.directorySearchButton').focus().click();
            }
        });
        //is now a link with X (not a checkbox form field):
        function clearFilters() {
            document.getElementById("collegeFilter").selectedIndex = "0";
            document.getElementById("departmentFilter").selectedIndex = "0";
            document.getElementById("directorySearchBox").value = "";
            schoolFilter = "";
            departmentFilter = "";
            allFaculty = true;
            scope = "_faculty/all";
            keywords = "";
            if (window.sessionStorage) {
                var directorySearchBox = document.getElementById("directorySearchBox"),
                    collegeFilterSelect = document.getElementById("collegeFilter"),
                    departmentFilterSelect = document.getElementById("departmentFilter");
                directorySearchBox.value = "";
                collegeFilterSelect.value = "";
                departmentFilterSelect.value = "";
                sessionStorage.collegeFilter = "";
                sessionStorage.departmentFilter = "";
                sessionStorage.keywords = "";
                sessionStorage.allFaculty = true;
            }           
            applyUserInput();
            page = 0;
            populateResults();
        }
        $(".first").click(function () {
            if (page != 0) scrollToResultTop(populateResults, true);
            page = 0;
        });
        $(".previous").click(function () {
            if (page != 0) scrollToResultTop(populateResults, true);
            (page === 0) ? page = 0 : page -= 1;
        });
        $(".next").click(function () {
            if (page != totalPages) scrollToResultTop(populateResults, true);
            (page === totalPages) ? page = totalPages : page += 1;
        });
        $(".last").click(function () {
            if (page != totalPages) scrollToResultTop(populateResults, true);
            page = totalPages;
        });
        //
        function scrollToResultTop(callback, extra_fx) {
            if (extra_fx) {
                $('.result').fadeOut(600, function() {
                    $(this).show();
                });
            }
            $('html, body').stop().animate({
                'scrollTop': $('#searchResults').offset().top - 150
            }, 600, 'swing', callback);
        }
        //
        function formatResult(result) {
            var formattedResult =
                '<div class="result" itemscope itemtype="http://schema.org/Person">' +
                    (result.image ? '<div class="profilePicture"><img class="image" src="' + result.image + '"alt="' + result.imageAltText + '" itemprop="image"/></div>' : '') +
                    (result.name ? '<h2 class="name" itemprop="name">' + (result.link ? ('<a href="' + result.link) + '">' + result.name + '</a>' : result.name) + '</h2>' : '') +
                    (result.title ? '<div class="title" itemprop="jobTitle">' + result.title + '</div>' : '') +
                    (result.additionalTitles ? '<div class="additionalTitles" itemprop="jobTitle">' + result.additionalTitles + '</div>' : '') +
                    (result.affiliation ? '<div class="affiliation" itemprop="affiliation">' + result.affiliation + '</div>' : '') +
                    (result.email ? '<div class="email" itemprop="email"><a class="email" href="mailto:' + result.email + '" itemprop="email">' + result.email + '</a></div>' : '') +
                '</div>';
            return formattedResult;
        }
        // Returns a function, that, as long as it continues to be invoked, will not
        // be triggered. The function will be called after it stops being called for
        // N milliseconds. If `immediate` is passed, trigger the function on the
        // leading edge, instead of the trailing.
        function debounce(func, wait, immediate) {
            var timeout;
            return function() {
                var context = this, args = arguments;
                var later = function() {
                    timeout = null;
                    if (!immediate) func.apply(context, args);
                };
                var callNow = immediate && !timeout;
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
                if (callNow) func.apply(context, args);
            };
        };
    } // end of IF around test for mainFacultyDirectorySearch on page so only runs on main faculty listing page
});
$(function () {
    // NOTE: this script is 1 of 2 versions of Search for school/depts Faculty listings pages. 
    // Not for /our-faculty/index.aspx.
    // this version only offers All or Tenure filter options (not FULL TIME) and defaults to All.
		// Used by most schools (except Law and now Schmid College) 
    // eg /copa/faculty-directory.aspx.
    // this is from level/js/faculty.js in Cascade
    if ( document.getElementById("school_FacDirSearch_withoutFT") != null ) {
        var devUrl = "//chapmanfaculty.dev.breilabs.com",
            prodUrl = "//" + window.location.hostname,
            page = 0,
            resultsPerPage = 50,
            totalPages = 0,
            scope = (function () {
                if (window.sessionStorage) {
                    switch (sessionStorage.scope) {
                        case "_faculty/all":
                            $("#showAll").attr("checked", "checked");
                            break;
                        case "_faculty/tenure":
                            $("#tenure").attr("checked", "checked");
                            break;
                        default:
                            break;
                    }
                }
                var inputVal = $(".filter input:checked").val();
                switch (inputVal) {
                    case "Tenure":
                        return "_faculty/tenure";
                    default:
                        return "_faculty/all";
                }
            })(),
            schoolFilter = (function () {
                var extensionStart = window.location.pathname.lastIndexOf("."),
                    relativePath = window.location.pathname.substr(0, extensionStart).toLowerCase();
                switch (relativePath) {
                    case "/business/faculty-research/faculty-directory".toLowerCase():
                        return "SBE";
                    case "/communication/faculty-directory".toLowerCase():
                        return "SOC";
                    //return code has to match PeopleSoft school code so even though not CES publically, that is still their code
                    case "/education/contact-us/faculty-directory".toLowerCase():
                        return "CES";
                    case "/copa/faculty-directory".toLowerCase():
                        return "COPA";
                    case "/dodge/about/faculty-directory".toLowerCase():
                        return "CFMA";
                    case "/engineering/about/faculty/faculty-directory".toLowerCase():
                        return "SENG";
                    case "/law/law-faculty/index".toLowerCase():
                        return "SOL";
                    case "/scst/about/faculty-directory".toLowerCase():
                        return "COS";
                    case "/pharmacy/faculty-directory/index".toLowerCase():
                        return "SOP";   
                    case "/crean/faculty-directory".toLowerCase():
                        return "CHBS";
                    case "/wilkinson/about/faculty/faculty-directory".toLowerCase():
                        return "CHSS";                    
                    default:
                        return "";
                }
            })(),
            departmentFilter = (function () {
                var extensionStart = window.location.pathname.lastIndexOf("."),
                    relativePath = window.location.pathname.substr(0, extensionStart).toLowerCase();
                switch (relativePath) {                
                    case "/research/institutes-and-centers/economic-science-institute/about-us/faculty-directory".toLowerCase():
                        return "ESI";
                    case "/copa/dance/faculty-directory".toLowerCase():
                        return "DANC";
                    case "/copa/theatre/faculty-directory".toLowerCase():
                        return "THEA";
                    case "/wilkinson/art/faculty-directory".toLowerCase():
                        return "ARTS";
                    case "/communication/faculty-directory".toLowerCase():
                        return "COMM";
                    case "/engineering/faculty-directory".toLowerCase():
                        return "EECS";
                    case "/wilkinson/english/faculty-directory/index".toLowerCase():
                        return "ENGL";
                    case "/wilkinson/history/faculty-directory".toLowerCase():
                        return "HIST";
                    case "/crean/academic-programs/undergraduate-programs/bs-health-sciences/faculty".toLowerCase():
                        return "HSK";
                    case "/wilkinson/languages/faculty-directory".toLowerCase():
                        return "LANG";
                    case "/crean/academic-programs/graduate-programs/ma-marriage-family/faculty".toLowerCase():
                        return "MFT";
                    case "/crean/academic-programs/graduate-programs/physician-assistant/faculty".toLowerCase():
                        return "PAS";
                    //chgd from PHYS to PT May 2019:
                    case "/crean/academic-programs/graduate-programs/physical-therapy/faculty".toLowerCase():
                        return "PT"; 
                    case "/crean/academic-programs/graduate-programs/ms-communication-sciences-and-disorders/faculty".toLowerCase():
                        return "CSD";
                    case "/crean/academic-programs/graduate-programs/ms-athletic-training/faculty".toLowerCase():
                        return "ATPE";	
                    case "/crean/academic-programs/undergraduate-programs/ba-psychology/faculty".toLowerCase():
                        return "PSYC";
                    case "/crean/academic-programs/undergraduate-programs/bs-kinesiology/faculty".toLowerCase():
                        return "KINE";
                    case "/wilkinson/philosophy/faculty-directory".toLowerCase():
                        return "PHIL";
                    case "/wilkinson/political-science/faculty-directory".toLowerCase():
                        return "POLI";
                    case "/wilkinson/religious-studies/faculty/directory".toLowerCase():
                        return "RELI";
                    case "/wilkinson/sociology/faculty-directory".toLowerCase():
                        return "SOCI";
                    default:
                        return "";
                }
            })(),
            groupFilter = (function () {
                var extensionStart = window.location.pathname.lastIndexOf("."),
                    relativePath = window.location.pathname.substr(0, extensionStart).toLowerCase();
                switch (relativePath) {
                    case "/scst/crean-school-health/faculty-directory".toLowerCase():
                        return "SHLS";
                    case "/scst/about/earth-environmental-sciences/faculty-directory".toLowerCase():
                        return "SESS";
                    case "/scst/about/computational-sciences/faculty-directory".toLowerCase():
                        return "SOCS";
                    case "/copa/music/faculty-directory".toLowerCase():
                        return "MUSI";
                    default:
                        return "";
                }
            })(),
            keywords = "",
            facultyFeedUrl = function () {
                return prodUrl + "/" +
                       scope + "/" +
                       (keywords ? keywords + "/" : "") +
                       page + "/" +
                       resultsPerPage + "?" +
                       (schoolFilter ? ("school=" + schoolFilter + "&") : '') +
                       (departmentFilter ? ("dept=" + departmentFilter + "&") : '') +
                       (groupFilter ? ("facgroup=" + groupFilter + "&") : '') +
                       "callback=?";
            },
            populateResults = function () {
                //setting the sessionStorage.scope breaks app on some iPad minis. Remove for now
                //if (window.sessionStorage) {
                //    sessionStorage.scope = scope;
                //}
                $(".facultyList .facultyMember").addClass("old");
                $.getJSON(facultyFeedUrl(), function (data) {
                    for (var i = 0; i < data.length; i++) {
                        var v_photo;
                        var v_alt_text = 'no photo available';
                        if (!data[i].ThumbnailPhoto) {
                            v_photo = '/_files/level/img/unisex-silhouette.jpg';														
                        }
                        else if (data[i].ThumbnailPhoto == '/') {
                            v_photo = '/_files/level/img/unisex-silhouette.jpg';
                        }
                        else if (data[i].ThumbnailPhoto == '') {
                            v_photo = '/_files/level/img/unisex-silhouette.jpg';
                        }
                        else {
                            v_photo = data[i].ThumbnailPhoto;
                            v_alt_text = 'Headshot photo of ' + data[i].FacFullName;
                        }
                        
                        //put each title on own line
                        var splitTitles = data[i].AdditionalTitles;
                        if (splitTitles != '' && splitTitles != null) {
                            splitTitles = splitTitles.replace(/;/gi, "<br/>");
                        }                    
                        var result = {
                            link: data[i].CascadePath ? '/our-faculty/' + data[i].CascadePath : '',
                            image: v_photo,
                            imageAltText: v_alt_text,
                            firstName: $.trim(data[i].FacFirstName),
                            lastName: $.trim(data[i].FacLastName),
                            name: $.trim(data[i].FacFullName),
                            title: data[i].Rank,
                            additionalTitles: splitTitles,
                            affiliation: (function () {
                                var affiliation = [];
                                var cntr = 0;
                                var dept = '';
                                var school = '';
                                var prev_school = '';
                                var prev_dept = '';
                                var final_school_dept = '';
                                for (var j = 0; j < (data[i].Depts.length); j++) {
                                    cntr = cntr + 1;
                                    school = data[i].Depts[j].SchoolName ? data[i].Depts[j].SchoolName : '';
                                    if (data[i].Depts[j].DisplayDeptName != '' && data[i].Depts[j].DisplayDeptName != 'Conservatory of Music') {
                                        dept = data[i].Depts[j].FacGroupName ? data[i].Depts[j].DisplayDeptName + ', ' + data[i].Depts[j].FacGroupName: data[i].Depts[j].DisplayDeptName;
                                    }
                                    else {
                                        dept = data[i].Depts[j].FacGroupName ? data[i].Depts[j].FacGroupName : '';
                                    }
                                    //
                                    if (cntr == 1) {
                                        prev_school = data[i].Depts[j].SchoolName ? data[i].Depts[j].SchoolName : '';
                                        prev_dept = dept;	 
                                    }
                                    else if (school == prev_school){
                                        if (prev_dept != '' && dept != '') {
                                            prev_dept = prev_dept + ', ' + dept;
                                        }
                                        else if (prev_dept != '') {
                                            prev_dept = prev_dept;
                                        }
                                        else   {
                                            prev_dept = dept;
                                        }
                                    }
                                    else {
                                        if (prev_dept == '') {
                                            final_school_dept = prev_school;
                                        }
                                        else {
                                            if (prev_school != '') {
                                                final_school_dept = prev_school + "; " + prev_dept;
                                            }
                                            else {
                                                final_school_dept = prev_dept;
                                            }
                                        }                            
                                        affiliation.push(final_school_dept);
                                        prev_school = data[i].Depts[j].SchoolName ? data[i].Depts[j].SchoolName : '';
                                        prev_dept = dept;	
                                    }
                                }
                                //end FOR loop; 
                                //one final output after last loop to get last "previous" variable:
                                if (prev_dept == '') {
                                    final_school_dept = prev_school;
                                }
                                else {
                                    if (prev_school != '') {
                                        final_school_dept = prev_school + '; ' + prev_dept;
                                    }
                                    else {
                                        final_school_dept = prev_dept;
                                    }
                                }
                                affiliation.push(final_school_dept);
                                return affiliation.join('<div class="spacer"></div>');
                            })(),
                            // end affiliation
                            phone: data[i].OfficePhone,
                            email: data[i].ChapEmail,
                            specialty: (function () {
                                var spcl;
                                if (data[i].SpecialtyGrouping != 'none' && data[i].SpecialtyGrouping != '') {
                                    spcl = data[i].SpecialtyGrouping;
                                }
                                else {
                                    spcl = '';
                                }
                                return spcl;
                            })(),
                            id: data[i].DatatelId
                        } 
                        //end result
                        $(".pagingInfo").before(formatResult(result));
                    }
                    //end FOR loop
                    if (data.length) {
                        var rangeLower = (data[data.length - 1].CurrentPage * resultsPerPage) + 1,
                            rangeUpper = (data[data.length - 1].CurrentPage + 1) * data[data.length - 1].ResultsPerPage,
                            totalResults = data[data.length - 1].TotalResults;                        
                        if (rangeUpper > totalResults) {
                            rangeUpper = totalResults;
                        }
                        $(".rangeLower").html(rangeLower);
                        $(".rangeUpper").html(rangeUpper);
                        $(".totalResults").html(totalResults);
                        totalPages = data[data.length - 1].TotalPages;
                        $(".pagingNavigation").show();
                    }
                    else {
                        $(".rangeLower").html(0);
                        $(".rangeUpper").html(0);
                        $(".totalResults").html(0);
                        totalPages = 0;
                        $(".pagingNavigation").hide();
                    }
                    $(".facultyList .facultyMember.old").remove();
                });
            };
        populateResults();
        //
        $(".directorySearchButton").click(function (event) {            
            keywords = $.trim($("#directorySearchBox").val());
            if (keywords) {
                scope = scope.replace('_faculty/', '_facultysearch/');            
            }
            else {
                scope = scope.replace('_facultysearch/', '_faculty/');
            }
            page = 0;
            populateResults();
        });
        //
        $('#directorySearchBox').keypress(function (event) {
            if (event.which == 13) {
                jQuery(this).blur();
                jQuery('.directorySearchButton').focus().click();
            }
        });
        //
        $(".first").click(function () {
            page = 0;
            populateResults();
        });
        $(".previous").click(function () {
            (page === 0) ? page = 0 : page -= 1;
            populateResults();
        });
        $(".next").click(function () {
            (page === totalPages) ? page = totalPages : page += 1;
            populateResults();
        });
        $(".last").click(function () {
            page = totalPages;
            populateResults();
        });
        $("#showAll").bind("change", function () {
            scope = "_faculty/all";
        });
        $("#tenure").bind("change", function () {
            scope = "_facultysearch/tenure";
        });
        //
        function formatResult(result) {
            //var imgAlt = result.name ? 'Headshot photo of ' + result.name : 'Faculty Member Photo',
                formattedResult =
                    '<div class="facultyMember" itemscope itemtype="http://schema.org/Person">' +
                        (result.image ? '<div class="profilePicture"><img width="80px" src="' + result.image + '" itemprop="image" alt="' + result.imageAltText + '"></div>' : '') +
                        (result.name ? '<h2 class="name" itemprop="name">' + (result.link ? ('<a href="' + result.link) + '">' + result.name + '</a>' : result.name) + '</h2>' : '') +
                        (result.title ? '<div class="title" itemprop="jobTitle">' + result.title + '</div>' : '') +
                        (result.additionalTitles ? '<div class="additionalTitles" itemprop="jobTitle">' + result.additionalTitles + '</div>' : '') +
                        (result.specialty ? '<div class="specialty" itemprop="specialty">' + result.specialty + '</div>' : '') +
                        (result.affiliation ? '<div class="affiliation" itemprop="affiliation">' + result.affiliation + '</div>' : '') +                
                        (result.email ? '<div class="email" itemprop="email"><a href="mailto:' + result.email + '">' + result.email + '</a></div>' : '') +
                    '</div>';
            return formattedResult;
        }
    } // end of IF around test for deptFacultyDirectorySearch on page so only runs on school/dept faculty listing page(s)
});
$(function () {
    // NOTE: this script is 1 of 2 versions of Search for school/depts Faculty listings pages. 
    // Not for /our-faculty/index.aspx.
    // this version shows the Full-Time filter option and defaults to Full-Time.
		// Mostly used by Law School and now Schmid College.
    if ( document.getElementById("school_FacDirSearch_withFT") != null ) {
    var devUrl = "//chapmanfaculty.dev.breilabs.com",
        prodUrl = "//" + window.location.hostname,
        page = 0,
        resultsPerPage = 50,
        totalPages = 0,
        scope = (function () {
            if (window.sessionStorage) {
                switch (sessionStorage.scope) {
                    case "_faculty/full":
                        $("#fullTime").attr("checked", "checked");
                        break;
                    case "_faculty/all":
                        $("#showAll").attr("checked", "checked");
                        break;
                    case "_faculty/tenure":
                        $("#tenure").attr("checked", "checked");
                        break;
                    default:
                        break;
                }
            }
            var inputVal = $(".filter input:checked").val();
            switch (inputVal) {
                case "Tenure":
                    return "_faculty/tenure";
                case "Full Time":
                    return "full";
                case "All":
                    return "all";
                default:
                    return "_faculty/full";
            }
        })(),
        schoolFilter = (function () {
            var extensionStart = window.location.pathname.lastIndexOf("."),
                relativePath = window.location.pathname.substr(0, extensionStart).toLowerCase();

            switch (relativePath) {                
                case "/law/law-faculty/index".toLowerCase():
                    return "SOL";                
                case "/scst/about/faculty-directory".toLowerCase():
                		return "COS";
								default:
                    return "";
            }
        })(),
        //this script was copied from faculty.js. In that version departmentFilter and groupFilter were set thru Case logic.
        //rather than changing too much in this version of js, just set these two to blank and left rest of function as is.
        //not ideal. quick fix. should be done better later
        departmentFilter = "",
        groupFilter = "",
        keywords = "",
        facultyFeedUrl = function () {
            return prodUrl + "/" +
                   scope + "/" +
                   (keywords ? keywords + "/" : "") +
                   page + "/" +
                   resultsPerPage + "?" +
                   (schoolFilter ? ("school=" + schoolFilter + "&") : '') +
                   (departmentFilter ? ("dept=" + departmentFilter + "&") : '') +
                   (groupFilter ? ("facgroup=" + groupFilter + "&") : '') +
                   "callback=?";
        },
        populateResults = function () {
            //setting the sessionStorage.scope breaks app on some iPad minis. Remove for now
            //if (window.sessionStorage) {
            //    sessionStorage.scope = scope;
            //}

            $(".facultyList .facultyMember").addClass("old");
            $.getJSON(facultyFeedUrl(), function (data) {
                for (var i = 0; i < data.length; i++) {
                    var v_photo;
                    if (!data[i].ThumbnailPhoto) {
                        v_photo = '/_files/level/img/unisex-silhouette.jpg';
                    }
                    else if (data[i].ThumbnailPhoto == '/') {
                        v_photo = '/_files/level/img/unisex-silhouette.jpg';
                    }
                    else if (data[i].ThumbnailPhoto == '') {
                        v_photo = '/_files/level/img/unisex-silhouette.jpg';
                    }
                    else {
                        v_photo = data[i].ThumbnailPhoto;
                    }
                    //put each title on own line
                    var splitTitles = data[i].AdditionalTitles;
                    if (splitTitles != '' && splitTitles != null) {
                        splitTitles = splitTitles.replace(/;/gi, "<br/>"); 					
                    }                    
                    var result = {
                        link: data[i].CascadePath ? '/our-faculty/' + data[i].CascadePath : '',
                        image: v_photo,
                        firstName: $.trim(data[i].FacFirstName),
                        lastName: $.trim(data[i].FacLastName),
                        name: $.trim(data[i].FacFullName),
                        title: data[i].Rank,
                        additionalTitles: splitTitles,
                        affiliation: (function () {
                            var affiliation = [];
                            var cntr = 0;
                            var dept = '';
                            var school = '';
                            var prev_school = '';
                            var prev_dept = '';
                            var final_school_dept = '';
                            for (var j = 0; j < (data[i].Depts.length); j++) {
                                cntr = cntr + 1;
                                school = data[i].Depts[j].SchoolName ? data[i].Depts[j].SchoolName : '';
                                if (data[i].Depts[j].DisplayDeptName != '' && data[i].Depts[j].DisplayDeptName != 'Conservatory of Music') {
                                    dept = data[i].Depts[j].FacGroupName ? data[i].Depts[j].DisplayDeptName + ', ' + data[i].Depts[j].FacGroupName: data[i].Depts[j].DisplayDeptName;
                                }
                                else {
                                     dept = data[i].Depts[j].FacGroupName ? data[i].Depts[j].FacGroupName : '';
                                }
                                //
                                if (cntr == 1) {
                                    prev_school = data[i].Depts[j].SchoolName ? data[i].Depts[j].SchoolName : '';
                                    prev_dept = dept;	 
                                }
                                else if (school == prev_school){
                                    if (prev_dept != '' && dept != '') {
                                        prev_dept = prev_dept + ', ' + dept;
                                    }
                                    else if (prev_dept != '') {
                                        prev_dept = prev_dept;
                                    }
                                    else   {
                                        prev_dept = dept;
                                    }
                                }
                                else {
                                    if (prev_dept == '') {
                                        final_school_dept = prev_school;
                                    }
                                    else {
                                        if (prev_school != '') {
                                            final_school_dept = prev_school + "; " + prev_dept;
                                        }
                                        else {
                                            final_school_dept = prev_dept;
                                        }
                                    }
                                affiliation.push(final_school_dept);
                                prev_school = data[i].Depts[j].SchoolName ? data[i].Depts[j].SchoolName : '';
                                prev_dept = dept;	
                                }
                            }
                            //one final output after last loop to get last "previous" variable:
                            if (prev_dept == '') {
                                final_school_dept = prev_school;
                            }
                            else {
                                if (prev_school != '') {
                                    final_school_dept = prev_school + '; ' + prev_dept;
                                }
                                else {
                                    final_school_dept = prev_dept;
                                }
                            }
                            affiliation.push(final_school_dept);
                            return affiliation.join('<div class="spacer"></div>');
                        })(),
                        phone: data[i].OfficePhone,
                        email: data[i].ChapEmail,
                        specialty: (function () {
                                var spcl;
                                if (data[i].SpecialtyGrouping != 'none' && data[i].SpecialtyGrouping != '') {
                                    spcl = data[i].SpecialtyGrouping;
                                }
                                else {
                                    spcl = '';
                                }
                            return spcl;
                        })(),
                        id: data[i].DatatelId
                    }
                    $(".pagingInfo").before(formatResult(result));
                }
                if(data.length){
                    var rangeLower = (data[data.length - 1].CurrentPage * resultsPerPage) + 1,
                        rangeUpper = (data[data.length - 1].CurrentPage + 1) * data[data.length - 1].ResultsPerPage,
                        totalResults = data[data.length - 1].TotalResults;
                    
                    if (rangeUpper > totalResults) {
                        rangeUpper = totalResults;
                    }
                    $(".rangeLower").html(rangeLower);
                    $(".rangeUpper").html(rangeUpper);
                    $(".totalResults").html(totalResults);
                    totalPages = data[data.length - 1].TotalPages;
                    $(".pagingNavigation").show();
                }
                else{
                    $(".rangeLower").html(0);
                    $(".rangeUpper").html(0);
                    $(".totalResults").html(0);
                    totalPages = 0;
                    $(".pagingNavigation").hide();
                }
                $(".facultyList .facultyMember.old").remove();
            });
        };
    //
    populateResults();
    $(".directorySearchButton").click(function (event) {
        keywords = $.trim($("#directorySearchBox").val());
        if(keywords){
            scope = scope.replace('_faculty/', '_facultysearch/');            
        }
        else{
            scope = scope.replace('_facultysearch/', '_faculty/');
        }
        page = 0;
        populateResults();
    });
    //
    $('#directorySearchBox').keypress(function (event) {

        if (event.which == 13) {
            jQuery(this).blur();
            jQuery('.directorySearchButton').focus().click();
        }
    });
    //
    $(".first").click(function () {
        page = 0;
        populateResults();
    });
    $(".previous").click(function () {
        (page === 0) ? page = 0 : page -= 1;
        populateResults();
    });
    $(".next").click(function () {
        (page === totalPages) ? page = totalPages : page += 1;
        populateResults();
    });
    $(".last").click(function () {
        page = totalPages;
        populateResults();
    }); 
    //   
    $("#showAll").bind("change", function () {
        scope = "_faculty/all";
    });
    
    $("#fulltime").bind("change", function () {
        scope = "_facultysearch/full";
    });
    $("#tenure").bind("change", function () {
        scope = "_facultysearch/tenure";
    });
    //
    function formatResult(result) {
        var imgAlt = result.name ? 'Photo of ' + result.name : 'Faculty Member Photo',
            formattedResult =
            '<div class="facultyMember" itemscope itemtype="http://schema.org/Person">' +
                (result.image ? '<div class="profilePicture"><img width="80px" src="' + result.image + '" itemprop="image" alt="' + imgAlt + '"></div>' : '') +
                (result.name ? '<h2 class="name" itemprop="name">' + (result.link ? ('<a href="' + result.link) + '">' + result.name + '</a>' : result.name) + '</h2>' : '') +
                (result.title ? '<div class="title" itemprop="jobTitle">' + result.title + '</div>' : '') +
                (result.additionalTitles ? '<div class="additionalTitles" itemprop="jobTitle">' + result.additionalTitles + '</div>' : '') +
                (result.specialty ? '<div class="specialty" itemprop="specialty">' + result.specialty + '</div>' : '') +
                (result.affiliation ? '<div class="affiliation" itemprop="affiliation">' + result.affiliation + '</div>' : '') +                
                (result.email ? '<div class="email" itemprop="email"><a href="mailto:' + result.email + '">' + result.email + '</a></div>' : '') +
            '</div>';
        return formattedResult;
    }
} // end of IF around test for deptFacultyDirectorySearch on page so only runs on school/dept faculty listing page(s)
});
$(function () {

	/* Popluate featured item from xml generated from Cacade 
  ------------------------------------------------------------------------------------------------*/
  $.ajax({
    url: $(".featureFeed").text(),
    success: function (xml) {
      var image = $(xml).find("xml>system-data-structure>image>path").text(),
          date = $(xml).find("xml>system-data-structure>date").text(),
          month = date.split('-')[0],
          day = date.split('-')[1],
          year = date.split('-')[2],
          title = $(xml).find("xml>system-data-structure>title").text(),
          description = $(xml).find("xml>system-data-structure>description").text(),
          link = $(xml).find("xml>system-data-structure>link>link").text(),
          fileLink = $(xml).find("xml>system-data-structure>link>fileLink>path").text(),
          internalLink = $(xml).find("xml>system-data-structure>link>internalLink>path").text();

      if (internalLink !== '/') {
        link = internalLink+".aspx";
      }
      else if (fileLink !== '/') {
        link = fileLink;
      }

      // Image
      $(".newsEvents .featured .image").attr("src", image);
      $(".newsEvents .featured .image").attr("alt", title);

      // Date
      $(".newsEventsContent .featured .date .day").html(day);
      $(".newsEventsContent .featured .date .month").html(utils.toShortMonthName(month));
      $(".newsEventsContent .featured .date .year").html(year);

      // Title
      $(".newsEventsContent .featured .title").html('<a href="' + link + '">' + title + '</a>');

      // Description
      $(".newsEventsContent .featured .description").html(description);

      // Read More Link
      if (link != '') {
        $(".newsEventsContent .featured .readMore").html('<a href="' + link + '">Read More<span class="bullet"> &raquo;</span></a>');
      }
    },
    dataType: 'xml'
  });

});
/*
 * Fetch images from Chapman Flickr and Picasa feeds for widgets.
 */

var ChapmanImageFeeds = (function() {
    // Constants
    var CHAPMAN_BASE_FEED = 'https://www.chapman.edu/getFeed.ashx?name=';
    var YAHOO_API_ENDPOINT = 'https://query.yahooapis.com/v1/public/yql';
    var DEFAULT_PICASA_GALLERY_URL = 'https://get.google.com/albumarchive/105740368086394902806';

    // Global Attrs
    var $flickr = null;     // Need to select after document ready.
    var $picasa = null;     // Need to select after document ready.

    // Public Methods
    var initOnDocumentReady = function() {
        // Call this in onReady block.
        $flickr = $('.flickr-gallery');
        $picasa = $('.picasa-gallery');
    }

    var loadFlickrImages = function() {
        // Don't load if widget not present.
        if ( $flickr.length < 1 ) {
            return false;
        }

        var chapmanFeed = CHAPMAN_BASE_FEED + $flickr.data('feed');
        queryYahooApis(chapmanFeed, flickrCallback);
    };

    var loadPicasaImages = function() {
        // Don't load if widget not present.
        if ( $picasa.length < 1 ) {
            return false;
        }

        var chapmanFeed = CHAPMAN_BASE_FEED + $picasa.data('feed');
        queryYahooApis(chapmanFeed, picasaCallback);
    };

    // Private Methods
    var queryYahooApis = function(chapmanFeed, onSuccessCallback) {
        // Let's use JSONP: https://learn.jquery.com/ajax/working-with-jsonp/
        params = {
            q: "select * from xml where url='" + chapmanFeed +"'",
            format: "json",
            diagnostics: true
        };

        $.ajax({
            url: YAHOO_API_ENDPOINT,
            jsonp: "callback",
            dataType: "jsonp",
            data: params,
            success: onSuccessCallback
        });
    }

    var flickrCallback = function(data) {
        var $flul = $flickr.find('ul');
        var images = populateWidgetWithImages($flul, data);

        // Update See Full Gallery link.
        if ( images.length ) {
            var apiLink = data.query.results.feed.link[0].href;
            var userId = apiLink.split('userid=')[1].split('&')[0];
            $flickr.find(".more-link").attr("href", 'https://www.flickr.com/groups/' + userId);
        }
    };

    var picasaCallback = function(data) {
        var $pcul = $picasa.find('ul');
        var images = populateWidgetWithImages($pcul, data);
        var fullGalleryUrl = DEFAULT_PICASA_GALLERY_URL;

        // Update See Full Gallery Link.
        if ( data.query.results.feed.link.length >= 2 ) {
            fullGalleryUrl = data.query.results.feed.link[1].href;
        }

        $picasa.find(".more-link").attr("href", fullGalleryUrl);
    };

    var populateWidgetWithImages = function($parent, feedData) {
        var populatedImages = [];
        var results = feedData.query.results;

        if ( ! results ) {
            console.warn('Failed to get image feed results:', feedData);
            return populatedImages;
        }

        var feed = results.feed;
        var isPicasaFeed = feed.id.indexOf('picasa') !== -1;

        for (var i = 0; i < 4; i += 1) {
            var data = feed.entry[i];
            var href = data.link[0].href;
            var title = data.title;
            var src = data.link[data.link.length - 1].href;

            // If we ever support a third feed, we can come up with something less crude then.
            if ( isPicasaFeed ) {
                href = data.link[1].href;
                title = data.title.content;
                src = data.content.src;
            }

            var $item = $("<li>").append(
                $("<a>").attr({
                    "href": href,
                    "title": title,
                    "target": "_blank"
                }).append(
                    $("<img>").attr({
                        'src': src,
                        'alt': title
                    })
                )
            ).appendTo($parent);

            if ($item.find('img').width() >= 77) {
                $item.find('img').css({
                    'width': '100%'
                })
            } else {
                $item.find('img').css({
                    'height': '100%'
                })
            }

            populatedImages.push(data);
        }

        return populatedImages;
    }

    // Public API
    return {
        init: initOnDocumentReady,
        flickr: loadFlickrImages,
        picasa: loadPicasaImages
    };
})();


// On document ready.
$(function () {
    ChapmanImageFeeds.init();
    ChapmanImageFeeds.flickr();
    ChapmanImageFeeds.picasa();
});

$( document ).ready(function() {

	/* Funnel Toggle More Links
	 * 
	 * If the funnel boxes contain a list of links longer than 3 links, hide the rest and create a Show/Hide toggle
	------------------------------------------------------------------------------------------------*/
	$(".funnelBlock").each(function() {

		// CONFIGURABLE:
		var number_of_links_to_show = 3;

		// Find the link list
		var $list = $(this).find('.linkList');
		var $extraLinks = $list.find('li').slice(number_of_links_to_show);

		// Don't do anything if there aren't extra links
		if ($list.length == 0 || $extraLinks.length == 0) return;

		// Hide the extra links
		$extraLinks.hide();

		// Create the toggle button
		$toggleButton = $('<a href="javascript:void(0);" class="more">+ More</a>');
		$list.after($toggleButton);

		// Bind action to show/hide on toggle button click
		$toggleButton.on('click', function() {
			if ($(this).html() === "+ More") {
				$extraLinks.slideDown();
				$(this).html("- Less");
			} else {
				$extraLinks.slideUp();
				$(this).html("+ More");
			}
		});

	});

});
$(window).load(function (callback) {
  if ($('noscript').length) {
    renameNoscript();
    addiFrameTitle();
    addAriaHiddenToNoScript();


    try {
    } catch (ignore) { }
  }
  renameTempscript();

  function callIframe(url, callback) {
    $('iframe').attr('src', url);
    $('iframe').load(function () {
      renameNoscript(this);
    });
  }
});
function addAriaHiddenToNoScript() {
  if ($('noscript:contains("googletagmanager")').length > 0) {
    $("noscript").attr("aria-hidden", "true");
  }
  else if ($('noscript:contains("facebook")').length > 0) {
    $("noscript").attr("aria-hidden", "true");
  }
}
function renameNoscript() {
  $('noscript').replaceWith('<tempscript>' + $('noscript').html() + '</tempscript>');
  addiFrameTitle();
  renameTempscript();
}
function renameTempscript() {
  $('tempscript').replaceWith('<noscript>' + $('tempscript').html() + '</noscript>');
}
function addiFrameTitle() {
  var attr = $(this).attr('title');
  var noTitle = $('iframe').not('[title]');
  $("iframe").each(function () {
    $(noTitle).attr('title', 'Embedded content from external source');
    renameTempscript();
  });
}
renameNoscript();
addiFrameTitle();
function addEmptyAlt() {
	var missingAlt = $('img').not('[alt]');

	if ($(missingAlt.length)) {
		$(missingAlt).attr('alt', ' ');
	}
}

$(window).load(function() {
	addEmptyAlt();
});
$(function () {

	/* Left Nav 
  ------------------------------------------------------------------------------------------------*/

  $(".leftNav>ul>li:not(.active)>ul")
    .prev("a")
    .children(".plus")
    .css("visibility", "visible");

  $(".leftNav .plus").click(function (e) {
    e.preventDefault();
    $(this).toggleClass("open").parent("a").toggleClass("is-open").siblings("ul").slideToggle().toggleClass("is-open");
  });

  $(".leftNav .plus").keydown(function (e) {
    if (e.keyCode === 32 || e.keyCode === 13) {
      $(this).toggleClass("open").parent("a").toggleClass("is-open").siblings("ul").slideToggle().toggleClass("is-open");
      return false
    }
    return true
  });

  $(".leftNav ul li .show, .leftNav ul li .hide").click(function () {
    $(this).parent("li").toggleClass("active");
  });

  $(".leftNav").on("click", ".newbutton a", function () {
    recordOutboundLink($(this)[0], "Outbound-link_" + document.title.replace(" | Chapman University", ''), $(this).attr("href"), $(this).text());     
  });
});
function wrapIframes() {
  // There's some uncertainty about what elements are being targeted with this modification:
  // just embedded YouTube videos? All embedded videos? Blacklist below is added to avoid breaking
  // any existing behavior while providing some flexibility in more selectively applying wrap to
  // future embeds.
  var skipClass = '.no-video';

  // iframe Blacklist: Skip any iframes with the following selectors.
  var iframeSelectorBlacklist = [
    skipClass,                          // Class user can add in Cascade.
    '#no-video',                        // This is for existing cases (should use class above).
    '#map_frame',
    // Special cases can be added below:
    '#message-your-lawmaker-iframe'     // countable.us widget
  ];
  var notSelector = iframeSelectorBlacklist.join(', ');

  $('.editableContent iframe').not(notSelector).each(function() {
    // Point any YouTube videos to https address.
    this.src.replace('http://www.youtube.com','https://www.youtube.com');

    // Wrap in div.video tag to apply stylesheet rules which adds large bottom-padding. If
    // iframe has parent with skipClass tag then skip. This is for non-video embeds that may
    // dynamically generate iframes (like countable.us). It gives Cascade users themselves a
    // chance to avoid video styling by wrapping embed in <div class="no-video"> tag.
    // See https://github.com/chapmanu/cascade-assets/issues/87 for more details.
    var isWrappedWithNoVideoTag = $(this).parents(skipClass).length > 0;
    if ( ! isWrappedWithNoVideoTag ) {
      $(this).wrap('<div class="video"/>');
    }
  });
}

$(document).ready(function() {
  wrapIframes();

  // Added for links (really calls to action) in right col callouts:
  $(".rightColumn").on("click", ".newbutton a", function () {
    recordOutboundLink($(this)[0], "Outbound-link_" + document.title.replace(" | Chapman University", ''), $(this).attr("href"), $(this).text());
  });
});
$(function () {

	/* Masthead Class
  ------------------------------------------------------------------------------------------------*/
  if ($(".masthead").length && $(".masthead img").length) {
    $("#container").addClass("bigMasthead").removeClass("smallMasthead");
  }

});
$(function () {
    if ($('video#homepage-masthead__video').length) {
        fetchCuratorImages();
        var vid = $("video#homepage-masthead__video");
        $('.homepage video').removeAttr('controls');
        $('#homepage-masthead__pause-button ,#homepage-masthead__play-button').on('click keydown', function (event) {
            if (masthead_a11y(event)) {
                togglePlay();
            }
        });
        ieObjectFitFallback();
    }
});
function fetchCuratorImages() {
    $.ajax({
        url: 'https://api.curator.io/v1/feeds/ef183959-c3ad-4f2d-b90e-390c5d766fac/posts?api_key=11a4445f-6005-4040-9ff2-fd90d3aaa8a6',
        type: 'GET',
        success: manipulateCuratorImages,
        error: function (data, status, error) {
            console.log('%c ERROR: level/homepage-masthead.js - could not load curator.io images' + data.responseText.error, 'background: #222; color: #bada55');
            $('.homepage-masthead__photos img').addClass('fade-in');
        }
    });
}
function manipulateCuratorImages(data) {
    $('.homepage-masthead__photos img').each(function (index, value) {
        $(this).attr('src', data.posts[index].image);
        $(this).attr('data-post', data.posts[index].id);
    })
    $('.homepage-masthead__photos img').load(function () {
        var imageObj = $(this);
        if (!(imageObj.width() == 1 && imageObj.height() == 1)) {
            fadeInImages();
        }
    });
    $('img[alt=""]').each(function (index, value) {
        $(this).attr('alt', data.posts[index].text);
    })
}
function fadeInImages() {
    $('.homepage-masthead__photos img').addClass('fade-in');
}
function togglePlay() {
    if ($('video#homepage-masthead__video').length) {
        var vid = $("video#homepage-masthead__video");
        if ($(vid).get(0).paused) {
            vid.removeClass('homepage-masthead__play-video--paused')
            $('#homepage-masthead__play-button').hide();
            $('#homepage-masthead__pause-button').show();
            $(vid).trigger('play');
        } else {
            vid.addClass('homepage-masthead__video--paused')
            $('#homepage-masthead__pause-button').hide();
            $('#homepage-masthead__play-button').show();
            $(vid).trigger('pause');
        }
    }
}
function ieObjectFitFallback() {
    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE ");
    if (
        msie > 0 ||
        (!!navigator.userAgent.match(/Trident.*rv\:11\./) &&
            $(".homepage-masthead__photo-grid img").length)
    ) {
        $(".homepage-masthead__photo-grid img, .ie__homepage-masthead__photos img").each(function () {
            var t = $(this),
                s = "url(" + t.attr("src") + ")",
                p = t.parent(),
                d = $("<div class='ie__fallback--object-fit'></div>");
            t.hide();
            p.append(d);
            d.css({
                height: 150,
                "background-size": "cover",
                "background-repeat": "no-repeat",
                "background-position": "center",
                "background-image": s
            });
        });
        $('.ie__fallback-object-fit:first-of-type').css('height', '100%');
    }
}

// KEYS 🎹
var masthead_a11y = function masthead_a11yClick(event) {
    var code = event.charCode || event.keyCode,
        type = event.type;

    if (type === 'click') {
        return true;
    } else if (type === 'keydown') {
        if (code === 32 || code === 13) {
            event.preventDefault();
            return true;
        }
    } else {
        return false;
    }
};
$(function () {

	/* Mosaic border fix if only one slide
	------------------------------------------------------------------------------------------------*/
	if ($(".mosaic .slide").length < 2) {
	  $(".mosaic .block1 .border").css("border-width", "5px 5px 5px 5px");
	  $(".mosaic .block2 .border").css("border-width", "0 5px 5px 5px");
	}

});
$(function () {

	// Sync height of name bar buttons (only on desktop)

	$(window).resize(function () {
		sizeNameLinks();
	});
	$(function () {
		sizeNameLinks();
	})

	function sizeNameLinks() {

    nameLinks = $('.nameBarButtons li a');
    hasLong = false;

    nameLinks.each(function (index) {
      if ($(this).hasClass('long')) {
        hasLong = true;
      }
    });

    if (hasLong) {
      nameLinks.addClass('long');
    }

    if (nameLinks.length) {

      var nLheight = 0,
	        tmp = 0;

      nameLinks.each(function (index) {

        if (!$(this).hasClass('stuck')) {
          tmp = 0;
          tmp = $(this).height();
          if (tmp > nLheight) {
            nLheight = tmp;
          }
        } else {
          nLheight = $(this).css('height');
        }
      });

      nameLinks.addClass('stuck').css('height', nLheight);

    }

	}

	/* Name Bar
  ------------------------------------------------------------------------------------------------*/
  if ($(".nameBar").length) {
    $(".nameBar").removeClass("active");
    $(".toggleExpanded .button").click(function () {
      $(".expandedNameBar").slideToggle().parent(".nameBar").toggleClass("active");
    });

    verticallyAlignNamebarText = (function () {
      $(".nameBarButtons li a .text").each(function () {
        var maxCharacters = $(".oldie").length ? 28 : 29;
        if ($(this).text().length > maxCharacters) {
          $(this).parent('a').addClass("long");
        }
      });
    })();

  }

  if ($(".scrollGallery").length) {
    $(".nameBar .slideDescription").remove();
  }

});
$(function () {
  //used with News/Events widget in 2 and 3 Column Modular templates
  //
  // Make it work with old code.
  var pad2 = utils.pad2;

  // Convert feed category element to date object.
  // The newsfeed wants a datestamp that it can display in the feed. The feed provides one
  // as a category element. The problem is that sometimes category is a string with timestamp
  // value and sometimes an array where one of items is timestamp value. For more info, see
  // https://github.com/chapmanu/cascade-assets/issues/160
  var categoryToDatestamp = function (category) {
    // Sample category datestamp: "2017/03/06 (Mon)"
    var datestamp = null;

    // Type checking.
    var categoryIsArray = category instanceof Array;
    var categoryIsString = typeof category === "string";

    // Convert to date object. If value is not in expected format, it will result in
    // invalid date object.
    if (categoryIsString) {
      var dateStr = category.substring(0, 10);
      datestamp = new Date(dateStr);
    } else if (categoryIsArray) {
      // In the samples I looked at in production, the timestamp was always the first
      // element of the array. If not, will produce an invalid date object which
      // will be caught as invalid below.
      var dateStr = category[0].substring(0, 10);
      datestamp = new Date(dateStr);
    } else {
      console.warn(
        "Feed did not provide category as string or array as expected."
      );
      return null;
    }

    // Make sure we got a valid date object: https://stackoverflow.com/a/1353711/6763239
    var datestampIsValid = !isNaN(datestamp.getTime());
    if (datestampIsValid) {
      return datestamp;
    } else {
      return null;
    }
  };

  if ($(".news-events-widget").length) {
    /* Populate news from Wordpress RSS feed (converted to JSON with YQL)
    ------------------------------------------------------------------------------------------------*/

    //default is NewsAndStories:
    var newsFeedUrl =
      "https://www.chapman.edu/getFeed.ashx?name=newsNewsAndStories",
      newsYqlUrl = function () {
        return "https://social04.chapman.edu:4040/data?url=" + newsFeedUrl;
      },
      newsFeedOptions = $(".newsFeed").text();

    // TODO: It probably would have been much cleaner to put all these switched vars
    // here and below into a JS object keyed to the newsFeedOptions value.
    switch (newsFeedOptions) {
      case "Academics":
        newsFeedUrl = "http://www.chapman.edu/getFeed.ashx?name=newsAcademics";
        $(" .allNews").attr("href", "http://blogs.chapman.edu/cu-students");
        break;
      case "Admissions":
        newsFeedUrl = "http://www.chapman.edu/getFeed.ashx?name=newsAdmissions";
        $(" .allNews").attr("href", "http://blogs.chapman.edu/cu-students");
        break;
      case "ASBE":
        newsFeedUrl = "http://www.chapman.edu/getFeed.ashx?name=newsBusiness";
        $("  .allNews").attr("href", "http://blogs.chapman.edu/business");
        break;
      case "Commencement":
        newsFeedUrl =
          "http://www.chapman.edu/getFeed.ashx?name=newsCommencement";
        $("  .allNews").attr("href", "http://blogs.chapman.edu/commencement");
        break;
      case "COPA":
        newsFeedUrl = "http://www.chapman.edu/getFeed.ashx?name=newsCOPA";
        $(" .allNews").attr("href", "http://blogs.chapman.edu/copa");
        break;
      case "Crean":
        newsFeedUrl = "http://www.chapman.edu/getFeed.ashx?name=newsCrean";
        $(" .allNews").attr("href", "http://blogs.chapman.edu/crean");
        break;
      case "Dodge":
        newsFeedUrl = "http://www.chapman.edu/getFeed.ashx?name=newsDodge";
        $("  .allNews").attr("href", "http://blogs.chapman.edu/dodge");
        break;
      case "Education":
        newsFeedUrl = "http://www.chapman.edu/getFeed.ashx?name=newsEducation";
        $("  .allNews").attr("href", "http://blogs.chapman.edu/education");
        break;
      case "Information Systems":
        newsFeedUrl = "http://www.chapman.edu/getFeed.ashx?name=newsIST";
        $(" .allNews").attr(
          "href",
          "http://blogs.chapman.edu/information-systems"
        );
        break;
      case "Law":
        newsFeedUrl = "http://www.chapman.edu/getFeed.ashx?name=newsLaw";
        $(" .allNews").attr("href", "http://blogs.chapman.edu/law");
        break;
      case "Pharmacy":
        newsFeedUrl = "http://www.chapman.edu/getFeed.ashx?name=newsPharmacy";
        $(" .allNews").attr("href", "http://blogs.chapman.edu/pharmacy");
        break;
      case "Schmid":
        newsFeedUrl = "http://www.chapman.edu/getFeed.ashx?name=newsSCHMID";
        $(" .allNews").attr("href", "http://blogs.chapman.edu/scst");
        break;
      case "SOC":
        newsFeedUrl = "http://www.chapman.edu/getFeed.ashx?name=newsSOC";
        $(" .allNews").attr("href", "http://blogs.chapman.edu/communication");
        break;
      case "Students":
        newsFeedUrl = "http://www.chapman.edu/getFeed.ashx?name=newsStudents";
        $(" .allNews").attr("href", "http://blogs.chapman.edu/students");
        break;
      case "Thompson Policy Institute":
        newsFeedUrl =
          "http://www.chapman.edu/getFeed.ashx?name=newsThompsonInstitute";
        $(" .allNews").attr("href", "http://blogs.chapman.edu/tpi/");
        break;
      case "Wilkinson":
        newsFeedUrl = "http://www.chapman.edu/getFeed.ashx?name=newsWilkinson";
        $(" .allNews").attr("href", "http://blogs.chapman.edu/wilkinson");
        break;
      default:
        $(" .allNews").attr("href", "https://news.chapman.edu");
        break;
    }

    $(" .news .loading")
      .siblings(".story")
      .css("visibility", "hidden");

    var updateNewsWidget = function (data) {
      var newsData = data[0];
      if (newsData) {
        $(" .newsEvents").each(function () {
          $(this)
            .find(".news .story")
            .each(function (i) {
              var $this = $(this);
              if (newsData.item[i].pubDate) {
                //Month
                $this
                  .find(".date .month")
                  .html(
                    newsData.item[i].pubDate[0].split(" ")[2].toUpperCase()
                  );
                //Day
                $this
                  .find(".date .day")
                  .html(
                    pad2(
                      parseInt(newsData.item[i].pubDate[0].split(" ")[1], 10)
                    )
                  );
                //Year
                $this
                  .find(".date .year")
                  .html(newsData.item[i].pubDate[0].split(" ")[3]);
              }
              //Title
              $this.find(".title>a").html(newsData.item[i].title[0]);
              //Links
              $this.find(".title>a, .readMore").each(function () {
                $(this).attr("href", newsData.item[i].link[0]);
              });

              //Show News
              $(".news .loading")
                .hide()
                .siblings(".story")
                .css("visibility", "visible");
              $(".news .story").css("visibility", "visible");
            });
        });
      } else {
        $(".news").html(
          "<p>Oops, <a href='" +
          newsFeedUrl +
          "'>" +
          newsFeedUrl +
          "</a> appears to be unresponsive or is not returning anything to display at the moment.</p>"
        );
      }
    };

    $.getJSON(newsYqlUrl(), function (data) {
      updateNewsWidget(data);
    })
      .done(function (data) {
        updateNewsWidget(data);
      })
      .fail(function (data) {
        $(".news").html(
          "<p>There are no news articles found or the news feed is temporarily down.</p>"
        );
      });

    /* Populate events from RSS feeds (converted to JSON with YQL)
    ------------------------------------------------------------------------------------------------ */
    if ($(".events").length) {
      //sample: eventsFeedUrl = "https://25livepub.collegenet.com/calendars/calendar.7285.rss",
      var eventsFeedUrl = "http://www.chapman.edu/getFeed.ashx?name=events",
        eventsYqlUrl = function () {
          return "https://social04.chapman.edu:4040/data?url=" + eventsFeedUrl;
        },
        eventsFeedOptions = $(".eventsFeed").text();

      $(" .allEvents").attr("href", "https://events.chapman.edu/");

      switch (eventsFeedOptions) {
        case "ASBE":
          eventsFeedUrl =
            "http://www.chapman.edu/getFeed.ashx?name=eventBusiness";
          $(" .allEvents").attr(
            "href",
            "https://events.chapman.edu/?group_id=11,73,29,92,31,163,10"
          );
          break;
        case "CDC":
          eventsFeedUrl = "http://www.chapman.edu/getFeed.ashx?name=eventCDC";
          $(" .allEvents").attr(
            "href",
            "https://events.chapman.edu/?group_id=14"
          );
          break;
        case "COPA":
          eventsFeedUrl = "http://www.chapman.edu/getFeed.ashx?name=eventCOPA";
          $(" .allEvents").attr(
            "href",
            "https://events.chapman.edu/?group_id=21,56,105,75,89"
          );
          break;
        case "CREAN":
          eventsFeedUrl = "http://www.chapman.edu/getFeed.ashx?name=eventCREAN";
          $(" .allEvents").attr(
            "href",
            "https://events.chapman.edu/?group_id=44,108,103,155,152,27,37,114,38"
          );
          break;
        case "DANCE":
          eventsFeedUrl = "http://www.chapman.edu/getFeed.ashx?name=eventDANCE";
          $(" .allEvents").attr(
            "href",
            "https://events.chapman.edu/?group_id=105"
          );
          break;
        case "DODGE":
          eventsFeedUrl = "http://www.chapman.edu/getFeed.ashx?name=eventDODGE";
          $(" .allEvents").attr(
            "href",
            "https://events.chapman.edu/?group_id=23"
          );
          break;
        case "Education":
          eventsFeedUrl =
            "http://www.chapman.edu/getFeed.ashx?name=eventEducation";
          $(" .allEvents").attr(
            "href",
            "https://events.chapman.edu/?group_id=61,20"
          );
          break;
        case "Information Systems":
          eventsFeedUrl = "http://www.chapman.edu/getFeed.ashx?name=eventIST";
          $(" .allEvents").attr(
            "href",
            "https://events.chapman.edu/?group_id=133"
          );
          break;
        case "LAW":
          eventsFeedUrl = "http://www.chapman.edu/getFeed.ashx?name=eventLAW";
          $(" .allEvents").attr(
            "href",
            "https://events.chapman.edu/?group_id=28"
          );
          break;
        case "MUSIC":
          eventsFeedUrl = "http://www.chapman.edu/getFeed.ashx?name=eventMUSIC";
          $(" .allEvents").attr(
            "href",
            "https://events.chapman.edu/?group_id=56,89"
          );
          break;
        case "PHARMACY":
          eventsFeedUrl =
            "http://www.chapman.edu/getFeed.ashx?name=eventPHARMACY";
          $(" .allEvents").attr(
            "href",
            "https://events.chapman.edu/?group_id=141"
          );
          break;
        case "SCHMID":
          eventsFeedUrl =
            "http://www.chapman.edu/getFeed.ashx?name=eventSCHMID";
          $(" .allEvents").attr(
            "href",
            "https://events.chapman.edu/?group_id=36,101,120,22,123,129,112"
          );
          break;
        case "SOC":
          eventsFeedUrl = "http://www.chapman.edu/getFeed.ashx?name=eventSOC";
          $(" .allEvents").attr(
            "href",
            "https://events.chapman.edu/?group_id=146"
          );
          break;
        case "STUDENTS":
          eventsFeedUrl =
            "http://www.chapman.edu/getFeed.ashx?name=eventSTUDENTS";
          $(" .allEvents").attr(
            "href",
            "https://events.chapman.edu/?group_id=53,135,58,70,137,49,99,88,131,14,144,50,126,64,74,71,102,142,41,153,116,15,94,164,19,26,34,30,114,38,117"
          );
          break;
        case "THEATRE":
          eventsFeedUrl =
            "http://www.chapman.edu/getFeed.ashx?name=eventTHEATRE";
          $(" .allEvents").attr(
            "href",
            "https://events.chapman.edu/?group_id=75"
          );
          break;
        case "Thompson Policy Institute":
          eventsFeedUrl =
            "http://www.chapman.edu/getFeed.ashx?name=eventTHOMPSONPOLICY";
          $(" .allEvents").attr(
            "href",
            "https://events.chapman.edu/?group_id=191"
          );
          break;
        case "WILKINSON":
          eventsFeedUrl =
            "http://www.chapman.edu/getFeed.ashx?name=eventWILKINSON";
          $(" .allEvents").attr(
            "href",
            "https://events.chapman.edu/?group_id=84,115,60,86,146,87,134,115,128,160,110,82,132,45,43,40"
          );
          break;
        case "ESI":
          eventsFeedUrl = "http://www.chapman.edu/getFeed.ashx?name=eventESI";
          $(" .allEvents").attr(
            "href",
            "https://events.chapman.edu/?group_id=83"
          );
          break;
        default:
          eventsFeedUrl = "http://www.chapman.edu/getFeed.ashx?name=events";
          break;
      }

      var updateEventsWidget = function (data) {
        var eventsData = data[0];
        if (eventsData) {
          $(".newsEvents").each(function () {
            $(this)
              .find(".events .story")
              .each(function (i) {
                var $this = $(this);
                var rssitem;
                var maxloop;
                if (typeof eventsData.item.length == "undefined") {
                  rssitem = eventsData.item;
                  maxloop = 0;
                } else {
                  rssitem = eventsData.item[i];
                  maxloop = eventsData.item.length;
                }

                if (rssitem) {
                  // Title
                  $this.find(" .title>a").html(rssitem.title[0]);

                  // Links
                  $this.find(" .title>a, .readMore").each(function () {
                    $(this).attr("href", rssitem.link[0]);
                  });

                  // Datestamp: pubdate sometimes contained original but not current
                  // event date; use category field instead (has yyyy/mm/dd format)
                  var datestamp = categoryToDatestamp(rssitem.category[0]);
                  if (datestamp) {
                    var shortMonthName = utils.toShortMonthName(
                      datestamp.getMonth() + 1
                    );
                    $this.find(".date .month").html(shortMonthName);
                    $this.find(".date .day").html(pad2(datestamp.getDate()));
                    $this.find(".date .year").html(datestamp.getFullYear());
                  } else {
                    console.warn("Feed did not provide valid datestamp.");
                  }
                } else {
                  $(this).hide();
                }

                //Show Events
                $(" .events .loading")
                  .hide()
                  .siblings(".story")
                  .css("visibility", "visible");
                $(" .events .story").css("visibility", "visible");

                if (maxloop == i) {
                  return false;
                }
              });
          });
        } else {
          $(" .events").html(
            "<p>There are no events found (or <a href='" +
            eventsFeedUrl +
            "'>" +
            eventsFeedUrl +
            "</a> is temporarily down).</p>"
          );
          //$(".events").html("<p>No events found at this time.</p>");
        }
      };

      $(".events .loading")
        .siblings(".story")
        .css("visibility", "hidden");
      $.getJSON(eventsYqlUrl(), function (data) {
        updateEventsWidget(data);
      })
        .done(function (data) {
          updateEventsWidget(data);
        })
        .fail(function (data) {
          $(".events").html(
            "<p>There are no events found or the events feed is temporarily down).</p>"
          );
        });
    }

    /* Switch news events tabs
    ------------------------------------------------------------------------------------------------*/

    $(".newsEventsNav li").click(function () {
      var $this = $(this),
        i = $this.index();
      $this
        .addClass("active")
        .siblings()
        .removeClass("active");
      $this
        .parent(".newsEventsNav")
        .siblings(".newsEventsContent")
        .children("li:eq(" + i + ")")
        .addClass("active")
        .siblings()
        .removeClass("active");
      $ellipsis = $(".ellipsis");
      if ($ellipsis) $ellipsis.ellipsis();
    });

    $(".newsEventsNav li").keydown(function (e) {
      if (e.keyCode === 32 || e.keyCode === 13) {
        var $this = $(this),
          i = $this.index();
        $this
          .addClass("active")
          .siblings()
          .removeClass("active");
        $this
          .parent(".newsEventsNav")
          .siblings(".newsEventsContent")
          .children("li:eq(" + i + ")")
          .addClass("active")
          .siblings()
          .removeClass("active");
        $ellipsis = $(".ellipsis");
        if ($ellipsis) $ellipsis.ellipsis();
        return false;
      }
      return true;
    });

    $(".tabNav li").click(function () {
      var $this = $(this),
        i = $this.index();
      $this
        .addClass("active")
        .siblings()
        .removeClass("active");
      $this
        .parent(".tabNav")
        .siblings(".tabContent")
        .children("li:eq(" + i + ")")
        .addClass("active")
        .siblings()
        .removeClass("active");
      $ellipsis = $(".ellipsis");
      if ($ellipsis) $ellipsis.ellipsis();
    });

    // Apply user selected options
    (function () {
      var newsEventsOptions = [
        $(".newsEventsOptions").html(),
        $(".leftColumnNewsEventsOptions").html()
      ],
        $featureTab = [
          $(".main .newsEventsNav li:first-child"),
          $(".leftNav .newsEventsNav li:first-child")
        ],
        $newsTab = [
          $(".main .newsEventsNav li:nth-child(2)"),
          $(".leftNav .newsEventsNav li:nth-child(2)")
        ],
        $eventsTab = [
          $(".main .newsEventsNav li:nth-child(3)"),
          $(".leftNav .newsEventsNav li:nth-child(3)")
        ],
        $featureContent = [$(".main .featured"), $(".leftNav .featured")],
        $newsContent = [$(".main .news"), $(".leftNav .news")],
        $eventsContent = [$(".main .events"), $(".leftNav .events")],
        $newsEvents = [$(".main .newsEvents"), $(".leftNav .newsEvents")];

      for (var i = 0; i < newsEventsOptions.length; i++) {
        switch (newsEventsOptions[i]) {
          case "Featured - News - Events (Featured active)":
            break;
          case "Featured - News - Events (News active)":
            $featureTab[i].removeClass("active");
            $newsTab[i].addClass("active");
            $newsContent[i].parent("li").addClass("active");
            $featureContent[i].parent("li").removeClass("active");
            break;
          case "Featured - News - Events (Events active)":
            $featureTab[i].removeClass("active");
            $eventsTab[i].addClass("active");
            $eventsContent[i].parent("li").addClass("active");
            $featureContent[i].parent("li").removeClass("active");
            break;
          case "Featured - News (Featured active)":
            $eventsTab[i].hide();
            break;
          case "Featured - News (News active)":
            $featureTab[i].removeClass("active");
            $newsTab[i].addClass("active");
            $eventsTab[i].hide();
            $newsContent[i].parent("li").addClass("active");
            $featureContent[i].parent("li").removeClass("active");
            break;
          case "Featured - Events (Featured active)":
            $newsTab[i].hide();
            break;
          case "Featured - Events (Events active)":
            $featureTab[i].removeClass("active");
            $eventsTab[i].addClass("active");
            $newsTab[i].hide();
            $eventsContent[i].parent("li").addClass("active");
            $featureContent[i].parent("li").removeClass("active");
            break;
          case "News - Events (News active)":
            $featureTab[i].hide();
            $newsTab[i].addClass("active");
            $newsContent[i].parent("li").addClass("active");
            $featureContent[i].parent("li").removeClass("active");
            break;
          case "News - Events (Events active)":
            $featureTab[i].hide();
            $eventsTab[i].addClass("active");
            $eventsContent[i].parent("li").addClass("active");
            $featureContent[i].parent("li").removeClass("active");
            break;
          case "Featured Only":
            $newsTab[i].hide();
            $eventsTab[i].hide();
            break;
          case "News Only":
            $featureTab[i].hide();
            $eventsTab[i].hide();
            $newsTab[i].addClass("active");
            $newsContent[i].parent("li").addClass("active");
            $featureContent[i].parent("li").removeClass("active");
            break;
          case "Events Only":
            $featureTab[i].hide();
            $newsTab[i].hide();
            $eventsTab[i].addClass("active");
            $eventsContent[i].parent("li").addClass("active");
            $featureContent[i].parent("li").removeClass("active");
            break;
          case "Do Not Show":
            $newsEvents[i].hide();
            break;
          default:
            break;
        }
      }
    })();

    // Show today label if appropriate
    var todayLabel = function () {
      var today = new Date(),
        tomorrow = new Date(),
        month = [
          "JAN",
          "FEB",
          "MAR",
          "APR",
          "MAY",
          "JUN",
          "JUL",
          "AUG",
          "SEP",
          "OCT",
          "DEC"
        ];
      tomorrow.setDate(tomorrow.getDate() + 1);

      // Today
      $(".newsEvents .date").each(function (index) {
        if (
          today.getFullYear() ===
          parseInt(
            $(this)
              .children(".year")
              .html(),
            10
          )
        ) {
          if (
            month[today.getMonth()].toUpperCase() ===
            $(this)
              .children(".month")
              .html()
          ) {
            if (
              today.getDate() ===
              parseInt(
                $(this)
                  .children(".day")
                  .html(),
                10
              )
            ) {
              $(this)
                .siblings(".todayTomorrow")
                .children(".today")
                .css("display", "inline");
            }
          }
        }
      });

      // Tomorrow
      $(".newsEvents .date").each(function (index) {
        if (
          tomorrow.getFullYear() ===
          parseInt(
            $(this)
              .children(".year")
              .html(),
            10
          )
        ) {
          if (
            month[tomorrow.getMonth()].toUpperCase() ===
            $(this)
              .children(".month")
              .html()
          ) {
            if (
              tomorrow.getDate() ===
              parseInt(
                $(this)
                  .children(".day")
                  .html(),
                10
              )
            ) {
              $(this)
                .siblings(".todayTomorrow")
                .children(".tomorrow")
                .css("display", "inline");
            }
          }
        }
      });
    };

    $(".events .copy").each(function (index) {
      $(this).html($(this).text());
    });

    $ellipsis = $(".ellipsis");
    if ($ellipsis) $ellipsis.ellipsis();
  }
});

$(function () {
  if ($(".rssfeed").length) {
    addTitleToReadMoreText();
    addUniqueIdToEachPost();
  }
});

addTitleToReadMoreText();
addUniqueIdToEachPost();
function addTitleToReadMoreText() {
  $(".post").each(function () {
    var title = $(this).find('strong').text();
    var readMoreLink = $(this).find('a').text();

    if ($(readMoreLink).text().indexOf('read more')) {
      $(this).find('a').text(title)
    }
  });
}

function addUniqueIdToEachPost() {
  $.each($('.post'), function (ind) {
    var title = $(this).find('strong');
    $(this).attr('id', 'post-' + parseInt(ind + 1));
    $(title).attr('id', 'post-' + parseInt(ind + 1) + '__title');
    var titleID = $(this).find('strong').attr('id');
    var id = $(this).attr('id');
    $(this).find('a').attr('aria-labelledby', titleID)
  });
}
;
$(function() {

	// This adds placeholder support to browsers that wouldn't otherwise support it.
	jQuery.support.placeholder = false;
	test = document.createElement('input');
	if('placeholder' in test) jQuery.support.placeholder = true;

	// This adds 'placeholder' to the items listed in the jQuery .support object. 
	if(!$.support.placeholder) { 
	  var active = document.activeElement;
	  $(':text').focus(function () {
			if ($(this).attr('placeholder') != '' && $(this).val() == $(this).attr('placeholder')) {
			  $(this).val('').removeClass('hasPlaceholder');
			}
	  }).blur(function () {
			if ($(this).attr('placeholder') != '' && ($(this).val() == '' || $(this).val() == $(this).attr('placeholder'))) {
			  $(this).val($(this).attr('placeholder')).addClass('hasPlaceholder');
			}
	  });
	  $(':text').blur();
	  $(active).focus();
	  $('form:eq(0)').submit(function () {
	     $(':text.hasPlaceholder').val('');
	  });
	}

	// Placeholder text
  if (!Modernizr.input.placeholder) { ph(); }

  function ph() {
    $("input[placeholder]:not(.ph)").each(function () {
      var place = $(this).attr('placeholder');

      $(this).attr('value', place);

      $(this).bind('focus', function () {
          if ($.trim($(this).attr('value')) == place) {
              $(this).attr('value', "");
          }
      });
      $(this).bind('blur', function () {
          if ($.trim($(this).attr('value')) == '') {
              $(this).attr('value', place);
          }
      });

      $(this).addClass('ph');
    })
    $("textarea[placeholder]:not(.ph)").each(function () {
      var place = $(this).attr('placeholder');

      $(this).val(place);

      $(this).bind('focus', function () {
          if ($.trim($(this).val()) == place) {
              $(this).val("");
          }
      });
      $(this).bind('blur', function () {
          if ($.trim($(this).val()) == '') {
              $(this).val(place);
          }
      });

      $(this).addClass('ph');
    })
  }

});
/* MST April 2016: moved content over to main folder query-string.js, not this one in /level subfolder in github. that one also had old query string logic for Stages on previous iteration of homepage */
;
$(function () {

  /*
   * Adds additional requested functionality for new (v201611) slider masthead.
   *
   * Specifically, coordinates slide changes with changes in other elements.
   *
   * This isn't necessarily the best approach, but works most cleanly I
   * I think given existing design constraints.
   */
  var SliderMastheadMixins = (function () {
    // Globals
    var SLIDER_CONTAINER_SELECTOR = 'div.slider.version-201611';
    var HEADER_SELECTOR = SLIDER_CONTAINER_SELECTOR + ' div.column.header div.aligned';
    var SUBHEADER_SELECTOR = HEADER_SELECTOR + ' div.subheader';
    var isSliderMasthead = $(SLIDER_CONTAINER_SELECTOR).length > 0;
    var $header = null;
    var $subheader = null;

    // Public Methods
    var onStart = function (slider) {
      if (!isSliderMasthead) {
        return;
      }

      $header = $(HEADER_SELECTOR);
      $subheader = $(SUBHEADER_SELECTOR);
    };

    var beforeSlideChange = function (slider) {
      if (!isSliderMasthead) {
        return;
      }

      //using fadeTo because fadeIn/fadeOut will cause entire header to disappear/reappear 
      //completely from the layout when height is not a fixed value
      $header.fadeTo("slow", 0);
    };

    // This function sets the slide subtitles when switching slides
    // The first subtitle gets set in the Velocity format: _cascade/formats/level/Masthead
    var afterSlideChange = function (slider) {
      if (!isSliderMasthead) {
        return;
      }

      var currentSubtitle = currentSlideSubtitle(slider);

      // Always remove contents of div when switching slides
      $subheader.empty();

      // Only add html for subtitle if there is one
      if (currentSubtitle != '' && currentSubtitle !== undefined) {
        // Replace newline characters with html breaks so users can have multiline subtitles
        currentSubtitle = currentSubtitle.replace(/(\n)+/g, "<br/>");
        $subheader.append("<hr /><h3>" + currentSubtitle + "</h3>");
      }

      $header.fadeTo("slow", 1);
    };

    // Private Methods
    var currentSlideNumber = function (slider) {
      return slider.currentSlide;
    };

    var currentSlide = function (slider) {
      var currentSlide = slider.slides[currentSlideNumber(slider)];
      return $(currentSlide);
    };

    var currentSlideSubtitle = function (slider) {
      // Returns text of subtitle associated with current slide.
      var $currentSlide = currentSlide(slider);
      return $currentSlide.find('input.slideSubtitle').val();
    }

    // Public API
    return {
      onStart: onStart,
      beforeSlideChange: beforeSlideChange,
      afterSlideChange: afterSlideChange
    };
  })();

  /* Rotator
  ------------------------------------------------------------------------------------------------*/
  // FIXME: Please don't use this kind of logic for jQuery elements. This is what
  // selectors are for.
  if ($(".rotatorContainer").parent(".mosaic").length > 0) {
    $('.flexslider').flexslider({
      animation: "slide",
      touchSwipe: true,
      controlNav: false,
      pauseOnHover: true,
      pauseOnAction: true,
      pausePlay: true,
      randomize: false,
      slideshowSpeed: (function () {


        var setting = $(".slideOptions .speed").text(),
          speed = 10000;

        if (setting > 0) {
          speed = 1000 * setting;
        }

        return speed;
      })(),
      slideToStart: (function () {
        var number = $(".slideOptions .startingSlideNumber").text();

        if (number > 0) {
          return (number - 1);
        } else {
          return 0;
        }

      })(),
      slideshow: (function () {
        var isAuto = $(".slideOptions .autoRotate").text() ? true : false;

        return isAuto;

      })(),
      animationLoop: true,
      start: function (slider) {
        g_mySlider = slider;
        var currentSlide = slider.slides[slider.currentSlide],
          $currentSlide = $(currentSlide);

      },
      before: function (slider) {

      },
      after: function (slider) {
        var currentSlide = slider.slides[slider.currentSlide],
          $currentSlide = $(currentSlide);
      }
    });

    // Initialize tipsy for info rollovers
    $(".mosaic .info").each(function (index) {
      if (!$(this).attr("title")) {
        $(this).remove();
      }
    });

    $(".info").tipsy({
      fade: true,
      gravity: $.fn.tipsy.autoWE
    });

    $(".nameBar .slideDescription").remove();
  } else if ($(".rotatorContainer").parent(".rounded-slider").length > 0) {

    $('.rounded-slider').find('.red').html('<p>' + $(".rounded-slider .slide:first-child").attr('data-red') + '</p>');

    if ($(".rounded-slider .slide:first-child").attr('data-link')) {
      $('.rounded-slider').find('.red').append(
        $("<a>").attr({
          'href': $(".rounded-slider .slide:first-child").attr('data-link'),
          'title': 'Learn More'
        }).html("Learn More &raquo;")

      );
    } else {
      $('.rounded-slider').find('.red').addClass("no-link");
    }

    if (!$(".rounded-slider .info-container .red p").text()) {
      $(".rounded-slider .info-container .red").hide();
    }

    // FIXME: Code in callback methods below needs cleanup.
    $('.flexslider').flexslider({
      animation: "slide",
      touchSwipe: true,
      directionNav: false,
      pauseOnHover: true,
      pauseOnAction: true,
      pausePlay: true,
      randomize: false,
      slideshowSpeed: (function () {

        var setting = $(".slideOptions .speed").text(),
          speed = 10000;

        if (setting > 0) {
          speed = 1000 * setting;
        }

        return speed;
      })(),
      slideToStart: (function () {
        var number = $(".slideOptions .startingSlideNumber").text();

        if (number > 0) {
          return (number - 1);
        } else {
          return 0;
        }

      })(),
      slideshow: (function () {
        var isAuto = $(".slideOptions .autoRotate").text() ? true : false;

        return isAuto;

      })(),
      animationLoop: true,
      start: function (slider) {
        g_mySlider = slider;
        var currentSlide = slider.slides[slider.currentSlide],
          $currentSlide = $(currentSlide),
          red = $('.rounded-slider').find('.red');
        //blue = $('.rounded-slider').find('.blue');

        var caption = $currentSlide.attr('data-red');
        //var title = $currentSlide.attr('data-blue');
        var link = $currentSlide.attr('data-link');

        red.removeClass('no-link');

        if (caption) {
          red.html("<p>" + caption + "</p>");
        } else {
          red.hide();
        }
        //blue.html("<p>"+title+"</p>");

        if (link) {
          red.append(
            $("<a>").attr({
              'href': link,
              'title': 'Learn More'
            }).html("Learn More &raquo;")
          )
        } else {
          red.addClass('no-link');
        }

        SliderMastheadMixins.onStart(slider);
      },
      before: function (slider) {

        var red = $('.rounded-slider').find('.red');
        //    blue = $('.rounded-slider').find('.blue');

        red.find('a').remove();
        red.find('p').animate({
          opacity: 0
        }, 500);
        //    blue.find('p').animate({
        //        opacity: 0
        //    }, 500);

        SliderMastheadMixins.beforeSlideChange(slider);
      },
      after: function (slider) {
        g_mySlider = slider;
        var currentSlide = slider.slides[slider.currentSlide],
          $currentSlide = $(currentSlide),
          red = $('.rounded-slider').find('.red');
        //blue = $('.rounded-slider').find('.blue');

        var caption = $currentSlide.attr('data-red');
        //var title = $currentSlide.attr('data-blue');
        var link = $currentSlide.attr('data-link');

        red.removeClass('no-link');

        if (caption) {
          red.find('p').html(caption);
          red.show('');
        } else {
          red.hide('');
        }
        //blue.find('p').html(title);

        if (link) {
          red.append(
            $("<a>").attr({
              'href': link,
              'title': 'Learn More'
            }).css('opacity', 0).html("Learn More &raquo;")
          )
        } else {
          red.addClass('no-link');
        }

        red.find('p, a').animate({
          opacity: 1
        }, 500);
        //blue.find('p').animate({
        //    opacity: 1
        //}, 500);

        SliderMastheadMixins.afterSlideChange(slider);
      }
    });

    // Keep the slide arrows on the edge of the browser window

    // $(".flex-direction-nav li .next").offset({ left: $("#container").outerWidth() - 43 });
    // $(".flex-direction-nav li .prev").offset({ left: $("#container").offset().left });

    // $(window).bind("resize", function () {

    //     $(".flex-direction-nav li a.next").offset({ left: $("#container").outerWidth() - 43 });
    //     $(".flex-direction-nav li a.prev").offset({ left: $("#container").offset().left });

    // });

  } else {

    $('.flexslider').flexslider({
      animation: "slide",
      touchSwipe: true,
      controlNav: false,
      pauseOnHover: true,
      pauseOnAction: true,
      pausePlay: true,
      randomize: false,
      slideshowSpeed: (function () {

        var setting = $(".slideOptions .speed").text(),
          speed = 10000;

        if (setting > 0) {
          speed = 1000 * setting;
        }

        return speed;
      })(),
      slideToStart: (function () {
        var number = $(".slideOptions .startingSlideNumber").text();

        if (number > 0) {
          return (number - 1);
        } else {
          return 0;
        }

      })(),
      slideshow: (function () {
        var isAuto = $(".slideOptions .autoRotate").text() ? true : false;

        return isAuto;

      })(),
      animationLoop: true,
      start: function (slider) {
        g_mySlider = slider;
        var currentSlide = slider.slides[slider.currentSlide],
          $currentSlide = $(currentSlide);

        $(".flexslider .slides .slide").removeClass("active");
        $currentSlide.addClass("active");

        $(".blockOut").fadeOut();

        $(".slideDescription .centeredContent").html($currentSlide.children(".dataDescription").html());
        if (!$(".slideDescription .centeredContent").html()) {
          $(".slideDescription").addClass("visuallyhidden");
        } else {
          $(".slideDescription").removeClass("visuallyhidden");
        }
      },
      before: function (slider) {

        $(".blockOut").stop().fadeIn();
        $(".slide").stop().fadeTo(250, .2, function () {});

      },
      after: function (slider) {
        var currentSlide = slider.slides[slider.currentSlide],
          $currentSlide = $(currentSlide);

        $(".blockOut").stop().fadeOut("slow");
        $(".slide").stop().fadeTo(500, 1, function () {});


        $(".flexslider .slides .slide").removeClass("active");
        $currentSlide.addClass("active");

        $(".slideDescription .centeredContent").html($currentSlide.children(".dataDescription").html());
        if (!$(".slideDescription .centeredContent").html()) {
          $(".slideDescription").addClass("visuallyhidden");
        } else {
          $(".slideDescription").removeClass("visuallyhidden");
        }
      }
    });

    // Keep the slide arrows on the edge of the browser window

    // $(".flex-direction-nav li .next").offset({ left: $("#container").outerWidth() - 43 });
    // $(".flex-direction-nav li .prev").offset({ left: $("#container").offset().left });

    // $(window).bind("resize", function () {

    //     $(".flex-direction-nav li a.next").offset({ left: $("#container").outerWidth() - 43 });
    //     $(".flex-direction-nav li a.prev").offset({ left: $("#container").offset().left });

    // });

  }

  // Remove :focus outline from rotator nav arrows
  $(".flex-direction-nav li a").each(function () {
    $(this).attr("hideFocus", "true").css("outline", "none");
  });

  // Pause the slider once the user interacts with the slider
  $(".flex-direction-nav li a").on("click", function (event) {
    g_mySlider.pause();
    g_mySlider.resume = function () {};
  });

  /* Mini-Rotator Code
  ------------------------------------------------------------------------------------------------*/
  if ($(".miniRotator").length) {

    $(".miniRotatorContainer").jcarousel({
      start: (function () {
        var number = $(".slideOptions .startingSlideNumber").text();
        //mst added to default to slide 1, otherwise when blank, in old/new mini rotators pushing slide1 to position 2:
        if (number == "") {
          number = 1;
        }
        return (number * 1);

      })(),
      auto: (function () {
        var speed = 10,
          speedSetting = $(".slideOptions .speed").text(),
          isAuto = $(".slideOptions .autoRotate").text() ? true : false;

        if (isAuto) {
          if (speedSetting > 0) {
            speed = speedSetting;
          }
        } else {
          speed = 0;
        }

        return speed;

      })(),
      scroll: 1,
      wrap: "circular",
      buttonNextHTML: null,
      buttonPrevHTML: null,
      initCallback: function (carousel) {
        carousel.clip.hover(function () {
          carousel.stopAuto();
        }, function () {
          carousel.startAuto();
        });

        $('.miniRotatorNav .next').bind('click', function () {
          carousel.next();
          return false;
        });

        $('.miniRotatorNav .prev').bind('click', function () {
          carousel.prev();
          return false;
        });
      }
    });
  }

});
$(function () {

	/* Custom Scroll Bar
	------------------------------------------------------------------------------------------------*/

	$('.scrollGallery').each(function () {

		$(this).jScrollPane({

			showArrows: $(this).is('.arrow'),
			horizontalDragMinWidth: 65,
			horizontalDragMaxWidth: 65

		});

		var api = $(this).data('jsp');
		var throttleTimeout;
		$(window).bind('resize',

		function () {

			if ($.browser.msie) {
			  // IE fires multiple resize events while you are dragging the browser window which
			  // causes it to crash if you try to update the scrollpane on every one. So we need
			  // to throttle it to fire a maximum of once every 50 milliseconds...
			  if (!throttleTimeout) {
			    throttleTimeout = setTimeout(

			    function () {
			      api.reinitialise();
			      throttleTimeout = null;
			    },


			    50);
			  }
			} else {
			  api.reinitialise();
			}

		});

	});

});
$(function () {

	/* social icon hover styles */
	$('#social_follow_us li').hover(function () {

	  $(this).find('span.inactive_state').stop().animate({
	    opacity: 0
	  }, 75);
	}, function () {

	  $(this).find('span.inactive_state').stop().animate({
	    opacity: 1
	  }, 75);
	});
	/* end social icon hover styles */

});
$(function() {
	$carousels = $('#big-sponsor .carousel ul');

	$carousels.each(function(index, carousel) {
		var slideCount = $(carousel).find('li').length;

		$(carousel).slick({
			infinite: false,
			slidesToShow: slideCount < 4 ? slideCount : 4,
			slidesToScroll: slideCount < 4 ? slideCount : 4,
			accessibility: false,
			responsive: [
				{
					breakpoint: 1024,
					settings: {
						slidesToShow: slideCount < 3 ? slideCount : 3,
						slidesToScroll: slideCount < 3 ? slideCount : 3,
						infinite: false,
					}
				},
				{
					breakpoint: 600,
					settings: {
						slidesToShow: slideCount < 2 ? slideCount : 2,
						slidesToScroll: slideCount < 2 ? slideCount : 2,
						infinite: false,
					}
				},
				{
					breakpoint: 480,
					settings: {
						slidesToShow: 1,
						slidesToScroll: 1,
						infinite: false,
					}
				}
			]
		});
	});
});


























// If they're not required, can we delete them and remove these lines?
// don't require cascade/home
// don't require cascade/shortcuts














































;
